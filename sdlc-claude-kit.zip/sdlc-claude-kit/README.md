# sdlc-claude-kit

A portable, project-agnostic reasoning-discipline layer for Claude Code (or any
IDE assistant that can read `.claude/` files), extracted from the SAARADHI
repo's genesis session (2026-07-04/06). It teaches multi-pass engineering
process — framing, decomposition, verification, escalation — not domain facts.
It does not make a smaller model smarter; it forces the *process* a stronger
session would already run.

## What's in here

```
.claude/
  skills/
    sdlc-model-elevation-protocol/   entry point — sizes the task, routes to the rest
    sdlc-problem-framing/
    sdlc-spec-and-requirements-reasoning/
    sdlc-solution-search/
    sdlc-architecture-reasoning/
    sdlc-decomposition-and-planning/
    sdlc-implementation-discipline/
    sdlc-debugging-reasoning/
    sdlc-self-critique-loop/
    sdlc-verification-discipline/
    sdlc-testing-and-qa-reasoning/
    sdlc-code-review-reasoning/
    sdlc-quality-bar-and-taste/
    sdlc-context-and-credit-economy/
    USING-SDLC-SKILLS.md             chaining map, orchestration pattern, THE escalation rule
  agents/
    reviewer-doctrine.md
    reviewer-factual.md
    reviewer-usability.md
    skill-author.md
    sonnet-worker.md
```

## Portability status — read before importing

**Fully portable, no editing needed:** the 14 `sdlc-*` skills +
`USING-SDLC-SKILLS.md`. They're self-contained reasoning frameworks. They do
contain citations like "SAARADHI-specific worked examples inside remain as
citations" and pointers to sibling skills (`saaradhi-change-control`,
`saaradhi-architecture-contract`, `saaradhi-methodology`) — those are
**illustrative, not hard dependencies**. If the target repo doesn't have
equivalents, the skill still works; it just has one fewer real-world example
to point at.

**Needs adaptation before it fully works:** the 5 files in `agents/`.
`reviewer-doctrine`, `reviewer-factual`, `reviewer-usability`, and
`skill-author` all hard-require two files that are SAARADHI-specific and are
**not** included in this kit: `ARCHITECTURE_VISION.md` (root canonical doc)
and `.claude/skills/AUTHORING.md` (this repo's skill-authoring contract —
provenance labels, ownership map, genesis execution log). Only `sonnet-worker`
is close to drop-in (it just force-loads `sdlc-model-elevation-protocol`,
which *is* in this kit) — it has one trailing repo-specific line
("nothing routes around saaradhi-change-control") that's harmless to leave or
delete.

Two ways to use the agents in a new repo:
1. **Skip them.** The 14 skills + USING guide are the actual reasoning layer
   and work standalone. The agents are optional orchestration wiring for
   *authoring and reviewing a skill library* specifically — only relevant if
   the new repo is *also* building its own `.claude/skills/` library.
2. **Adapt them.** Write a lightweight `AUTHORING.md` and top-level vision doc
   for the new repo (even a few lines), then the 4 reviewer/author agents work
   as designed.

## How to import into a new workspace

Copy the `.claude/` folder (or just the pieces you want) into the target
repo's root:

```bash
cp -r .claude/skills/sdlc-* .claude/skills/USING-SDLC-SKILLS.md  <target-repo>/.claude/skills/
cp -r .claude/agents/*.md <target-repo>/.claude/agents/   # optional, see above
```

If the target repo has no `.claude/` yet, just copy the whole folder as-is.

Then paste the prompt in `COPILOT_IMPORT_PROMPT.md` into your IDE assistant's
chat so it internalizes the entry point and chaining map before it starts
working.
