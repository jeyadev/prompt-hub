# Import prompt — paste this into your IDE assistant's chat

Use this after copying this kit's `.claude/skills/` (and optionally
`.claude/agents/`) into the target repo. Paste the block below as-is. It works
for Claude Code, GitHub Copilot Chat, Cursor, or any assistant that can read
files in the workspace — it doesn't assume a "Skill tool"; it just tells the
assistant to read and follow the files as instructions.

---

```
This repo has a .claude/skills/ folder containing an sdlc-* skill library —
a project-agnostic engineering-discipline layer (framing, spec-writing,
solution search, architecture reasoning, decomposition, implementation,
debugging, self-critique, verification, testing, code review, quality,
context economy). Before you do any nontrivial work in this repo:

1. Read .claude/skills/USING-SDLC-SKILLS.md in full. It is the map: which
   skill to load at which moment, the escalation rule, and a copy-paste
   session preamble.
2. Read .claude/skills/sdlc-model-elevation-protocol/SKILL.md — this is the
   entry point for any nontrivial task. Its Stage 0 sizes the task into
   LIGHT/STANDARD/FULL depth; don't skip sizing even for tasks that look small.
3. Do NOT preload all 14 skills into context up front. Load each one only at
   the moment USING-SDLC-SKILLS.md §1 says to — e.g. sdlc-problem-framing
   when the ask is vague or names a solution, sdlc-solution-search before
   committing to an approach, sdlc-self-critique-loop and
   sdlc-verification-discipline before declaring anything done.
4. Apply THE ESCALATION RULE (USING-SDLC-SKILLS.md §3, conditions E1-E5)
   literally: if a self-critique flaw survives 2 revision passes, if
   verification mismatches twice with no explanation, if you're about to
   improvise something with no precedent and real blast radius (money, data,
   production, git history), if you catch yourself re-reading or re-drafting
   the same thing a 3rd time, or if two genuinely different readings of the
   task both survive framing — STOP and say so explicitly instead of
   guessing. Escalating loudly is the success state this layer is designed to
   produce; silent, confident mediocrity is exactly the failure mode it
   exists to catch.
5. Some skills contain cross-references to sibling skills named
   "saaradhi-*" (e.g. saaradhi-change-control, saaradhi-architecture-contract).
   Those don't exist in this repo — they're citations from the repo this
   library was extracted from, illustrating the pattern. Treat them as
   optional worked examples, not missing dependencies. If this repo has its
   own equivalent (a change-control process, an architecture-decisions log),
   note the mapping once and use that instead.
6. Label operational claims you make (executed / doc-verified / candidate)
   the way the skills model, and prefer writing a short decision/verification
   note over silently proceeding when something is ambiguous or risky.

Confirm you've read USING-SDLC-SKILLS.md and the elevation protocol, then
state the Stage-0 depth class for the task I'm about to give you before you
start.
```
