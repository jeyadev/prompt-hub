---
name: sdlc-testing-and-qa-reasoning
description: >-
  Load when deciding WHAT deserves a test, whether a test suite can be trusted, or what a green
  run actually licenses — before writing tests for new behavior, after fixing any bug, when
  "coverage" is discussed, or when a pass is about to be treated as shipped. Does NOT cover:
  proving one specific change works / done-claims (→ sdlc-verification-discipline), this
  project's golden-file format and harness mechanics (→ validation-and-qa), or metric-lift
  judgment (→ saaradhi-methodology). Covers: coverage reasoning (silent regressions, constraint
  boundaries, every past failure); specs-before-system labeling; never-constraints as first-class
  tests; what evidence promotes a change (structural pass ≠ shipped; thresholds are proposals
  until gated); test-the-test discipline (a test must fail when its behavior breaks); edge
  ordering (boundaries, empties, duplicates/retries). Trigger phrases: "add a test", "what should
  we test", "is this covered", "tests pass so ship it", "edge cases".
---

# Testing & QA reasoning — what deserves a test, and when a green run means anything

**Mechanism.** Cheap sessions test what is easy to test (the happy path they just wrote); frontier sessions test what would break *silently*. This skill is the project-agnostic reasoning layer: which behaviors earn a test, how to know a test is trustworthy, and what a passing run does and does not license. The mechanics of this project's test corpus (golden format, harness usage, corpus ownership) live in `validation-and-qa` — cite it, never re-document it.

## When NOT to use (load the sibling instead)

| If the real question is… | Use instead |
|---|---|
| Did THIS change work — what evidence attaches to "done"? | `sdlc-verification-discipline` (the pyramid, predicted-vs-observed, the done gate) |
| Measuring a live metric (funnel numbers, baselines, reports) | metric measurement → `diagnostics-and-instrumentation` (project) or your project's equivalent |
| Judging a metric-improvement claim (prediction-before-data, falsifiers) | experiment discipline → `saaradhi-methodology` |
| Attacking a draft's reasoning before shipping it | self-critique of drafts → `sdlc-self-critique-loop` |
| Golden-file field spec, adding a golden, running the harness, thresholds' current values | `validation-and-qa` (owns `evals/golden-conversations/**`) |

## 1. Coverage reasoning — what deserves a test (in this order)

Test-worthiness is not "lines touched"; it is **cost of silent breakage**. Rank candidates:

1. **Behaviors that regress silently.** If it broke tomorrow, would anything crash, or would it just quietly do the wrong thing? Crashes announce themselves; silent wrongness (a wrong price stated politely, an event not emitted, a ban violated) is only caught by a test that encodes the required behavior.
2. **Constraint boundaries.** Every limit the code enforces (length caps, enums, ranges) gets a test at the boundary — see §6 for ordering.
3. **Every past failure.** The failure→golden rule (`validation-and-qa` §3, binding in this project): every agent failure found in review becomes a test *written to fail against the broken behavior, before the fix ships*. The test then proves the fix and pins it forever — "a fixed failure without a golden is an unpinned regression waiting to recur." Generalized: your bug tracker is your highest-yield test backlog, because each entry is a proven-reachable failure, not a hypothetical.

**Gate (per new behavior):** answer "how would I learn if this broke next month?" If the honest answer is "a user tells us", it needs a test. If the answer is "the type checker / an existing test", writing another test for it is coverage theater — spend the effort on rank 1–3.

## 2. Specs-before-system — the certified-inventory pattern

When tests are written before the system exists, they are **design specifications**, and honest labeling is the discipline: a pass means spec-conformance, never real-world performance.

Worked example [EXECUTED 2026-07-04]: the 8-file seed corpus under `evals/golden-conversations/` predates any agent build. Every file opens with a mandatory header — "SYNTHETIC DESIGN SPECIFICATION — NOT A REAL TRANSCRIPT" — and carries `source: synthetic-spec` (e.g. `evals/golden-conversations/catalog-led/ta-saree-price-inquiry.yaml`). `validation-and-qa` §1 states the consequence plainly: passing them "is a spec-conformance check, not evidence of real-world performance." As real cases arrive, they replace/augment synthetic ones under a different provenance label (`anonymised-transcript`) — the inventory stays certified because every item declares what kind of evidence it is.

**Gate:** any test not derived from an observed real case carries a synthetic/spec label in the file itself. An unlabeled synthetic test will eventually be read as recorded history — that is fabrication by drift.

## 3. Never-constraints as first-class tests

Behavioral bans ("never fabricate a price", "never ask for payment before X") are not review comments — they are **tests checked on every run, over the whole interaction**, because a ban violated once anywhere is a failure regardless of how much else passed.

Worked example [EXECUTED 2026-07-04]: every golden in this project must carry a non-empty `never[]` list, and the harness enforces that structurally — a golden without one fails stage 1 (`evals/harness/run_evals.py` `check()`: "'never' constraints empty — every golden file must state at least the trust-ladder NEVER"). The saree golden's six `never` entries (no payment ask before rung detection, no non-catalog price, no language switch, no rung-4 demand at first contact, no screenshot-as-proof, no dark patterns) are behavioral bans encoded as data the runner checks, not prose a reviewer might remember.

**Gate:** for every subsystem, the bans exist as machine-checked assertions run with the suite — not only in a doc. If your framework has no place to put a conversation-level/whole-run constraint, that is a harness gap to fix, not a reason to skip the ban.

## 4. What evidence PROMOTES a change (pass ≠ shipped, thresholds are proposals)

1. **A structural/unit pass licenses only "did not regress against encoded expectations at that level."** It never licenses "shipped" — `validation-and-qa` §1: "Golden-pass ≠ shipped… A build that passes 100% of goldens and doesn't move the metric is a failure." Map the level you actually ran per `sdlc-verification-discipline` §2 and say which one it was.
2. **Thresholds are PROPOSED until adopted through a gate.** This project's acceptance numbers — 100% on `never` constraints, ≥90% intent match — are explicitly labeled PROPOSED, and "adopting or changing them routes through `saaradhi-change-control`" (`validation-and-qa` §4). Generalized: a bar nobody adopted through a decision gate is a suggestion; do not tighten, loosen, or *cite it as binding* silently.
3. **The asymmetry is deliberate and worth copying:** behavioral bans gate at 100% (one violation blocks promotion — they are design law), while quality dials (intent match) sit at a calibratable percentage. Flattening both into one "score" is how a ban violation hides inside a 94%.

## 5. Test-the-test discipline (a test that has never failed is unproven)

A new test earns trust only by being shown to **fail when the behavior it guards is broken**. Procedure:

1. Break the guarded behavior deliberately — mutate the code, or mutate a *copy* of the artifact in an isolated dir (never the real corpus).
2. Run the suite. Expect a loud, attributed failure (named file/case + reason), non-zero exit.
3. Restore. Only now does the test count as coverage.

Worked example [EXECUTED 2026-07-05, this authoring session]: copied `run_evals.py` + one golden into an isolated scratchpad tree, stripped the golden's `never[]` block (breaking the guarded behavior of §3), ran the harness → `FAIL mutated-no-never.yaml` with two per-field reasons, `0/1 golden files structurally valid`, exit 1. The check demonstrably fires when its target breaks; a test added without this step may be asserting nothing (wrong fixture path, always-true assertion, skipped registration) and will glow green forever.

## 6. Edge ordering — where the bugs actually live

When time-boxing edge coverage, spend in this order:

1. **Boundary values** — off-by-one at every enforced limit; test the last legal and first illegal value. Worked example: `reference_id` capped at 35 chars (Meta Payments API limit) — a 36-char value → `REJECTED: reference_id > 35 chars`, exit 1 [EXECUTED 2026-07-05]; 35 chars is the last accepted value per the `> 35` comparison at `scripts/funnel_logger.py:44`. The interesting test is 35-vs-36, not 5-vs-500.
2. **Empty states** — zero inputs, missing files, empty lists. The suite itself must fail loudly on empty (harness exits 2 on zero golden files, not 0 [EXECUTED 2026-07-04]) — full treatment in `sdlc-verification-discipline` §3.
3. **Duplicate/retry paths** — anything reachable twice will arrive twice. Pre-mortem T-011 [DOC-VERIFIED, `docs/known-traps.md`]: Meta retries webhook delivery for up to **7 days**; a consumer without idempotency keys double-fulfils. The test: replay the identical event twice (and once out-of-order/late), assert exactly one fulfilment. T-011's status line makes this a review-time obligation: "enforce at code review" until every consumer carries a dedupe check. Sibling hazard T-015 (webhook alone ≠ proof of payment) shows the same class: the retry/duplicate path is where money bugs live.

## The session gate (pass/fail)

**Every bug fixed this session has a test that fails on the pre-fix code (proven per §5), or a written one-line reason why not** ("not reproducible in harness because X; tracked as Y"). "Fixed it, moving on" with neither fails this gate — that is the failure→golden rule applied to your own session.

## Provenance and maintenance

Executed evidence: golden-mutation FAIL/exit-1 and reference_id 36-char rejection [EXECUTED 2026-07-05, this session, isolated scratchpad + read-only reject path — no project files modified]; 8/8 corpus pass, empty-corpus exit 2, synthetic headers [EXECUTED 2026-07-04, genesis log + `validation-and-qa`]. Doc-cited: failure→golden rule and PROPOSED thresholds (`validation-and-qa` §3/§4), T-011/T-015 [DOC-VERIFIED via `docs/known-traps.md` ← `docs/platform-facts.md`]. The six-section reasoning framework itself is distilled genesis practice — [CANDIDATE — verify on first downstream run]: the first session applying it should record whether the session gate caught an untested fix (log per `USING-SDLC-SKILLS.md`). Re-verify: `python evals/harness/run_evals.py` → 8/8 exit 0; `grep -n "reference_id" scripts/funnel_logger.py`; `grep -n "never" evals/harness/run_evals.py`. Last updated: 2026-07-05.
