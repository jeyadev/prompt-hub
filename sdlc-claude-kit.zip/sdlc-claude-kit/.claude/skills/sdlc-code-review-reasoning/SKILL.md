---
name: sdlc-code-review-reasoning
description: >-
  Load BEFORE reviewing any diff, PR, agent-authored file, or "please check my change" — it is
  the ordered checklist of what a principal engineer actually verifies, so review effort lands on
  correctness and invariants instead of style. Also load when: asked to approve something big and
  you're tempted to skim, a bug fix arrives without the question "what did it already corrupt?",
  a test suite passes suspiciously easily, or you're one of several parallel reviewers and need
  the report contract. does NOT cover critiquing your OWN draft (→ sdlc-self-critique-loop) or
  polish/taste judgment (→ sdlc-quality-bar-and-taste). Trigger phrases: "review this", "LGTM?",
  "check this diff", "does this look right", "approve the PR", "second pair of eyes".
---

# Code-review reasoning — what a principal checks, in order

**Mechanism.** Cheap reviews read the diff top-to-bottom and comment on what's easy to see (naming, style), missing what's expensive to miss (wrong behavior, invariant breaches, corrupted history). A principal reviews in a fixed priority order — the expensive failure classes first — and *verifies at least one thing by running it*, because reading is not evidence. This skill renders that order as a numbered procedure with gates.

**does NOT cover:** attacking your own draft before shipping (→ `sdlc-self-critique-loop` — same adversaries, different target); whether correct code is *good* — clarity, structure, reader economy (→ `sdlc-quality-bar-and-taste` owns the twelve signatures; step 6 below only says *when* taste enters, never *what* it is); construction-time discipline for code you're writing (→ `sdlc-implementation-discipline` — its done-gate is the checklist authors run before you ever see the diff).

## When NOT to use this skill

| Situation | Use instead |
|---|---|
| Critiquing your own not-yet-shipped output | `sdlc-self-critique-loop` (Refuter / Consequence-Chaser / Disambiguator on your own draft) |
| Judging polish/taste of an already-correct artifact | `sdlc-quality-bar-and-taste` |
| Writing the code in the first place | `sdlc-implementation-discipline` |
| The diff proposes changing an invariant, the schema, or the vision | `saaradhi-change-control` — that's a gate decision, not a review comment; flag and route, don't approve or nit |
| Reviewing experiment/metric claims rather than code | `saaradhi-methodology` (predicted-numbers + one-mechanism rule) |

## The review procedure (numbered; run IN ORDER — early steps outrank late ones)

### 1. Does it solve the framed problem? (not just compile)

Re-read the ask/issue/spec BEFORE the diff. State in one sentence what problem this change claims to solve and what would prove it solved (`sdlc-problem-framing` step 3: a number, a passing command, an observable state change). A diff can be internally flawless and still be a correct solution to the wrong problem — the most expensive approval you can give.

**Gate:** if you cannot state the success criterion, you cannot review this diff — go get the frame first.

### 2. Correctness at boundaries and failure paths — read the error paths FIRST

Success paths mostly work; the author ran them. The bugs live where inputs are hostile, absent, duplicated, or late. Read in this order: error/exception branches → boundary validation → then the happy path.

Checklist, with the on-disk bar to hold diffs against [EXECUTED 2026-07-04]:
- **Inputs validated at the door?** Required fields, enums, length caps, format parses — the `funnel_logger.py` `validate()` pattern. A consumer that trusts its caller is a finding.
- **Empty/zero/missing = loud, distinct outcome?** The eval harness exits 2 (not 0) on zero golden files; `funnel_report.py` treats 0 events as "no traffic OR broken instrumentation. Check both." A silent-pass-on-empty is BLOCKING.
- **Destructive ops refuse by default?** `onboard.py` REFUSING-exit-1 on an existing dir. Any overwrite/delete without a guard is a finding.
- **Retry/duplicate safety?** Webhooks especially: Meta retries for 7 days (trap T-011, `docs/known-traps.md`) — a consumer without an idempotency key + signature verify is BLOCKING, not a nice-to-have.
- **Trust chain sound?** Verify-before-fulfil: a payment webhook alone is not proof of payment (trap T-015) — fulfilment must follow a lookup-API check. Generalize: does the code act on a claim it could cheaply verify?

**Gate:** name the specific failure path you traced end-to-end. "The error handling looks fine" fails the gate.

### 3. Invariant and contract crossings

Does the diff touch a schema version, an API/webhook contract, a security boundary, an event format, or any of the project's invariants? These crossings are where a local change breaks remote consumers.

- Schema shape or meaning changed → that's versioned like code: CHANGELOG entry, VERSION bump, ALL client instances migrated including the fixture (rules live in `saaradhi-change-control` §3 — cite, don't restate). A diff that changes a field's meaning without the ceremony is BLOCKING.
- Mirrored logic drifting? The repo's own pattern: the n8n Code node declares itself a "Mirror of scripts/funnel_logger.py" — if a diff changes one side of a declared mirror without the other, that's contract drift (IMPORTANT at minimum).
- Anything routing AROUND an invariant (dropping an event, hardcoding client logic in a shared flow, PII into logs) → BLOCKING + route to `saaradhi-change-control`. Reviewers flag; they never grant the exception.

### 4. Consequence-chasing on any fixed bug

Every bug fix has a PAST. If the diff fixes something that was ever live: how long was it broken, what did it touch during that window, and did anyone probe the damage? A fix without the chase is half a review.

Worked incident [EXECUTED 2026-07-04, trap T-018, `docs/known-traps.md`]: a broken `.gitignore` pattern (inline comment invalidated it) was *fixed* — and the fix alone would have left live API keys sitting in two commits forever. The chase question "what leaked while it was broken?" is what forced the history rewrite and key rotation. Hold every bug-fix diff to that standard: **require the author to answer the blast-radius question, or answer it yourself before approving.**

**Gate:** for any diff containing a bug fix, the review names the damage window and what was probed (or states "never live — merged broken, fixed pre-release").

### 5. Tests: do they fail on the pre-fix code?

A test that passes both before and after the change tests nothing. Cheapest strong check available: revert the product change (stash / `git stash`, or check out the parent commit), run the new tests, confirm they FAIL, restore. Also check: do the tests exercise the failure paths from step 2, or only the happy path the author already believed in? Empty test runs must be loud — the harness's exit-2-on-zero-files behavior [EXECUTED 2026-07-04] is the house bar.

### 6. Simplification: what can be deleted? (taste last, never first)

Only after correctness (2), contracts (3), consequences (4), and tests (5) are settled: is there code, config, or abstraction here that shouldn't exist at all? Deletion is the highest-value late-stage comment — dead branches, speculative generality, a second home for a fact that already has one. For everything softer than deletion (clarity, structure, naming philosophy), apply `sdlc-quality-bar-and-taste` — and if you catch yourself opening the review with a style comment, you are running the procedure backwards.

## Severity calibration (mirror of this library's own three-reviewer pass)

| Severity | Meaning | Examples from the classes above |
|---|---|---|
| **BLOCKING** | Wrong behavior, data loss/corruption, security/PII exposure, invariant breach, silent-pass-on-empty | Fulfil-on-webhook-alone (T-015); no idempotency on a retried webhook (T-011); secret reachable by git (T-018 class); schema meaning changed without the gate; destructive op without refusal |
| **IMPORTANT** | Will bite later; contract drift; wrong label/provenance; missing consequence-chase on a fixed bug; tests that can't fail | One side of a declared mirror changed; unlabeled operational claim; error path swallowed into a generic catch; fixture left on old schema |
| **MINOR** | Style, duplication, naming, comment density — real but never blocks a merge alone | House-idiom mismatch; prose where a table belongs; redundant helper |

Calibration rule: severity tracks *consequence*, not *effort to fix*. A one-character fix can be BLOCKING (the T-018 gitignore line was); a large refactor request can be MINOR.

## The reviewer report contract (reviewers report; ONE fixer applies)

Per `multi-agent-orchestration` §6 [EXECUTED 2026-07-04: 3 disjoint reviewers → one fixer, applied cleanly]: reviewers DO NOT EDIT — parallel fixers re-collide. Every finding ships in this exact shape:

```
severity: BLOCKING | IMPORTANT | MINOR
file:     <absolute path>:<line>
snippet:  <the exact offending lines, short>
why:      <the failure class from steps 1–6, one sentence, consequence named>
proposed fix: <concrete change — the fixer should not have to re-derive it>
```

Then one fixer (the coordinator or a single designated agent) applies BLOCKING + IMPORTANT, and the change is committed once. If you are the sole reviewer AND the designated fixer, still write the findings first, then fix — the report is what makes the review auditable.

## Anti-patterns (fenced)

- ⛔ **Rubber-stamping the big diff** — size is a reason for MORE scrutiny, not a pass. If the diff is too large to review honestly, the finding is "split this," not "LGTM".
- ⛔ **Style-nitting past an invariant breach** — ten MINOR comments and zero findings on a missing idempotency key is a failed review that *looks* thorough. Run the order; early steps outrank late ones.
- ⛔ **Review-by-diff-only** — the diff shows what changed, never what it broke. Read the surrounding code, the callers, and the contract the changed lines participate in (the mirror-drift class in step 3 is invisible in the diff alone).
- ⛔ **Approving what needs a gate** — "looks technically fine" on a diff that crosses an invariant is authority overreach; route it (`saaradhi-change-control`), don't approve it.
- ⛔ **Reading as verification** — see the review gate below.

## The review gate (pass/fail, before any verdict)

**Every review names at least the ONE thing it verified by running or probing, not just reading** — a command executed, a test run against pre-fix code, a `git check-ignore -v`, a probe of the state a bug-fix claims to have repaired. A review with zero executed observations is a reading, not a review; label it as such or go run something. (Precedent: the library's own FACTUAL reviewer mandate was "re-execute every executable claim," not "re-read it" — `multi-agent-orchestration` §6 [EXECUTED 2026-07-04].)

## Provenance and maintenance

Worked material is on-disk: traps T-011/T-015/T-018 (`docs/known-traps.md`), `scripts/funnel_logger.py` / `onboard.py` / `funnel_report.py` behaviors and the three-reviewer→one-fixer pass (`multi-agent-orchestration` §6) — [EXECUTED 2026-07-04] per the genesis log in `.claude/skills/AUTHORING.md`; T-011/T-015 are [DOC-VERIFIED 2026-07-03 platform-facts §2/§5] hazards not yet hit live. The six-step order and severity table are the genesis session's distilled review judgment, mirroring the calibration its own review pass used; transfer effectiveness to a downstream reviewer is **[CANDIDATE — verify on first downstream review]** (record per `USING-SDLC-SKILLS.md`). Re-verify exemplars: `grep -n "T-015" docs/known-traps.md`; `python scripts/onboard.py fixture-demo-salon --archetype appointment-led` → REFUSING exit 1. Last updated: 2026-07-05.
