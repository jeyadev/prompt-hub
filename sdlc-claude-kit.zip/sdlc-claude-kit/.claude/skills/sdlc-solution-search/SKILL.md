---
name: sdlc-solution-search
description: >-
  Load AFTER framing and BEFORE committing to an approach, whenever a task has more than one
  plausible way to do it, the ask names a mechanism ("add caching", "use Sarvam", "switch to X"),
  or the first idea already feels obviously right (that feeling is the trap). Forces ≥2 candidates
  from DIFFERENT mental models, a ranked fallback menu with explicit switch triggers, and
  stress-testing each candidate against the hard constraints ON PAPER before any build.
  Does NOT cover: sequencing the chosen approach into subtasks (→ sdlc-decomposition-and-planning,
  run it next); deciding what/why to build (→ sdlc-problem-framing); attacking a finished draft
  (→ sdlc-self-critique-loop); big load-bearing structure decisions (→ sdlc-architecture-reasoning).
  Trigger phrases: "how should we do this", "what are the options", "which approach", "should we
  use X or Y", "is there a better way", "pick an approach", "evaluate options", "design choices".
---

# Solution search — ≥2 real candidates before you commit to one

**Mechanism.** The founder-named failure this skill fights is *shallow first-answer lock-in*: cheap sessions generate one coherent approach and immediately start building it. Frontier sessions generate several candidates from **different mental models**, make each one *argue why it would work*, stress-test them against the hard constraints on paper, and keep a named runner-up with a trigger for switching to it. The cost is minutes; the thing it prevents is building the wrong architecture for a day. Every step below is a concrete action with a pass/fail gate.

## When NOT to use — route to the sibling instead

| If you're… | Use instead |
|---|---|
| Sure what to build but not how to break it into work | `sdlc-decomposition-and-planning` |
| Unclear what problem/need is even in scope | `sdlc-problem-framing` (de-solutionize first, then come here) |
| Making a big load-bearing structural decision | `sdlc-architecture-reasoning` |
| Attacking an approach you've already committed to and drafted | `sdlc-self-critique-loop` |
| On a LIGHT task with one obvious correct approach | Just do it (elevation Stage 0) — 2 candidates for a rename is theatre |

## 1. Generate ≥2 candidates from DIFFERENT mental models

Two variants of one idea ("retry 3 times" vs "retry 5 times") are ONE candidate. Real candidates fail for *different reasons*. To force genuine difference, pull one candidate from at least two of these axes:

| Axis | The question it forces |
|---|---|
| Buy vs build vs do-nothing | Is there an existing rail/service, or a manual human step, that removes the build? |
| Different layer | Solve it at the data model / the flow / the platform config / the process — not just in code |
| Invert the problem | Instead of preventing X, make X harmless / detectable / reversible |
| Boring-established vs novel | The dullest known-good construct vs the clever one |
| Move the constraint | Change *where* the work happens so a hard limit stops applying |

**Gate (pass/fail):** your two candidates fail under *different* conditions. Write the one-line failure mode of each; if both fail the same way, they are one candidate — generate another from a different axis. "I only found one approach" fails this gate: either the task is genuinely LIGHT (say so, exit) or you stopped at the first answer (the named trap).

## 2. The derivation obligation — WHY it works, not THAT it might

For each surviving candidate write ONE sentence stating the *mechanism* by which it succeeds — the causal reason, not a hope. "Use a queue" is not a candidate; "a queue absorbs the burst because producers and consumers decouple, so the 7-day webhook retry storm (T-011) can't overrun the consumer" is.

**Gate:** a candidate with no WHY sentence is **deleted, not ranked**. You cannot rank options you can't explain; an unexplained option that "wins" is first-answer lock-in wearing a bracket.

## 3. Stress-test each candidate against the HARD constraints — on paper, before building

List the constraints that outrank preference: invariants, compliance/DPDP, platform caps and limits, authority boundaries (`saaradhi-change-control` HARD list; platform limits in `whatsapp-platform-reference` / `payments-rails-reference`). Run every candidate against every hard constraint *on paper*. A candidate that violates a hard constraint is eliminated now — not discovered broken on build day 3.

The high-value move here is the **constraint intersection**: when two constraints both bind one design element, find the single choice that satisfies both, and prove it does.

Worked example [DOC-VERIFIED 2026-07-04, `payments-rails-reference` §2 + footer]: the payment reconciliation key sits under two independent limits — Razorpay's `receipt` field ≤ 40 chars **and** Meta's `reference_id` ≤ 35 chars. Rather than carry two keys (and a mapping table, and a class of "which key was this?" bugs), the resolved design is **one key ≤ 35 chars, used as both** — the intersection of the two limits satisfies both by construction. One number, chosen once, kills a whole category of reconciliation defect. That is the payoff of stress-testing against the constraint set before building, not after.

**Gate:** each candidate you carry forward has passed every HARD constraint on paper, or is struck out with the constraint it violated named. Zero survivors → escalate (the frame or the constraints may be wrong — `sdlc-model-elevation-protocol` E3), don't build the "least bad" violator.

## 4. Rank into a fallback menu with explicit switch triggers

Don't pick one and discard the rest — rank them into a menu where each entry carries the condition under which you'd switch to it. This means a mid-build surprise becomes "switch to B" instead of "restart solution search".

| Rank | Candidate | Take it when (the default condition) | Switch AWAY when (the trigger) |
|---|---|---|---|
| A | recommended | default holds | trigger 1 fires |
| B | fallback | A's precondition fails | … |
| C | escape hatch | A and B both blocked | … |

Worked example (`first-client-campaign` §1.1, GATE 1A): the WhatsApp access path is exactly this menu — **A** Direct Cloud API on our own Meta app (default; take it because serving one client needs no Tech-Provider status), **B** BSP-fronted (take it *only when* A hits a wall client #1 actually needs solved: calling-API enablement we can't get directly, verification stuck, or throughput), **C** Meta Business Agent fast path (take it *only when* the controlled path stalls enough to threaten the ≤5-day clock). Each rank names the exact condition that flips the choice. The menu was built once; execution just watches for the triggers.

**Gate:** the top choice has a written "take it when", and at least one lower rank has a written "switch away when" trigger that is *observable* (a failed verification, a stuck review, a fired latency threshold) — not "if it feels wrong".

## 5. Keep the boring one — spend novelty only where the problem is novel

Default to the **most boring candidate that passed §3**. Boring = fewest new dependencies, most widely understood, easiest for a different session to maintain without you. A solution whose upkeep needs its author is a liability, not cleverness (`sdlc-quality-bar-and-taste` signature 9).

Novelty is justified **only** when you can name the specific hard constraint the boring candidate provably fails (from §3) that the novel one clears. "The boring one is boring" is not a justification. "The boring one exceeds the ≤35-char reconciliation key" is.

**Gate:** if the chosen candidate is the novel one, one sentence names the hard constraint the boring one failed. If you can't, choose boring.

## The commit gate (this is why the skill exists)

Before you write a line of the solution, you have on the page:
1. The **chosen candidate** with its WHY (§2) and its "passed all hard constraints" line (§3).
2. A **named second-best** with its explicit, observable **switch trigger** (§4).

Miss either half and you have a hunch, not a searched-and-chosen solution. A hunch with no runner-up is the shallow first answer this skill was loaded to prevent.

## Anti-patterns (fenced)

- ⛔ Two parameter tweaks of one idea presented as "options" (§1: they fail the same way → one candidate).
- ⛔ Ranking candidates you can't each explain the mechanism of (§2).
- ⛔ Discovering a hard-constraint violation on build day 3 that a 10-minute paper check in §3 would have caught.
- ⛔ A fallback whose switch trigger is a feeling, not an observation (§4).
- ⛔ Choosing the clever candidate for its cleverness with no failed-constraint justification (§5).
- ⛔ Generating candidates before the problem is framed — you'll search the solution space of the wrong problem (`sdlc-problem-framing` first).

## Provenance and maintenance

Worked examples are on-disk artifacts of this repo: the receipt-≤40 ∩ reference_id-≤35 → one-key-≤35 resolution in `payments-rails-reference` §2 and its authoring footer (**[DOC-VERIFIED 2026-07-04]** against Razorpay/Meta docs via `docs/platform-facts.md` §5); the A/B/C access-path fallback menu in `first-client-campaign` §1.1 (path facts **[DOC-VERIFIED 2026-07-03]**, the menu structure authored 2026-07-04); webhook-retry T-011 referenced in §2's example lives in `docs/known-traps.md`. The search procedure itself (that its gates close the first-answer-lock-in gap on smaller models) is **[CANDIDATE — verify on first downstream run]** as of 2026-07-05 — the first session to use it should record how many candidates it generated and whether the §3 paper check eliminated one that would otherwise have been built, per `saaradhi-methodology`. Re-verify examples: `grep -n "one key ≤35\|≤35" .claude/skills/payments-rails-reference/SKILL.md`; `grep -n "GATE 1A" .claude/skills/first-client-campaign/SKILL.md`. Last updated: 2026-07-05.
