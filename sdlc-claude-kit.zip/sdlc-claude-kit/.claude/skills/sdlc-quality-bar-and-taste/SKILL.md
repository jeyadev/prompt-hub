---
name: sdlc-quality-bar-and-taste
description: >-
  Load when output is correct but you must judge whether it's GOOD — final polish before
  delivering documents/code/reports, choosing between two working approaches, reviewing your own
  or an agent's finished artifact, or when feedback says "technically right but not what I wanted"
  / "feels off" / "too verbose" / "hard to follow". Trigger phrases: "polish this", "is this good
  enough to ship", "make it read well", "quality pass", "does this meet the bar".
---

# Quality bar & taste — catching the tasteless-but-correct output

**Mechanism.** Correctness is checkable; quality is judgment. This skill renders the judgment as checklists a Sonnet-class model can run. It cannot install aesthetic sense — it CAN catch the twelve most common ways correct output still disappoints, because each has an observable signature.

**When NOT to use:** correctness is still in doubt (→ `sdlc-self-critique-loop` first — taste-polishing wrong content is waste); domain-specific review depth (→ `sdlc-code-review-reasoning` for code).

## The twelve signatures of tasteless-but-correct (check each; fix or consciously waive)

**Structure & reader economy**
1. **Outcome buried** — the reader's first sentence must answer "what happened / what should I do". Fix: move the conclusion to line 1; background after.
2. **Uniform depth** — everything explained equally = nothing prioritized. Fix: depth ∝ risk/novelty; the routine gets one line.
3. **Prose where a table belongs** (≥3 items × ≥2 attributes) and **tables where prose belongs** (explanations, causality).
4. **No "what NOT" fence** — good artifacts state non-goals/when-not-to-use. Every skill in this library carries one; so should specs, designs, PRs.
5. **Wall-of-everything** — the artifact answers questions nobody asked. Fix: delete anything that doesn't change the reader's next action (the 20-token note beats the 2,000-token detour — `sdlc-context-and-credit-economy` §1).

**Claims & honesty**
6. **Confidence without provenance** — operational claims lacking ran-it / doc-checked / unverified marking. The tri-label (`skill-genesis` §1) is a taste marker, not bureaucracy: it's what lets a reader calibrate trust per sentence.
7. **Hedging fog** — "should probably mostly work" on things you could simply verify. Verify, then say it plainly; reserve uncertainty language for the genuinely unverified.
8. **Silent success theater** — "Done!" without evidence, or failures reported as "mostly passing". Worked precedent: genesis recorded "both n8n instances unreachable" as a finding in the integration doc rather than papering over it [EXECUTED 2026-07-04, `docs/n8n-integration.md` §0 history].

**Engineering judgment**
9. **Cleverness as liability** — a solution whose maintenance needs its author. Prefer the boring construct; spend novelty only where the problem is actually novel (`sdlc-implementation-discipline`).
10. **Missing failure design** — quality output makes silence impossible: empty ≠ pass (the eval harness exits 2 on zero test files, not 0 [EXECUTED 2026-07-04, `evals/harness/run_evals.py`]), destructive ops refuse by default (`onboard.py` overwrite refusal), invariants enforced mechanically not documentarily (`funnel_logger.py` PII guard).
11. **Asymmetric effort** — 500 lines on the easy part, 3 on the dangerous part. Fix: re-allocate until effort maps to risk.
12. **Unowned facts** — the same fact stated in two places (they WILL diverge). One home; cross-reference elsewhere.

## The two-question finish (after the checklist)

1. *"If a sharp senior read only the first 5 lines, would they know what happened and trust the rest?"*
2. *"What would I cut if this cost me ₹10 per line?"* — cut it.

## Calibration by audience

The bar's expression changes with the reader (this project's floor: semi-technical n8n-capable operators + Sonnet-class sessions — `docs/decisions/004`): for operators, expected-output after every command; for models, trigger-rich descriptions and numbered gates; for the founder, outcome-first summaries with evidence attached. Same bar, different rendering.

## Provenance and maintenance

Signatures 6/8/10 cite on-disk artifacts ([EXECUTED 2026-07-04]); the twelve-signature list itself is the genesis session's distilled editorial judgment — [CANDIDATE] as a transfer mechanism until a downstream session's output is compared before/after applying it (record per `USING-SDLC-SKILLS.md`). Re-verify examples: `python evals/harness/run_evals.py` on an empty temp dir → exit 2. Last updated: 2026-07-05.
