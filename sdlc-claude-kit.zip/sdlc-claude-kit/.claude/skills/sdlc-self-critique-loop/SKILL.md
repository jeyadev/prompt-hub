---
name: sdlc-self-critique-loop
description: >-
  Load BEFORE declaring any nontrivial output done — code, design, runbook, analysis, review
  response — to run the adversarial pass that separates frontier output from first-draft output.
  Also load when: your explanation only covers the observations that fit, someone says "are you
  sure?", a conclusion feels obvious, or two facts you're using sit suspiciously close together.
  Trigger phrases: "double-check this", "red-team it", "is this right?", "before you ship",
  "critique your own work", "what could be wrong here".
---

# The self-critique loop — draft, refute, revise

**Mechanism.** Cheap sessions produce their first coherent answer and stop; frontier sessions attack their own draft before showing it. This skill turns that implicit attack into three named adversaries with pass/fail gates. It is Stage 3 of `sdlc-model-elevation-protocol` in full depth.

**When NOT to use:** while still drafting (finish the draft first — critiquing fragments wastes passes); for experiment/metric claims use the stricter `saaradhi-methodology` (predicted-numbers + one-mechanism rule); for reviewing OTHERS' code → `sdlc-code-review-reasoning`.

## The three adversaries (run in order; each must produce a fix OR a written "checked X, found nothing")

### 1. The Refuter — "what single observation would prove this wrong?"
1. State your draft's load-bearing claim in one sentence.
2. Name the cheapest observation that would falsify it (a command, a file read, a doc line).
3. GO OBSERVE — never theorize when you can look. Gate: FAIL if you cannot name a falsifying observation (unfalsifiable = not yet a claim) or if you skipped running it.

Worked example [EXECUTED 2026-07-04]: claim "the fallback n8n instance is available." Falsifying observation: one curl. Result: `404 - No workspace here` — hibernated. Ten seconds of observation replaced a wrong architecture assumption (`docs/n8n-integration.md` §0).

### 2. The Consequence-Chaser — "if this was ever broken, what damage already exists?"
Any bug found, config fixed, or assumption invalidated has a PAST, not just a future:
1. How long was the wrong state live?
2. What did it touch during that window? (commits, sent messages, written records, downstream consumers)
3. Probe each — don't assume the blast radius is zero because the fix is in.

Worked example [EXECUTED 2026-07-04]: a `.gitignore` pattern was found broken and fixed. The chase question — "so was the secret committed while it was broken?" — found live API keys in two commits, forcing a history purge + key-rotation recommendation (trap T-018, `docs/known-traps.md`). The fix without the chase would have left credentials in history forever.

### 3. The Disambiguator — "which two nearby things did I merge?"
Adjacent numbers, similarly-named concepts, and same-symptom-different-cause pairs are where confident wrongness lives:
1. List every numeric limit / named concept pair in your draft that could be conflated.
2. Verify each against its OWN primary source, separately.
3. For identical symptoms, run one discriminating probe before assigning a cause.

Worked examples [EXECUTED 2026-07-04]: (a) calling-API permission-*request* caps (1/day) vs connected-*call* caps (~100/day) — one number wrong by 100× if merged (trap T-006); (b) two identical-looking 404s: bare proxy `404 page not found` = wrong hostname, vs `404 - No workspace here` = hibernated workspace — same symptom, different root cause, different fix (traps T-002/T-003).

## The one-mechanism rule (for any explanatory conclusion)

Your proposed cause must explain ALL observations — including the negatives and the data points that got worse. If one observation doesn't fit, the mechanism is wrong or incomplete; "mostly explains it" is the named failure mode (cherry-picking). Full treatment with worked example: `saaradhi-methodology` discipline (b).

## Revision protocol

- Each adversary's finding → apply the fix → re-run ONLY that adversary on the changed part.
- Two full revision passes failing on the same flaw → stop, escalate per `sdlc-model-elevation-protocol` E1. More passes past that point historically produce thrash, not quality (loop-detection rule E4).

## Provenance and maintenance

All worked examples are on-disk artifacts: traps T-002/T-003/T-006/T-018 (`docs/known-traps.md`), `docs/n8n-integration.md` §0 — [EXECUTED 2026-07-04]. The adversary framework itself is the distilled procedure of the genesis session; its transfer effectiveness to smaller models is [CANDIDATE — verify on first downstream run] (record per `USING-SDLC-SKILLS.md`). Re-verify examples: `grep -c "T-0" docs/known-traps.md` (expect ≥18). Last updated: 2026-07-05.
