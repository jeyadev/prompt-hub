---
name: sdlc-problem-framing
description: >-
  Load BEFORE starting any task whose ask is more than one sentence, arrives second-hand, or
  smells like a solution rather than a problem ("add a retry", "make it faster", "use X").
  Also load when: mid-task you discover the ask doesn't match what the code/data shows, the user
  keeps adding "oh and also", or two stakeholders want different things from one sentence.
  Trigger phrases: "what are we actually solving", "requirements unclear", "the user asked for X
  but", "before we start", "scope this".
---

# Problem framing — solve the need, not the sentence

**Mechanism.** The most expensive failure in engineering is a correct solution to the wrong problem. Cheap sessions answer the sentence they were given; frontier sessions first separate the *stated ask* from the *underlying need*, then confirm the frame cheaply before spending on the build. This is Stage 1 of `sdlc-model-elevation-protocol`.

**When NOT to use:** the ask is already a falsifiable spec with a success metric (go build); turning a confirmed frame into a full spec → `sdlc-spec-and-requirements-reasoning`; sizing protocol depth → elevation protocol Stage 0.

## The framing procedure (numbered, checkable)

1. **Restate** the ask in your own words — one sentence for WHAT, one for WHY-they-want-it. If you cannot write the WHY sentence, you don't have the need yet.
2. **De-solutionize**: if the ask names a mechanism ("add caching", "switch to Sarvam"), ask what observable problem it solves. The mechanism goes in the candidate list (→ `sdlc-solution-search`), not in the frame. Worked example: the SAARADHI vision explicitly fences this — clients buy "more bookings / recovered carts," never "an AI agent" (`ARCHITECTURE_VISION.md` §9); the product frame is the metric lift, the agent is one candidate mechanism.
3. **Name the ONE success criterion and its measurement** — a number, a passing command, an observable state change. "Success is never judged by eye" (`ARCHITECTURE_VISION.md` §4) generalizes: if you can't say how you'll measure done, you haven't framed it. Gate: write the verification command NOW.
4. **Fence the scope**: ≥2 explicit non-goals. Precedent: the vision dedicates a section to non-goals and calls them "equally binding" — do the same for tasks (§1 "Non-goals").
5. **Surface the constraints that outrank preferences**: invariants, compliance, authority boundaries — check `saaradhi-change-control` HARD list (or the project's equivalent) BEFORE designing, not after.
6. **Ambiguity gate**: if ≥2 materially different interpretations survive steps 1–5 and choosing wrong is expensive → ask ONE batched, option-rich question (see below). If interpretations converge or a wrong guess is cheap → pick the conventional default, state it, proceed (asking is not free; it blocks the pipeline).

## Question economy (the ≤5 rule)

When you must ask, frontier behavior is: batch questions; ask ONLY what neither docs nor repo nor conventions can answer; give the answerer structured options with a recommended default; record answers in a decision file so no session asks twice.
Worked example [EXECUTED 2026-07-04]: genesis reduced ALL founder-input needs to 4 questions (first client, existing accounts, operator skill floor, frozen-vs-negotiable), answered in one round and recorded as `docs/decisions/004-genesis-founder-answers.md` — cited since by 10+ skills instead of re-asking.

## Frame drift (mid-task re-framing)

When evidence contradicts the frame (the "bug" is a feature, the metric already moves, the real bottleneck is elsewhere): STOP building. Report the contradiction with evidence, propose the corrected frame, get a nod if the delta is material. Silently building the original frame against contrary evidence is the expensive path. If describing a problem was the ask, deliver the assessment and stop — don't fix unasked.

## Anti-patterns (fenced)

- ⛔ Restating the ask verbatim and calling it framing (step 1 requires YOUR words + the WHY).
- ⛔ A success criterion of "it works" / "user is happy" (not measurable).
- ⛔ Asking questions answerable by reading the repo (violates question economy; burns the answerer's patience budget).
- ⛔ Expanding the frame to adjacent problems you noticed (note them, fence them — `sdlc-context-and-credit-economy` §1).

## Provenance and maintenance

Worked examples cite `ARCHITECTURE_VISION.md` §1/§4/§9 and `docs/decisions/004` — on-disk, [EXECUTED 2026-07-04] where dated. The procedure is distilled from the genesis session's own framing behavior; downstream transfer effectiveness [CANDIDATE — verify on first run]. Re-verify: `ls docs/decisions/004-genesis-founder-answers.md`. Last updated: 2026-07-05.
