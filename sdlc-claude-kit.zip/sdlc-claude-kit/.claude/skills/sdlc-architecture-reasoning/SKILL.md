---
name: sdlc-architecture-reasoning
description: >-
  Load BEFORE making or defending any load-bearing technical decision — choosing between
  tools/stacks/designs, writing a design doc, answering "why is it built this way", classifying
  what may change freely vs what needs a gate, or reviewing an architecture that "feels right"
  but has no written WHY. Also load when: a trade-off is being argued by vibes, a design doc
  claims no weaknesses, someone proposes building for a future that isn't funded by evidence,
  or a past decision has no recorded reason and is about to be re-litigated. Does NOT cover
  turning a frame into a testable spec → sdlc-spec-and-requirements-reasoning; executing/gating
  an already-decided change → saaradhi-change-control; SAARADHI's OWN specific decisions →
  saaradhi-architecture-contract (this skill teaches the generic method those artifacts
  instantiate). Trigger phrases: "which should we pick", "design doc", "why did we choose",
  "trade-offs", "is this decision reversible", "what would make us revisit this".
---

# Architecture reasoning — load-bearing decisions with a written WHY

**Mechanism.** Architecture is the set of decisions that are expensive to reverse. Cheap sessions make them implicitly (the first workable design wins) and defend them by vibes; frontier sessions make them *explicit, justified, classed by hardness, and pre-wired with the trigger that reopens them*. Everything below is that discipline as checkable procedure. The single gate over all of it: **every architectural choice in your output carries a written Why AND a Revisit-when trigger. No exceptions — an unexplained choice is technical debt with no invoice.**

## When NOT to use this skill (use the sibling instead)

| You are… | Use instead |
|---|---|
| Turning a confirmed frame into requirements/acceptance evidence | `sdlc-spec-and-requirements-reasoning` |
| Executing or gating a change to something already decided | `saaradhi-change-control` |
| Looking up what SAARADHI specifically decided and why | `saaradhi-architecture-contract` |
| Confirming what problem you're solving at all | `sdlc-problem-framing` |
| Red-teaming a finished design before shipping | `sdlc-self-critique-loop` |

If your task is "decide between designs, and leave behind a reason the next session can act on," you are in the right place.

## 1. The decision-record discipline (five fields, one file, forever citable)

Every load-bearing decision gets a record in the house format — **Context · Options considered · Decision · Why · Revisit-when** (`docs/decisions/README.md` defines it; one file per decision, `NNN-short-title.md`).

1. **Context** — what forced a choice *now* (not background prose; the forcing function).
2. **Options considered** — ≥2 real options. One option = a rationalization, not a decision.
3. **Decision** — one sentence, unambiguous, dated.
4. **Why** — traced to a goal/constraint, not to taste. "Newest" is not a why; "newest ⇒ longest deprecation runway" is.
5. **Revisit-when** — the concrete trigger (an event, a number, a date) that legitimately reopens it, plus where to check. A decision without a reopening trigger becomes either dogma (never revisited) or noise (relitigated every session).

**Worked example [EXECUTED 2026-07-04, `docs/decisions/003-graph-api-version-pin.md`]** — a complete record in 7 lines: Context (placeholders needed pinning at genesis) · Decision (pin v25.0, dated) · Why (newest stable; oldest versions get sunset, so latest maximizes runway — a mechanism, not a preference) · Revisit-when (Meta releases v26+, or a used endpoint deprecates — with the changelog URL to check). Note the calibration: a decision record does NOT need to be long; it needs all five fields.

**Gate:** for each decision in your output, can a stranger find (a) why it was made and (b) what would reopen it, without asking you? If no → write the record before shipping the design.

## 2. Trade-off analysis as a weighted table, not vibes

When ≥2 options survive first contact, decide with a table whose **deciding criterion is named and weighted BEFORE scoring** — otherwise you'll unconsciously weight whichever criterion favors the option you already liked.

1. **Name the criteria** (3–6). Each must be observable (cost/month, p95 latency, has-feature-X yes/no, migration effort in days) — "elegance" is not a column.
2. **Declare the weighted criterion FIRST**: which single criterion dominates and why (traced to the goal metric or a constraint). Write this line above the table, before filling any cell.
3. **Fill the table** — one row per option, evidence-or-label per cell (a measured number, a doc citation, or an explicit "[CANDIDATE]"). An empty cell is a research task, not a shrug.
4. **Decide by the weighting, and say so.** If the table's answer surprises you, the interesting finding is *why* — either a criterion is missing (add it, openly) or your prior was wrong (update it).
5. **Gate:** if the weighted criterion was chosen after seeing the scores, the analysis is invalid — redo with the weighting committed first.

**Worked example (structure) [EXECUTED 2026-07-04].** The pending BSP selection (`docs/decisions/README.md` queue item `001`) is pre-framed exactly this way: four candidates (Gupshup / AiSensy / Interakt / Wati) scored on three named criteria — **calling-API support, INR pricing, webhook quality** — with calling-API support effectively the weighted criterion (no calling support = no voice front door, which is HARD; pricing is negotiable). The criteria were committed at genesis, before any vendor was evaluated — the ordering this section mandates.

## 3. Invariants as the architecture's constitution

Some properties are not design preferences but the conditions under which the system's strategy works at all. Extract them, number them, and **trace each to a strategic WHY** — an invariant whose reason nobody can state will be "optimized away" by the first session under deadline pressure.

Procedure:
1. Ask of each candidate property: *"if this stopped holding, would the product's core promise still be true?"* No → invariant. Yes → it's a preference; don't inflate it.
2. Write the invariant + rationale as a two-column table (invariant | why it is load-bearing, traced to the strategy doc). Keep them few — a constitution with 40 articles is a wishlist.
3. Enforce mechanically where possible (a validating script, a required field, a refusing default), documentarily otherwise — and route ANY change to one through the project's HARD gate.

**Worked example [cited: `saaradhi-change-control` §2].** SAARADHI's 7 invariants each carry a strategic derivation, e.g. invariant 2 (*every flow emits funnel events; unmeasured = unshipped*) traces to the business model itself: outcome-priced retainers on measurable lifts — "a flow that doesn't emit events cannot prove a lift — so it cannot be billed, renewed, or iterated. No events = no product." Every one of the 7 rows has that shape: the WHY is the strategy, not "best practice." That table lives in one home (`saaradhi-change-control`) and siblings cite it — copy the *pattern*, not the rows.

## 4. Known-weak-point honesty (a design doc with no stated weaknesses is unfinished)

Every architecture has points where it is currently thin, dependent, or bet-shaped. Frontier discipline is to **name them plainly in the design doc itself**, with honest status and a re-check pointer — because a weak point you named is a monitored risk, and one you hid is a future incident plus lost credibility.

1. List every dependency that doesn't exist yet, every single point of failure, every claim resting on an unverified fact, every moat that is contestable.
2. For each: honest one-line status (no hedging fog, no oversell) + how/when to re-check it.
3. **Gate:** if your design doc's weak-points section is empty, you haven't finished thinking — every real architecture has at least one. Go find yours.

**Worked example [cited: `saaradhi-architecture-contract` §2].** The contract's weak-points table states, about its own architecture: *"The whole conversation rail sits behind a BSP we have not yet signed up for … multi-tenant onboarding and Calling are aspirational"*; *"There is effectively no warm failover right now"* (fallback n8n hibernated, [EXECUTED 2026-07-04]); the v2 Sarvam layer is "an Indic-depth edge, not English-frontier parity, and a contestable moat." Each row has a re-check pointer. That is the register this section requires: plain statements a seller could be embarrassed by, written down anyway.

## 5. HARD vs SOFT decision classing (what needs a gate vs what swaps on evidence)

Not all decisions deserve the same ceremony. Class each one explicitly:

| Class | Meaning | Change path |
|---|---|---|
| **HARD** | Load-bearing for the strategy; changing it is a pivot | Formal gate + owner sign-off (project's change-control) |
| **SOFT** | An implementation bet; swappable when evidence says so | Evidence + a §1 decision record; no ceremony |

1. Classing test: *"if we changed this next month on new evidence, is that healthy adaptation (SOFT) or a strategic pivot (HARD)?"*
2. **Write the class next to the decision** — unclassed decisions default, under pressure, to whatever is convenient.
3. A decision can split: class the principle and the instance separately.

**Worked example [EXECUTED 2026-07-04, `docs/decisions/004-genesis-founder-answers.md`]** — the pattern's origin: the founder explicitly froze *stack choices (n8n, Razorpay, BSP pick) as SOFT — "swappable on evidence without ceremony, recorded in docs/decisions/"* — and *the 7 invariants, metric contract, and trust ladder as HARD — change-control with founder sign-off only*. And the split-classing move, from `saaradhi-architecture-contract` §1.6: **rail-agnostic payments is a HARD principle; Razorpay the provider is SOFT** — the hedge survives even if the vendor swaps.

## 6. Horizon discipline (build-now vs design-for vs narrate-only)

Every capability in a design gets a horizon, and the build only commits to the nearest one:

| Horizon | Discipline | Failure it fences |
|---|---|---|
| **H1 — build on now** | Ship it; sell it; depend on it | — |
| **H2 — design for, pilot** | Leave the seam (interface/config slot); pilot behind a gate; never sell as live | Betting a delivery on an unshipped capability |
| **H3 — narrate only** | Vision narrative; zero build, zero seams | Speculative code for a future that may not arrive |

1. Tag every component/capability H1/H2/H3 in the design doc.
2. **Promotion is evidence-gated, never enthusiasm-gated:** H2→H1 requires the enabling fact confirmed available AND a passed gate on *your own metric* (not a vendor benchmark), recorded as a §1 decision. H3→H2 is a deliberate strategy amendment.
3. **Selling or committing above H1 is the "vapour" failure — fence it explicitly in the doc.**

**Worked example [cited: `ARCHITECTURE_VISION.md` §2, `saaradhi-architecture-contract` §1.3].** SAARADHI places its whole stack: H1 = Cloud API agent, Calling API + voice notes, UPI Intent via Razorpay, CTWA ads ("*All of v1 lives here*"); H2 = Sarvam Indic voice layer, in-chat UPI (designed-for: the seam exists as `voice.pipeline: v1-general | v2-sarvam` in `bundle-config.template.yaml`, switchable "only after §8 gate passes"); H3 = autonomous agentic commerce (narrated, zero code). The why is a named risk: the platform shipped 4 major changes in 90 days — H1-only builds stay shippable while the ground moves.

## 7. The check-an-idea procedure (run every new idea through the constitution)

Before building any new idea/tool/integration, answer in writing (generalized from `saaradhi-architecture-contract` §3's 7-question checklist):

1. **Does it strengthen the core differentiator, or just polish a swappable component?** A better rail that doesn't feed the moat is a distraction.
2. **Which horizon (§6)?** About to sell/commit above H1 → stop.
3. **Does it violate any invariant (§3)?** Check every one, in writing → any yes routes to the HARD gate; no self-approval.
4. **How is it measured?** Name the metric/event that proves it worked; can't name it → not ready (→ `sdlc-spec-and-requirements-reasoning` §2).
5. **Does it preserve the architecture's non-negotiable UX/strategy properties?** (For SAARADHI: voice-first + rung order.) Check the quiet violations, not just the loud ones.
6. **Does it add reusable leverage** (schema extension, template, recorded trap) or is it a one-off?
7. **Is its cost modelled** against the constraint that dominates your economics?

**Gate:** all seven answered in writing before prototyping. The cheapest place to kill a bad idea is here — before it has sunk cost defending it.

## The output gate (repeat, because it is the whole skill)

Before shipping any design doc, decision, or architecture review, verify: **every architectural choice has (a) a written Why traced to a goal or constraint and (b) a Revisit-when trigger someone else could act on.** Sweep your output for the words "obviously," "clearly," "standard practice" — each is usually a missing Why wearing a costume.

## Anti-patterns (fenced)

- ⛔ Defending a choice with "it's the standard" — trace it to a goal or admit it's a default.
- ⛔ A trade-off table whose weights were picked after seeing the scores (§2 gate).
- ⛔ Promoting preferences to invariants ("we always use X") — inflation devalues the real constitution (§3.1).
- ⛔ A design doc with no weak-points section (§4 gate: unfinished).
- ⛔ Treating everything as HARD (nothing can adapt) or everything as SOFT (nothing holds) — class each item (§5).
- ⛔ Building H2/H3 capability into an H1 delivery because "we'll need it eventually" (§6).
- ⛔ Re-litigating a recorded decision without new evidence matching its Revisit-when trigger — cite the record, move on.

## Provenance and maintenance

Worked examples are on-disk artifacts: `docs/decisions/README.md` + `003` + `004` [EXECUTED 2026-07-04]; `ARCHITECTURE_VISION.md` §2/§7; `saaradhi-change-control` §2 invariant-rationale table; `saaradhi-architecture-contract` §1.3/§1.6/§2/§3; `schema/v0.1/bundle-config.template.yaml` (the H2 seam). The invariant-rationale rows and weak-point rows are OWNED by those siblings — this skill teaches the pattern and cites; on divergence, the sibling wins. The generalized procedures (five-field record, weighted-table ordering, classing test, horizon table, 7-question generalization) are the genesis session's distilled decision behavior — [CANDIDATE — verify on first downstream run]: the first session using this on a real decision should record whether the Why + Revisit-when gate held (per `USING-SDLC-SKILLS.md`, when present). Re-verify examples exist: `ls docs/decisions/003-graph-api-version-pin.md docs/decisions/004-genesis-founder-answers.md`; `grep -n "Revisit when" docs/decisions/README.md`. Last updated: 2026-07-05.
