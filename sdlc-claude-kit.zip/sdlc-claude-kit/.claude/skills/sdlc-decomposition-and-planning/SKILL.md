---
name: sdlc-decomposition-and-planning
description: >-
  Load AFTER the frame is set and BEFORE writing code/docs, on any task with ≥3 moving parts,
  parallel work, or a multi-file / multi-day shape. Turns one task into INDEPENDENTLY VERIFIABLE
  subtasks, freezes interfaces/names before parallel work, orders by information gain (kill the
  riskiest assumption first), and places checkpoints so an interruption is cheap.
  Does NOT cover: generating the candidate approaches you are decomposing (→ sdlc-solution-search,
  run it first); what/why to build (→ sdlc-problem-framing); the agent fan-out mechanics
  (→ multi-agent-orchestration); the adversarial pass on the result (→ sdlc-self-critique-loop);
  load-bearing structure choices (→ sdlc-architecture-reasoning).
  Trigger phrases: "break this down", "plan this", "make a plan", "how do we sequence this",
  "split the work", "what order", "can we parallelize", "too big to do at once", "roadmap this",
  "where do we start".
---

# Decomposition & planning — subtasks a weaker model can each prove done

**Mechanism.** Cheap sessions plan by listing steps in the order they occur to them, then discover mid-build that step 3 invalidated step 1. Frontier sessions do three things first: cut the task into pieces that can each be *verified alone*, freeze the shared names so parallel pieces never collide, and run the piece that kills the biggest assumption *before* the easy pieces. This is Stage 2 of `sdlc-model-elevation-protocol`. Every rule below is a concrete action with a pass/fail gate — none of it requires "thinking carefully".

## When NOT to use — route to the sibling instead

| If the task is… | Use instead |
|---|---|
| LIGHT by elevation Stage 0 (one file, reversible, one obvious check) | Just do it + run the check. Planning it is procrastination (§1). |
| Still undecided on WHICH approach to take | `sdlc-solution-search` — decompose the winner, not the field |
| Not yet framed (unclear what/why) | `sdlc-problem-framing` |
| Ready to fan the subtasks out to background agents | `multi-agent-orchestration` (this skill produces the plan it consumes) |
| A big structural/interface decision in its own right | `sdlc-architecture-reasoning` |
| Done, and you're about to declare it so | `sdlc-self-critique-loop` |
| Long/expensive and drifting on scope | `sdlc-context-and-credit-economy` |

## 1. The plan-first gate — plan, or is planning the procrastination?

Plan explicitly (do §2–§5) when ANY is true: ≥3 subtasks, work will run in parallel, one subtask's failure would invalidate another's output, or blast radius = 2 (money/data/customer-facing/git-history). Otherwise skip to building.

**Planning has become procrastination — stop and build the first subtask NOW — when ANY is true:**
- You have rewritten the plan ≥2 times without producing one durable artifact (file/commit).
- The plan has one real step dressed up as several.
- Every remaining unknown can only be resolved by running something (then run it — that IS the next subtask, not more planning).

**Gate:** state in one line "planning because <trigger>" or "skipping plan, LIGHT task". If you can't name the trigger, you're procrastinating — build.

## 2. Cut into INDEPENDENTLY VERIFIABLE subtasks (the core gate)

A subtask is *independently verifiable* only if you can name — before building any of it — ONE observation that proves it done **without running any sibling subtask**. If proving A done requires B to already exist, A and B are not independent: either merge them, or make the dependency explicit and sequence them.

Build this table before writing any implementation:

| # | Subtask (the output artifact) | Verified by (one concrete probe) | Depends on | Risk 0–2 |
|---|---|---|---|---|
| S1 | e.g. `flows/appointment-led/opt-in.json` exists + parses | `python -c "import json;json.load(open(...))"` → exit 0 | — | 1 |
| S2 | funnel-logger called by S1's flow | `grep -c funnel_logger <flow>` ≥ 1 | S1 | 2 |

Rules for the "Verified by" cell (each is checkable):
- It is a **command, a file check, or an observable state change** — never "looks done" / "should work".
- It fails loud on the empty case (absent file, zero rows, exit ≠ 0) — see `sdlc-quality-bar-and-taste` signature 10.
- It can be written NOW, before the subtask is built. If you can't write it now, you don't understand the subtask — split it further or go learn it.

**GATE (blocks all execution): every row has a filled, concrete "Verified by" cell before subtask S1 starts.** A row without its probe is a defect, not a subtask. This is the one gate this skill exists to enforce.

## 3. Freeze interfaces and names BEFORE any parallel work

Before two workers (agents, sessions, or future-you across days) touch related pieces, freeze what they share: file paths, function/skill names, event names, schema field names, the cross-reference map. Written once, on disk, in one home (`sdlc-context-and-credit-economy` §3).

**Why it unblocks parallelism:** a reference *by frozen name* resolves regardless of build order; a reference *by content* forces the referenced thing to exist first. Freeze the names and the ordering constraint disappears.

Worked example [EXECUTED 2026-07-04]: this repo's 16-skill cross-reference map was frozen in `.claude/skills/AUTHORING.md` ("The library" table) *before* any skill was written. That let wave-2 authoring agents launch **before wave-1 finished**, and every forward reference to a not-yet-written sibling resolved with zero dangling links (`multi-agent-orchestration` §2). Had names been assigned as each skill was written, wave 2 would have had to wait for wave 1 — the parallelism would have collapsed.

**Gate:** every name/path/interface that ≥2 subtasks share appears in one frozen list before parallel work starts. Test: pick any cross-reference in a subtask spec — does its target name already exist in the frozen list? If no, freeze it first.

## 4. Order by information gain — kill the riskiest assumption first

Ordering has two layers:
1. **Dependency order (mandatory):** a subtask runs only after everything in its "Depends on" cell.
2. **Within the remaining freedom, information-gain order:** do the subtask that most reduces uncertainty or is most likely to invalidate other work *first* — not the easiest, not the most fun. The point of doing it first is to fail cheaply, before you've built on a bad assumption.

**Long-pole rule (external latency you don't control):** anything gated on a review/approval/KYC/DNS clock you can't compress — start it on **day 1 regardless of where its output sits in the sequence**, because its clock runs in the background while you do everything else. Run independent tracks concurrently.

Worked example (`first-client-campaign` Phase 1.2, §"campaign map"): Razorpay KYC is started **on day 1, before a client even exists**, because its multi-day review is the long pole — its output (live payment keys) isn't needed until trust-ladder rung 3, weeks later, but its *clock* must start now. In the same campaign the mandatory baseline-measurement week is run **concurrently with the build week** (Phase 3 ‖ Phase 4), because that is the only ordering where "discovery → live in ≤5 working days" and "no deploy without a measured baseline" are both satisfiable. Ordering here is not cosmetic; it's what makes the constraints co-satisfiable.

**Gate:** the first subtask you execute is either (a) the highest-risk assumption-killer among those with no unmet dependency, or (b) a long-pole started for its clock. If your first subtask is the easy one, re-order and say why the easy one earned priority.

## 5. Checkpoint design — make any interruption cost ≤1 subtask

Sessions die (API limits, crashes). Design so the maximum rework from an interruption at *any* point is one subtask.

1. **Durable artifacts first.** Files on disk and commits survive; your context does not (`sdlc-context-and-credit-economy` §5). Order work so each completed subtask leaves something on disk.
2. **Checkpoint at every phase boundary and after any subtask others depend on** — commit, or at least land the file. Worked example [EXECUTED 2026-07-04]: the genesis authoring run hit **two** session-limit die-offs mid-fan-out; because work was committed/landed at phase boundaries, recovery was "inventory disk state, resume the dead agents" in minutes with zero lost work, not a restart (trap T-008, `docs/known-traps.md`; `multi-agent-orchestration` §5).
3. **On resume, trust disk not memory:** probe what actually landed (`ls`, `wc -l`, `grep -c "<footer marker>"`) before continuing — agents' own beliefs about their progress were wrong in both directions during those die-offs (`multi-agent-orchestration` §5).

**Gate:** before executing, name the checkpoint after which an interruption costs ≤1 subtask of rework. If the answer is "we'd lose hours," insert an earlier durable boundary.

## The plan is done when (composite check)

- Every subtask row has a concrete "Verified by" probe (§2 gate) — the non-negotiable one.
- Shared names are frozen in one place (§3 gate).
- The first-executed subtask is the riskiest assumption-killer or a long-pole-for-its-clock (§4 gate).
- A ≤1-subtask-rework checkpoint is named (§5 gate).

Miss any and you have a step list, not a plan. A step list survives contact with reality about as well as an unframed ask survives contact with the code.

## Anti-patterns (fenced)

- ⛔ Subtasks whose only "verification" is running the next subtask — that's one subtask, mis-cut.
- ⛔ Doing the easy/fun subtask first to feel progress, leaving the assumption that could invalidate all of it for last.
- ⛔ Assigning names as you go during parallel work (guarantees collisions and dangling refs — the exact failure §3 prevents).
- ⛔ "Verified by: manual review" on a subtask a command could check — hidden judgment-only verification (`sdlc-quality-bar-and-taste` signature 10).
- ⛔ Re-planning a third time instead of building the first subtask (§1 procrastination signal; loop-detection = stop, `sdlc-model-elevation-protocol` E4).

## Provenance and maintenance

Worked examples are on-disk artifacts of this repo: the frozen 16-skill map in `.claude/skills/AUTHORING.md` + `multi-agent-orchestration` §2/§5; `first-client-campaign` Phase 1.2 / Phase 3‖4 concurrency; trap T-008 in `docs/known-traps.md` — all **[EXECUTED 2026-07-04]** during the genesis run this procedure was distilled from. The procedure itself (its gates closing the decomposition gap on smaller models) is **[CANDIDATE — verify on first downstream run]**: untested on a live Opus/Sonnet session as of 2026-07-05 — the first such session should record whether the §2 gate actually caught an unverifiable subtask, per `saaradhi-methodology`. Re-verify examples exist: `grep -c "^| " .claude/skills/AUTHORING.md` (the library map) and `grep -l "T-008" docs/known-traps.md`. Last updated: 2026-07-05.
