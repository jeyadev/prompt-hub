# USING-SDLC-SKILLS.md — how Opus/Sonnet sessions run the frontier process here

**What this is.** The `sdlc-*` skills are a project-agnostic reasoning-discipline layer distilled from the frontier-model session that built this repo (2026-07-04/05). They cannot install latent capacity; they transfer the **process** — multi-pass structure, forced checkpoints, escalation. This file is the chaining map, the orchestration pattern, THE escalation rule, the session preamble, and one worked end-to-end example. Portable: copy the `sdlc-*` folders + this file to any repo (SAARADHI-specific worked examples inside remain as citations).

## 1. Discovery and loading

`sdlc-model-elevation-protocol` is the ENTRY POINT — load it at the start of any nontrivial task; its Stage 0 sizes the task (LIGHT/STANDARD/FULL) and its stages route into the other skills at the moment each is needed. Don't preload all 14; load on the stage you're in:

| Task moment | Load |
|---|---|
| Start of any nontrivial task | `sdlc-model-elevation-protocol` (always) + `sdlc-context-and-credit-economy` (if session will be long) |
| Ask is vague / second-hand / names a solution | `sdlc-problem-framing` |
| Turning a confirmed frame into a buildable spec | `sdlc-spec-and-requirements-reasoning` |
| Choosing between approaches / designing structure | `sdlc-solution-search`, then `sdlc-architecture-reasoning` for load-bearing decisions |
| Breaking up the work / planning parallel effort | `sdlc-decomposition-and-planning` (+ `multi-agent-orchestration` if spawning agents) |
| Writing the code/artifact | `sdlc-implementation-discipline` |
| A bug / unexplained behavior | `sdlc-debugging-reasoning` (which CHECKs `docs/known-traps.md` first) |
| Before declaring anything done | `sdlc-self-critique-loop` → `sdlc-verification-discipline` |
| Deciding what deserves tests / what evidence promotes | `sdlc-testing-and-qa-reasoning` |
| Reviewing someone else's (or an agent's) work | `sdlc-code-review-reasoning` |
| Output correct but "is it good?" | `sdlc-quality-bar-and-taste` (last, never first) |

Project-specific siblings outrank the generic layer on their turf: metric claims → `saaradhi-methodology`; platform facts → `whatsapp-platform-reference`/`payments-rails-reference`; change gates → `saaradhi-change-control`. On divergence, the project skill wins in this repo.

## 2. Orchestration pattern (Opus orchestrator + workers)

For work too big for one session pass, the full mechanics live in `multi-agent-orchestration` (coordinator contract, shared brief, ownership map, waves, interruption recovery, three-reviewer pass). Delegation wiring specific to this setup:

1. Orchestrator (Opus or better) runs elevation-protocol Stages 0–2 itself — framing and decomposition are NOT delegated.
2. Per subtask, spawn from `.claude/agents/`: `skill-author` (opus — judgment-heavy authoring), `sonnet-worker` (mechanical, precisely-specified tasks; its definition force-loads the elevation protocol), or the three reviewers (`reviewer-factual` / `reviewer-doctrine` / `reviewer-usability`) after deliverables exist.
3. Every spawn prompt names: exact deliverable paths, the files to read first, the verification command with expected output, and the report contract.
4. Merge = coordinator applies reviewer findings (single fixer), runs the verification suite, commits once.

## 3. THE ESCALATION RULE (stated once, authoritatively)

A session stops and routes back to a stronger model or the human — reporting what it tried, observed, and ruled out — when ANY of these observable conditions holds:

- **E1** — a flaw found by self-critique survives 2 revision passes.
- **E2** — predicted-vs-observed verification mismatches twice on the same check with no explanatory mechanism.
- **E3** — the task needs an approach with no precedent in this repo/docs AND blast radius is customer-facing / money / data / git history.
- **E4** — loop detected: re-reading the same files or re-drafting the same section a 3rd time.
- **E5** — two materially different interpretations of the ask survive framing and a wrong guess is expensive.

Escalation is a SUCCESS state of the protocol. Silent completion below the bar is the failure mode this whole layer exists to prevent. Escalations are also DATA: note them (one line, `docs/experiments/` or the task report) so the library learns where the ceiling actually is.

## 4. Copy-paste session preamble

```
Before acting: load .claude/skills/sdlc-model-elevation-protocol/SKILL.md and follow it.
State your Stage-0 depth class (LIGHT/STANDARD/FULL) with axis scores. For STANDARD+,
show Stage-1 framing (restated ask, scope fence, measurable success criterion) BEFORE
implementation. Chain skills per .claude/skills/USING-SDLC-SKILLS.md §1. Never skip the
adversarial pass or predicted-vs-observed verification. Apply escalation rule E1–E5 from
USING-SDLC-SKILLS.md §3 — escalate loudly; never ship silent mediocrity. Label every
operational claim: executed / doc-verified / candidate. In this repo, nothing routes
around saaradhi-change-control.
```

## 5. Worked end-to-end example (real, from this repo's history)

Task (real, 2026-07-04): *"A sibling fixed our `.gitignore` — the `.mcp.json` line had an inline comment."* A naive session says "fix confirmed, moving on." The elevated loop, as actually run:

1. **Stage 0:** blast radius 2 (git history + live credentials) → FULL depth mandatory.
2. **Stage 1 framing:** stated ask = "note the fix"; underlying need = "secrets must not be in git — ever, including the past." Success criterion written up front: `git log --all -- .mcp.json` returns empty AND the file is ignored AND still present locally.
3. **Stage 3, Consequence-Chaser:** a broken ignore pattern has a PAST — probe: was the file committed while the pattern was broken? `git log --oneline --all -- .mcp.json` → **in both commits. Live API keys in history.**
4. **Stage 4 boundary:** history rewrite is destructive + the keys may be compromised → act minimally (filter-branch purge, reflog expire, gc), report loudly, recommend key rotation as the owner's call — don't rotate credentials you don't own.
5. **Stage 5 predicted-vs-observed:** predicted empty history / ignored / present — observed exactly that (one surprise: filter-branch also removed the working-tree copy; restored from backup, mismatch explained before closing).
6. **ACCRUE:** trap T-018 filed in `docs/known-traps.md`; the gitignore rule ("no inline comments") now costs future sessions one grep instead of one incident.

Every step cites artifacts still on disk: T-018, commits `47fbd7f`/`3acd933`, `.gitignore` comment block. That is the observable signature of the process working: **the second question ("what did it already break?") got asked.**

## 6. Residual gap — honest statement [CANDIDATE until measured]

What this layer likely recovers on Opus/Sonnet: process-shaped quality — framing, scope discipline, verification honesty, consequence-chasing, routing. What it likely does NOT recover: novel architecture under ambiguity, subtle cross-system interactions nobody wrote down, adversarial/security reasoning depth, taste beyond the twelve checkable signatures. **Escalation is mandatory (not optional) for:** anything E3-shaped, security-sensitive design, irreversible data/history operations without an on-disk precedent, and vendor-policy interpretation where being wrong breaches compliance (invariant 1/6 territory). First downstream sessions should record depth class, escalations fired, and rework count — that data (not this file's claims) establishes what the layer actually closes.

## Provenance and maintenance

Chaining map reflects the 14 sdlc-* skills + 5 agent definitions on disk (2026-07-06); worked example cites T-018 artifacts [EXECUTED 2026-07-04]. The elevation-protocol's effectiveness downstream is [CANDIDATE — verify on first Opus/Sonnet run] (record per §6). Re-verify the map: `ls .claude/skills | grep -c "^sdlc-"` → expect 14; `ls .claude/agents` → 5 files. Last updated: 2026-07-06.
