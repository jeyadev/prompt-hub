---
name: sdlc-model-elevation-protocol
description: >-
  THE entry-point discipline skill. Load at the START of any nontrivial engineering session on
  Opus/Sonnet-class models — before writing code, docs, plans, or answers — to run the multi-pass
  process that approximates frontier-model output quality. Also load when: output was rejected as
  shallow/wrong, you caught yourself answering immediately from the prompt's framing, you're unsure
  whether to keep grinding or escalate, or a task is tagged "fable-quality required". Trigger
  phrases: "do this properly", "production quality", "don't miss anything", "elevation protocol",
  "run the full process", plus ANY multi-step build/debug/review task.
---

# The elevation protocol — executing a frontier model's process on a smaller budget

**Honest mechanism statement.** This protocol cannot give you latent capacity you don't have. It transfers three real things: (1) a multi-pass procedure that frontier models run implicitly and cheaper models skip, (2) forced checkpoints where skipped reasoning gets caught, (3) an escalation rule so you fail loudly instead of silently. Expect it to close *much* of the quality gap on process-shaped work (runbooks, reviews, debugging, specs) and *less* on deep-insight work (novel architecture, subtle concurrency, adversarial security). The residual gap is listed in `USING-SDLC-SKILLS.md` §Residual-gap — read it once so you know your own blind spots.

**When NOT to use:** trivial single-step tasks (a rename, a one-line fix with an obvious test) — Stage 0 below tells you when to bail to a light pass. Sibling routing: framing problems → `sdlc-problem-framing`; the critique pass in depth → `sdlc-self-critique-loop`; token/scope management → `sdlc-context-and-credit-economy`.

## Stage 0 — Size the task (adaptive depth; 60 seconds, always)

Score the task 0–2 on each axis; sum = depth class.

| Axis | 0 | 1 | 2 |
|---|---|---|---|
| Blast radius | one file, reversible | subsystem | customer-facing / money / data / git history |
| Uncertainty | done this exact thing before | familiar shape, new details | novel problem or unfamiliar domain |
| Verifiability | a command proves it instantly | testable with setup | judgment-verified only |

- **0–1 → LIGHT:** single pass + run the verification command. Skip to Stage 5.
- **2–3 → STANDARD:** Stages 1, 2, 3(one adversary), 4, 5.
- **4–6 → FULL:** all stages, Stage 3 with three adversaries, Stage 5 with predicted-vs-observed table. **If blast radius = 2, FULL is mandatory regardless of total.**

Write the score in your working notes. Re-score if the task mutates mid-flight.

## Stage 1 — Frame before solving (counter: first-answer lock-in)

1. Restate the request in your own words: the stated ask AND the underlying need (they differ more often than not — see `sdlc-problem-framing`).
2. List what you will NOT do (scope fence, ≥2 items). Unbounded scope is the top cheap-model failure mode.
3. Name the ONE success criterion and how it will be *measured*, not eyeballed. If you cannot state it, you do not understand the task — go get the answer before proceeding. Worked precedent: every SAARADHI deployment declares one metric + baseline before shipping (`ARCHITECTURE_VISION.md` §4); the same rule applied to your task.
4. **Gate:** can you write the Stage-5 verification command(s) NOW, before building? If no → the plan is not concrete yet.

## Stage 2 — Decompose and order

Per `sdlc-decomposition-and-planning`: break into subtasks that are *independently verifiable*; freeze interfaces/names between them FIRST (this is what let 16 parallel authoring agents cross-reference sibling skills that didn't exist yet — `multi-agent-orchestration` §2 [EXECUTED 2026-07-04]); order by information gain (do the assumption-killing subtask first, not the easy one).

## Stage 3 — Draft, then adversarial pass (the pass cheap models skip)

Draft fully. Then STOP and switch roles — you are now the reviewer who wants this rejected:

1. **The Refuter:** what single piece of evidence would prove this wrong? Go look for it (run the command, read the file, check the doc). Do not theorize when you can observe.
2. **The Consequence-Chaser** (FULL only): if any bug/assumption you found here was ever true in the past, what damage already exists? Hunt it. Worked example: a broken `.gitignore` pattern wasn't just fixed — the question "what already leaked while it was broken?" found live API keys in two commits and forced a history rewrite (trap T-018, `docs/known-traps.md`) [EXECUTED 2026-07-04].
3. **The Disambiguator** (FULL only): find every pair of adjacent numbers/terms you may have merged (rate limit vs quota; request cap vs connected-call cap — trap T-006 came from exactly this). Verify each against its primary source separately.
4. **Gate (pass/fail):** each adversary produced either a concrete fix applied to the draft, or a written one-line reason it found nothing. "It looks fine" fails the gate — an adversary that finds nothing must say what it checked.

## Stage 4 — Boundary check (counter: silent authority overreach)

1. Does any part of the output change doctrine, contracts, schemas, pricing assumptions, or other people's files? → **flag, don't fix**: escalate to the owner/change-control instead of silently patching. Worked example: a discovered platform-pricing change that invalidated cost doctrine was escalated as a change-control event, not edited into the canon by the discovering agent (`docs/platform-facts.md` §14 addendum) [EXECUTED 2026-07-04].
2. Every claim in your output gets provenance: verified-by-running / verified-against-doc / unverified-candidate. Unlabeled operational claims are defects (`skill-genesis` §1).

## Stage 5 — Verify by observation, then report honestly

1. Write the EXPECTED result of each verification command *before* running it (FULL: as a predicted-vs-observed table).
2. Run. Any mismatch = stop and explain the mismatch before shipping; a surprise in verification is information, not noise.
3. Report: outcome first, evidence attached, failures stated plainly ("tests fail with X" — never "mostly works"), unverified parts labeled.
4. **Trust disk, not memory:** before claiming a file/state exists, probe it (`ls`, `wc -l`, `grep`). Agents' own status beliefs were wrong in both directions during the genesis interruptions — files believed missing were complete and vice versa (`multi-agent-orchestration` §5) [EXECUTED 2026-07-04].

## The escalation rule (fail loudly)

Escalate to a stronger model or human — stating what you tried and where it broke — when ANY of:
- **E1:** Stage 3 Refuter finds a flaw you cannot fix in 2 revision passes.
- **E2:** Stage 5 predicted-vs-observed mismatches twice on the same check with no explanatory mechanism.
- **E3:** the task requires inventing an approach with no precedent in the repo/docs AND blast radius = 2.
- **E4:** you notice you are re-reading the same files or re-generating similar drafts ≥3 times (loop detection = capacity ceiling reached).
- **E5:** two plausible interpretations of the ask survive Stage 1 and choosing wrong is expensive.
Escalation is a SUCCESS state of this protocol, not a failure. Silent low-quality completion is the failure.

## Copy-paste session preamble

Paste at the start of any Opus/Sonnet session (or into the task prompt):

```
Before acting: load and follow .claude/skills/sdlc-model-elevation-protocol/SKILL.md.
Run Stage 0 sizing and state your depth class (LIGHT/STANDARD/FULL) with the 3 axis scores.
For STANDARD+: show Stage 1 framing (restated ask, scope fence, measurable success criterion)
BEFORE any implementation. Never skip Stage 3 (adversarial pass) or Stage 5 (verify with
predicted-vs-observed). Apply the escalation rule E1–E5 — escalating loudly is success,
silent mediocrity is failure. Label every operational claim: executed / doc-verified / candidate.
Chain sibling skills per .claude/skills/USING-SDLC-SKILLS.md.
```

## Provenance and maintenance

Worked examples cite artifacts on disk in this repo (traps T-006/T-008/T-018 in `docs/known-traps.md`, `platform-facts.md` §14 addendum, `multi-agent-orchestration` §2/§5) — all [EXECUTED 2026-07-04] during the genesis run this protocol was distilled from. The protocol itself is a [CANDIDATE — verify on first downstream run]: its effectiveness claim (closing much of the process-gap) is untested on a real Opus/Sonnet session as of 2026-07-05 — the first such session should record depth class, escalations fired, and rejected-output count in `docs/experiments/` per `saaradhi-methodology`. Re-verify example paths: `grep -l "T-018" docs/known-traps.md`. Last updated: 2026-07-05.
