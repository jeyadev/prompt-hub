---
name: sdlc-context-and-credit-economy
description: >-
  Load when a session is long, wandering, or expensive: context bloating, re-reading the same
  files, re-deriving established facts, scope creeping past the original ask, unsure whether to
  spawn an agent vs work inline, or budgeting a multi-hour task across session limits. Also load
  at the START of any task expected to exceed ~50 tool calls. Trigger phrases: "keep it cheap",
  "we're burning tokens", "you already read that", "stay on task", "budget this work",
  "session limit", "context is huge".
---

# Context & credit economy — scope discipline for sessions that don't melt

**Why this skill is weighted heavy:** the founder named "poor scope & context economy" as a top failure of non-frontier sessions (`docs/decisions/004`-adjacent Q&A, 2026-07-05). The moves below are what a frontier session does differently, each grounded in the genesis run.

**When NOT to use:** deciding *what* to build (→ `sdlc-problem-framing`); mechanics of running agent fan-outs (→ `multi-agent-orchestration`); mid-task quality doubts (→ `sdlc-self-critique-loop`).

## 1. The scope fence (write it, then obey it)

At task start write: (a) the deliverable, (b) 2+ explicit NON-deliverables, (c) the "done" probe command. Every time you're tempted to touch something outside the fence, apply the triage:
- **Blocks the deliverable** → do it minimally, note it.
- **Damages something if ignored** (security, data loss) → handle it, tell the user why (worked example: mid-authoring discovery that live API keys had entered git history — out of scope, but unignorable; handled with a minimal purge and reported, then straight back to the fence — trap T-018 [EXECUTED 2026-07-04]).
- **Neither** → one-line note in your report ("noticed X, didn't touch it"), move on. This sentence costs 20 tokens; the detour costs 20,000.

## 2. Read economy (the biggest silent burn)

1. **Never re-read what you already know.** Before any Read, ask: is the answer already in my context? The harness tracks file state — a file you edited does not need re-reading to "check" the edit.
2. **Read the slice, not the file**: offset/limit for a known region; `grep -n` to locate, then read ±30 lines. Full-file reads only for files you must hold entirely (schemas, short docs).
3. **Probe before read**: `wc -l`, `ls`, `grep -c` answer most "what's the state of X?" questions for 1% of the tokens. Worked example: 15 interrupted agents were triaged with one `find` + `wc -l` loop instead of opening any file (`multi-agent-orchestration` §5) [EXECUTED 2026-07-04].
4. **Never read agent transcripts / large logs into context** — act on their summaries; tail logs with `-Tail N`.

## 3. Write-once, cite-forever (externalize your context)

Anything you'll need across sessions or agents goes ON DISK in its one home, then gets cited, not repeated:
- Shared conventions → one brief file all agents read (`AUTHORING.md` pattern: written once, cited by 16 agents, saving ~2k tokens × 16 prompts [EXECUTED 2026-07-04]).
- Verified results → an execution log others may cite without re-running (AUTHORING.md §"Genesis execution log").
- Decisions → `docs/decisions/NNN`; incidents → the traps register. If it's not written down, it will be re-derived at full price by the next session — writing it IS the cheap path.

## 4. Delegate vs inline (agents cost a cold start)

Spawn an agent only when: output is bulky and parallelizable (N similar documents), OR the work needs isolation (review with fresh eyes), OR it exceeds what your remaining context can hold. Otherwise inline — every agent re-reads ground truth you already hold (~10-40k tokens of cold start each). When you DO fan out: freeze interfaces first, give each agent a report contract so you triage completions from summaries, never transcripts (`multi-agent-orchestration` §2-3).

## 5. Budgeting across limits and long tasks

1. **Commit/checkpoint at phase boundaries** — a committed baseline made two session-limit die-offs recoverable in minutes (T-008) [EXECUTED 2026-07-04].
2. **Order work so interruption is cheap**: durable artifacts first (files on disk survive; your context doesn't).
3. On resume: probe disk state, don't reconstruct from memory (§2.3).
4. **Loop detection = stop signal**: re-reading the same file or re-drafting the same section a 3rd time means you've hit a wall — escalate per `sdlc-model-elevation-protocol` E4 instead of burning the remaining budget on pass 4-7.

## 6. The cheap-pass decision

Not every task deserves the full protocol. Use elevation-protocol Stage 0 sizing; for LIGHT tasks a single pass + verification command is CORRECT behavior, not laziness. Spending FULL depth on a rename is the same discipline failure as spending LIGHT depth on a payment flow.

## Provenance and maintenance

Worked examples: T-008/T-018 (`docs/known-traps.md`), `multi-agent-orchestration` §2/§5, `AUTHORING.md` genesis log — all [EXECUTED 2026-07-04]. Token-cost ratios (cold start ~10-40k; detour vs note) are order-of-magnitude estimates from the genesis run, not measured benchmarks — labeled as such. Re-verify examples exist: `grep -l "T-008" docs/known-traps.md`. Last updated: 2026-07-05.
