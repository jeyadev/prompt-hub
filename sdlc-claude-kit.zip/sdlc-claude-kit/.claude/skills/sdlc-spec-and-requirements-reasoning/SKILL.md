---
name: sdlc-spec-and-requirements-reasoning
description: >-
  Load AFTER the frame is confirmed and BEFORE building — to turn a "we agree on the problem"
  frame into a falsifiable spec: goal metric + measurement, inputs/outputs, invariants, non-goals,
  failure behaviors, acceptance evidence. Also load when: a requirement can't be tested ("make it
  robust / user-friendly / fast"), two requirements collide, you're about to write a freeform doc
  where a filled-in schema belongs, or a reviewer can't tell from the spec what "done" means.
  Does NOT cover confirming the frame → sdlc-problem-framing; load-bearing design decisions +
  their WHY → sdlc-architecture-reasoning; gating a change to a frozen spec item →
  saaradhi-change-control; final polish → sdlc-quality-bar-and-taste. Trigger phrases:
  "write the spec", "what are the requirements", "acceptance criteria", "define done",
  "is this testable", "these two requirements conflict".
---

# Spec & requirements reasoning — from a confirmed frame to a falsifiable contract

**Mechanism.** A frame says *what problem, why, and how success is measured* (`sdlc-problem-framing`). A spec turns that into a **contract others can build and test against without you in the room**. Cheap sessions skip straight from frame to code, so "done" is negotiated after the fact by eye. Frontier sessions write the spec first, make every requirement carry its own test, and surface conflicts *before* the build commits to one reading. The measurable payoff: a colleague or Sonnet-class model reading only the spec can write the acceptance test — the review gate below.

**Input contract.** This skill assumes a CONFIRMED frame: restated ask + WHY, one measured success criterion, ≥2 non-goals, constraints checked (`sdlc-problem-framing` steps 1–6). If you don't have that, go get it first — specifying an unconfirmed frame is a precise answer to the wrong question.

## When NOT to use this skill (use the sibling instead)

| You are… | Use instead |
|---|---|
| Still deciding what problem to solve / whether the ask matches reality | `sdlc-problem-framing` |
| Choosing between architectures/tools and recording WHY | `sdlc-architecture-reasoning` |
| Changing something a spec froze (an invariant, a metric contract, a schema field) | `saaradhi-change-control` |
| Judging whether a correct spec is also *good* (readable, right-altitude) | `sdlc-quality-bar-and-taste` |
| Red-teaming a finished spec before shipping it | `sdlc-self-critique-loop` |

If your task is "make this frame buildable and testable," you are in the right place.

## 1. The spec skeleton (six slots — every slot filled or explicitly waived)

Fill all six. A blank slot is a defect, not brevity; if a slot truly doesn't apply, write "N/A because…".

| Slot | What goes here | Fails if… |
|---|---|---|
| **Goal metric + measurement** | ONE primary metric, its baseline, target, window, and the *command/observation* that reads it | judged by eye; no baseline |
| **Inputs / outputs** | every input (type, source, required?), every output (shape, consumer) | "takes the data, returns a result" |
| **Invariants that must hold** | properties true in *every* execution — enumerate; mark which are project-HARD | only happy-path stated |
| **Non-goals** | ≥2 things this explicitly will NOT do (inherited from the frame + spec-level ones) | scope is open-ended |
| **Failure behaviors** | for each way it can fail: what the system does (refuse / handoff / log) — silence is never a valid answer | errors "shouldn't happen" |
| **Acceptance evidence** | the concrete artifact that proves each requirement met (a passing command, a logged event, a state change) | "we'll know it works" |

**Worked example — the metric slot as a shipped contract [EXECUTED 2026-07-04].** SAARADHI's metric contract (`ARCHITECTURE_VISION.md` §4) is exactly this slot made mandatory: each deployment declares *archetype · ONE primary metric · measured baseline · target lift · measurement window*, and **"no deployment ships without a baseline. Success is never judged by eye."** The machine form is `schema/v0.1/bundle-config.template.yaml`: `metric.baseline: null` with `# REQUIRED` — an un-filled baseline is a structurally invalid spec, not a soft omission.

## 2. Make every requirement falsifiable (the core move)

A requirement you cannot test is a wish. For **each** requirement, write the observation that would prove it violated. If you can't name one, the requirement is not yet a requirement — sharpen it until you can.

1. **Turn adjectives into observations.** "Fast" → "p95 < 200 ms measured by `latency_probe.py -n 10`." "Robust" → "on malformed input, exits non-zero and logs the reason, never writes partial state." "User-friendly" → a named task a named user completes unaided.
2. **Attach the acceptance evidence in the same line** — requirement and its test are one unit, never two documents that drift.
3. **Gate (pass/fail):** read your requirement list. Every row has a paired observation? If any row has none → it fails; rewrite or delete it. A spec of untestable requirements passes review and fails delivery.

**Worked example [EXECUTED 2026-07-04].** "No deployment without a baseline" is falsifiable by one command — the first-client-campaign Gate 3 check: `python -c "import yaml; m=yaml.safe_load(open('clients/<id>/bundle-config.yaml'))['metric']; assert m['baseline'] is not None and m['primary'] and m['target_lift']"` → the spec item *is* the test. Contrast an unfalsifiable sibling like "the agent feels natural" — no command, no gate, not a requirement.

## 3. Surface requirement conflicts — name the collision, force a ranked resolution

Two requirements that cannot both be maximised is normal, not a mistake. The failure is *discovering it in the build*. Procedure:

1. **Name the collision explicitly** — "R-a (X) and R-b (Y) cannot both hold at full strength because Z."
2. **Force a ranked resolution:** either (a) one requirement outranks the other (say which and why), or (b) a reframing satisfies both (state it), or (c) it escalates because both are HARD (→ `saaradhi-change-control` / the owner).
3. **FLAG the resolution as a deliberate interpretation** in the spec — a chosen reading, dated, reversible if wrong. A silent pick reads later as an accident.

**Worked example [EXECUTED 2026-07-04, `first-client-campaign` §Phases 3–4].** Two vision requirements collide: *onboarding in ≤5 working days* (§1.3) vs *no deployment ships without a measured baseline week* (§4). Naively sequential = ~12 days, breaking §1.3. Resolution taken: **run the baseline week CONCURRENTLY with the build week; go-live waits on BOTH gates (Gate 3 baseline AND Gate 4 build); the ≤5-day clock starts at build kickoff.** This is flagged in the skill as a deliberate interpretation — *and* it respects the ranking that the baseline is HARD and un-waivable ("there is no founder-waivable version of it") while the 5-day target is a SOFT goal that concurrency protects. Naming beat guessing: the wrong silent pick (ship on day 4 against a 4-day baseline) is called out there as metric-contract erosion.

## 4. The schema-thinking move — specs as versioned artifacts others fill

When a spec will be instantiated many times (per client, per service, per run), do not write freeform prose each time. Write a **schema** — a machine-consumable template with typed slots, REQUIRED markers, and a version — that others fill without re-deciding structure. This is what turns bespoke work into a productized, delegable pipeline.

- **Signal you need a schema:** you're about to copy a prose doc and edit the nouns for the Nth instance.
- **Shape:** typed fields; REQUIRED vs optional marked; defaults where safe; a `schema_version`; one canonical template file others copy, never hand-author.
- **Version it like code:** additive field = minor bump; remove/rename/re-mean a field or change a required contract = breaking (major bump + migrate every existing instance). The classification of "additive vs breaking" and its gate is owned by `saaradhi-change-control` §3 — cross-reference it, don't restate the rules here.

**Worked example [EXECUTED 2026-07-04].** `ARCHITECTURE_VISION.md` §6 defines five per-client artifacts (`domain-profile.md`, `pain-map.md`, `customer-asks.md`, `channel-trust.yaml`, `bundle-config.yaml`) as a **versioned schema** — "Nothing is re-typed. The schema is versioned like code." `bundle-config.template.yaml` (schema v0.1) is the filled-form contract: `# REQUIRED` markers, enumerated allowed values (`archetype: appointment-led | catalog-led | …`), invariant reminders inline (`funnel_events: true # must stay true`). A new client is schema-filling, not doc-writing — that is the spec-as-schema move paying off.

## 5. The spec review gate (the one test that matters)

**Hand the spec — and ONLY the spec — to a colleague or a fresh model and ask: "write the acceptance test for this."** If they can, the spec is a contract. If they come back with "what does done look like for requirement 3?", that requirement failed §2 and the spec is not ready. This gate is cheap (one message) and catches most under-specification before a line is built.

Run it against your own spec first by role-switching: reading only what you wrote (not what you know), can you produce every acceptance command? Any gap = a slot or a requirement to sharpen.

## Anti-patterns (fenced)

- ⛔ A requirement with no paired observation ("should handle errors gracefully") — §2 gate.
- ⛔ Happy-path-only: no failure-behavior slot filled, so silence-on-failure ships as "fine."
- ⛔ Discovering a requirement conflict during the build and silently picking one — §3 exists to pull it forward.
- ⛔ Re-writing a prose spec for the Nth similar instance instead of extracting a schema (§4).
- ⛔ Specifying an unconfirmed frame — precise answer, wrong question (Input contract).
- ⛔ Freezing a spec item then editing it later without routing through the owning gate (→ `saaradhi-change-control`).

## Provenance and maintenance

Worked examples are on-disk artifacts [EXECUTED 2026-07-04]: `ARCHITECTURE_VISION.md` §4/§6; `schema/v0.1/bundle-config.template.yaml`; the ≤5-day-vs-baseline concurrency resolution and its Gate-3 command in `.claude/skills/first-client-campaign/SKILL.md` (§Phases 3–4). The six-slot skeleton, the falsifiability move, the conflict-resolution procedure, and the review gate are the genesis session's distilled spec-writing behavior — [CANDIDATE — verify on first downstream run]: the first Opus/Sonnet session that writes a spec with this skill should record whether a cold reader could write the acceptance test from it (per `USING-SDLC-SKILLS.md`, when present). Re-verify examples exist: `grep -n "no deployment ships without a baseline" ARCHITECTURE_VISION.md`; `grep -n "REQUIRED" schema/v0.1/bundle-config.template.yaml`. Schema-versioning rules are owned by `saaradhi-change-control` §3 — this skill links them, does not maintain them. Last updated: 2026-07-05.
