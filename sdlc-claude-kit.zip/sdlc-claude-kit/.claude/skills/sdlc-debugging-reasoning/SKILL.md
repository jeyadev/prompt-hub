---
name: sdlc-debugging-reasoning
description: >-
  Load the MOMENT a bug or unexplained behavior appears — BEFORE restarting, redeploying, or
  editing anything — and follow it through to a register entry. Triggers: "why is this failing",
  "this worked yesterday", "weird error", "404 / timeout / it broke again", a test fails with no
  visible cause, two things show the same symptom, "it went away on its own", or any fix about to
  ship without a stated root cause. The scientific method for bugs as numbered gates: capture the
  symptom verbatim → grep the known-traps register → enumerate candidate causes (differential
  diagnosis) → run the cheapest DISCRIMINATING probe with a written prediction → accept only the
  ONE mechanism that explains ALL observations → chase what the bug corrupted while live → ACCRUE
  a register entry. Does NOT cover live-incident procedure, severity, or client comms
  (→ saaradhi-run-and-operate) or fixing measurement/instrumentation gaps
  (→ diagnostics-and-instrumentation).
---

# Debugging reasoning — the scientific method for bugs

**Mechanism.** Cheap sessions debug by pattern-match: see a symptom, recall the most familiar cause, apply its fix, restart, hope. Frontier sessions debug by elimination: freeze the evidence, enumerate rival causes, run the probe that *tells them apart*, and accept only a mechanism that explains everything — including the timeline and the things that still work. This skill turns that into seven numbered gates a Sonnet-class session can run. It is project-agnostic; every worked example is an on-disk artifact of this repo (never invent history — `AUTHORING.md` provenance rule).

**This skill does NOT cover:** live-incident *procedure* — severity levels, first-15-minutes checklist, founder escalation, client comms → `saaradhi-run-and-operate` (its evidence-before-restart rule is Gate 1 here, generalized). Diagnosing or repairing the *measurement layer* (empty funnels, dead loggers) → `diagnostics-and-instrumentation` (whose Part-4 tree is this skill's worked triage-tree instance).

## When NOT to use this skill

| Situation | Use instead |
|---|---|
| A live client is down and you need the response *procedure* (who, what order, comms) | `saaradhi-run-and-operate` — it routes back here for the reasoning between its steps |
| "No events / empty funnel" — the measurement itself is the suspect | `diagnostics-and-instrumentation` Part 4 (a pre-built tree; walk it before reasoning from scratch) |
| Judging whether a *change improved a metric* (not whether something is broken) | `saaradhi-methodology` — experiment discipline, not debugging |
| General adversarial review of a non-debugging draft | `sdlc-self-critique-loop` — this skill is its debugging specialization; the Disambiguator and Consequence-Chaser live there |
| A broken dev environment with a known setup fix | `saaradhi-build-and-env` — but run Gate 2 (register CHECK) first; the trap may already be recorded |

---

## The seven gates (in order; each has a pass/fail condition)

### Gate 1 — Freeze the evidence before touching anything

The failing state you are looking at IS the evidence. A restart, redeploy, cache-clear, or "quick fix attempt" destroys it, and you cannot diagnose what no longer exists.

Record, verbatim, before ANY intervention:
1. **The exact error text** — copy-paste, never paraphrase. The literal string is the grep key for Gate 2 and the Symptom field for Gate 7.
2. **When it started** — first bad occurrence, last known-good occurrence. The timeline is a constraint every candidate mechanism must satisfy (Gate 5).
3. **What changed** in that window — deploys, config edits, upgrades, credential rotations, "nothing" (write "nothing identified", not nothing).
4. **Does it reproduce?** — same input, same failure? Intermittent changes the candidate list.

This is the general form of `saaradhi-run-and-operate` §5's rule for live incidents ("capture evidence BEFORE restarting anything" — failing execution IDs, node input/output, exact error text, timestamps). For non-incident debugging the same rule applies to logs, failing test output, and process state.

**Gate: FAIL if you cannot paste the exact error string and state the last-known-good time.** "It's giving some kind of 404" fails; `404 - No workspace here` passes.

### Gate 2 — CHECK the register first (30 seconds that saves hours)

Before forming any hypothesis, grep the known-traps register by symptom — someone may have already fought this bug:

```bash
grep -n -i -B 1 -A 7 "<symptom keyword>" docs/known-traps.md
```

Literal error string first (`"No workspace here"`, `error 2047`), then loosen to the component name. Full ritual, multi-keyword variants, and the PowerShell form: `known-traps-register` §2. [EXECUTED 2026-07-05 — re-run against the 18-entry register; the 404 grep returns both T-002 and T-003 with their mitigations.]

A hit ends the session early: apply the mitigation, update the entry's Last-confirmed date, done. No hit means nothing — the register is young; **absence of an entry is not evidence of safety** (`known-traps-register` youth warning). Proceed to Gate 3.

**Gate: FAIL if you started probing or theorizing before running this grep.**

### Gate 3 — Differential diagnosis: enumerate causes BEFORE probing

One observable, multiple possible causes — always. Write **at least two candidate causes** for the symptom before running any probe. The named failure mode this gate exists to block is **first-familiar-cause lock-in**: pattern-matching the symptom to the cause you've seen most recently and spending the session confirming it.

> **Worked example [EXECUTED 2026-07-04]** — two 404s from two n8n URLs, same HTTP status, different diseases (`docs/known-traps.md` T-002/T-003; `docs/n8n-integration.md` §0):
> - `404 page not found` (bare reverse-proxy body) from `n8n.srv1121232.hstgr.cloud` → **wrong hostname** — a stale URL, the instance was never there. Fix: correct `N8N_BASE_URL` from `.mcp.json`.
> - `404 - No workspace here` from `eilaqureshi.app.n8n.cloud` → **hibernated n8n Cloud workspace** — right URL, sleeping instance. Fix: log in and wake it.
>
> A session that pattern-matched "404 = instance down" would have "fixed" an outage that didn't exist. The candidate list {wrong URL, instance down, workspace hibernated} plus one discriminating probe each (read the response *body*, not just the status code) produced two different root causes and two different fixes in minutes.

For each candidate, note what evidence you *already hold* (Gate 1) that fits or strains it. A candidate contradicted by evidence you already captured is eliminated for free.

**Gate: FAIL with fewer than two written candidates, or if any candidate is already contradicted by captured evidence and still on the list.**

### Gate 4 — Design the DISCRIMINATING probe, predict its outcome, then run it

For your top candidates, design the probe whose **outcome differs depending on which hypothesis is true**. A probe that returns the same result under both hypotheses is confirmation theater, however satisfying it feels to run.

Procedure:
1. For each pair of live candidates, write: "If H1, probe P returns X. If H2, it returns Y." X ≠ Y or P is not discriminating — design a different probe.
2. **Write the predicted outcomes BEFORE running.** A prediction made after seeing the result is a story (same rule as `saaradhi-methodology` Discipline A: no claim without a prediction that predates the data).
3. **Order probes cheapest-first**: a file read or one curl before a bisect; a bisect before an environment rebuild. The cheapest probe that discriminates is the right next move — not the most thorough one, not the one that confirms your favorite.
4. Run. Result eliminates at least one candidate — record which, and why. A result matching *no* prediction is a new observation: back to Gate 3 with an updated candidate list.

In the Gate-3 example the discriminating probe was reading the 404 **response body**: bare proxy text predicts "nothing routed at this hostname" (wrong URL); `No workspace here` predicts "n8n Cloud knows this hostname but the workspace is asleep" (hibernation). One cheap observation each, and the rival hypothesis died.

**Gate: FAIL if the probe's predicted outcome is identical under two live hypotheses, or if predictions were written after seeing results.**

### Gate 5 — The one-mechanism rule: the cause must explain ALL observations

Before writing "root cause:", check the proposed mechanism against **every** observation from Gate 1:

- [ ] The exact error text — would this mechanism produce *these words*, not just "an error"?
- [ ] **The timeline** — does it explain why the failure started WHEN it started (and not earlier)? A mechanism that "was always true" cannot alone explain a failure that began Tuesday.
- [ ] **The negatives** — does it permit everything that still works? If your mechanism would also break X, and X works, the mechanism is wrong or incomplete.
- [ ] Reproducibility — does it predict the observed always/intermittent behavior?

If one observation doesn't fit, the mechanism is wrong or incomplete; "mostly explains it" is the named failure mode (cherry-picking). If you need a *second, unrelated* mechanism to explain away a leftover observation, you have not found the root cause. Full treatment with worked example: `saaradhi-methodology` Discipline B; compressed form: `sdlc-self-critique-loop` "one-mechanism rule".

**Gate: FAIL if any Gate-1 observation is unexplained or waved off. Write the sentence connecting the mechanism to each observation — including the awkward one.**

### Gate 6 — Consequence-chase: what did the bug corrupt while it was live?

Root cause found and fixed is not done. The bug had a *past*: how long was the wrong state live, what did it touch in that window, and is any of that damage still sitting there? Run `sdlc-self-critique-loop` adversary 2 (the Consequence-Chaser) on your fix — this skill does not re-teach it.

The canonical warning is trap T-018 [EXECUTED 2026-07-04, `docs/known-traps.md`]: a broken `.gitignore` pattern was found and fixed — but the chase question "so was the secret committed while it was broken?" found live API keys already in two commits, forcing a history rewrite and key rotation. The fix without the chase would have closed the ticket and left credentials in history forever.

**Gate: FAIL if the fix ships without a written answer to "what did this corrupt while live?" — even when the answer is "checked commits/logs/sent-messages in the window; blast radius zero."**

### Gate 7 — ACCRUE: the solved bug becomes a register entry

An unrecorded fix will be re-fought at full price by the next session. Every solved nontrivial bug ends with an entry in `docs/known-traps.md` — symptom (verbatim, grep-ready) → root cause → mitigation → evidence label → status. Format and rules: `known-traps-register` §1/§3. Next free ID:

```bash
grep -o "T-[0-9]\{3\}" docs/known-traps.md | sort -u | tail -1
```

[EXECUTED 2026-07-05 — returns `T-018`; entry count 18.] If a Gate-2 hit proved stale or incomplete, fixing that entry is the same ritual. A debugging session that produced neither a new entry nor an updated one is not closed (`saaradhi-run-and-operate` §5 makes this binding for incidents; this skill makes it binding for every nontrivial bug).

**Gate: FAIL if the session ends with no register write (new entry, or updated Last-confirmed/mitigation on an existing one).**

---

## Building a triage tree (template + worked instance)

When one symptom class recurs ("service unreachable", "no events logged", "payment stuck"), pre-compile Gates 3–4 into a tree so the next session walks probes instead of re-deriving them. Rules for a good tree:

- **Nodes are PROBES, not causes** — each node is a command/observation with branching outcomes.
- **Every branch discriminates** — each outcome eliminates at least one cause family.
- **Ordered cheapest-first** — `ls` before an API call, an API call before a rebuild.
- **Every leaf names a cause + the owner of the fix** (the sibling skill, the config, the vendor) — a leaf that ends in "investigate more" is an unfinished tree.
- **Stop at the first hit**; the tree is walked, not read.

Template:

```
<SYMPTOM CLASS — one observable, quoted the way an operator would report it>
│
├─ 1. <cheapest existence/reachability probe — exact command>
│     ├─ outcome A → <cause family> → <fix / owning skill>
│     └─ outcome B → continue
├─ 2. <next-cheapest probe discriminating the remaining causes>
│     ├─ ...
└─ N. <most expensive probe last>
      └─ still unexplained → escalate (time-box rule below) — do NOT loop back to node 1
```

**Worked instance** — the "no events logged" tree in `diagnostics-and-instrumentation` Part 4 follows exactly this shape: probe 1 `ls` the log file (free — splits "never logged" from "logged outside the window"); probe 2 does the flow call the logger at all; probe 3 re-run the exact event by hand to expose silent `REJECTED`s; probe 4 `ls clients/*/logs/` for a client-id mismatch; probe 5 (most expensive last) inspect n8n executions via the API. Five probes, each discriminating, cheapest-first, every leaf naming a cause and its owning skill. Build yours the same way and file it in the skill that owns the symptom's subsystem.

---

## Time-box and escalation

**Two full hypothesis cycles** (Gate 3 candidates → Gate 4 probes → Gate 5 mechanism attempt) **with no mechanism that survives Gate 5 → escalate** to a stronger model or human, per `sdlc-model-elevation-protocol` E1; if you catch yourself re-reading the same logs or re-running variants of the same probe a third time, that is E4 loop detection — same exit.

The escalation message states three things, all from your Gate records: **what you observed** (verbatim symptoms + timeline), **what you tried** (each probe with its predicted and actual outcome), **what you ruled out** (each dead hypothesis and the evidence that killed it). That message is a *deliverable* — it lets the stronger session start at your frontier instead of at zero. Escalation is a success state of this protocol; a symptom-patch shipped to avoid escalating is the failure.

---

## Anti-patterns (fenced)

- ⛔ **Fixing the symptom without a mechanism** — retry-wrapping, catch-and-swallow, widening a timeout because it "helps". The bug is still there; you have only made it invisible and intermittent.
- ⛔ **Restart-first debugging** — restarting before Gate 1 destroys the evidence. A restart is a *fix*, applied after diagnosis: "launch Docker Desktop and wait" is correct for T-001 only because the mechanism (engine not running, pipe error `open //./pipe/dockerDesktopLinuxEngine`) was established first.
- ⛔ **Two variables per experiment** — change one thing per probe or the outcome attributes to neither (the debugging form of `saaradhi-methodology` hard rule 4: one change per window).
- ⛔ **Confirmation probing** — running the check that passes under your favorite hypothesis *and* under its rival, then claiming support. If the predicted outcomes don't differ, it is not evidence (Gate 4).
- ⛔ **"It went away" as a close state** — it didn't; you lost the reproduction. An unexplained disappearance is status **OPEN-RECURRING**, recorded in the register with what was observed and what was NOT explained — never silently dropped, never marked resolved.

---

## Provenance and maintenance

- Worked examples are all on-disk artifacts: traps T-001/T-002/T-003/T-018 (`docs/known-traps.md`), `docs/n8n-integration.md` §0, the Part-4 tree in `diagnostics-and-instrumentation`, the evidence-before-restart rule in `saaradhi-run-and-operate` §5 — [EXECUTED 2026-07-04] per the genesis log in `.claude/skills/AUTHORING.md`. No other history exists and none is claimed.
- Register commands re-verified this session [EXECUTED 2026-07-05]: the Gate-2 grep returns T-002 and T-003 for the 404 symptoms; the Gate-7 ID command returns `T-018`; `grep -c "^### T-" docs/known-traps.md` → 18, matching the register header.
- The seven-gate procedure is the distilled debugging behavior of the genesis session; its transfer effectiveness to Opus/Sonnet sessions is [CANDIDATE — verify on first downstream run]: the first real debugging session run under this skill should record gates passed/failed, whether Gate 2 or Gate 4 shortened the session, and any escalation fired (record per `USING-SDLC-SKILLS.md`).
- Re-verify examples still resolve: `grep -c "^### T-" docs/known-traps.md` (expect ≥18) · `grep -l "No workspace here" docs/known-traps.md` · `grep -n "capture evidence BEFORE restarting" .claude/skills/saaradhi-run-and-operate/SKILL.md`.
- Cross-references: `known-traps-register` · `diagnostics-and-instrumentation` · `saaradhi-run-and-operate` · `saaradhi-methodology` · `sdlc-self-critique-loop` · `sdlc-model-elevation-protocol` · `saaradhi-build-and-env`.
- Last updated: **2026-07-05**.
