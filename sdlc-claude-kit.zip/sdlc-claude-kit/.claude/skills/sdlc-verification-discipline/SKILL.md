---
name: sdlc-verification-discipline
description: >-
  Load BEFORE claiming any build, fix, or change is done — to design verification that catches its
  own failure and attach real evidence to the word "done". Covers: writing acceptance criteria +
  EXPECTED numbers before building (predicted-vs-observed); the verification pyramid and the rule
  "verify at the highest level the change can affect"; trust-disk-not-memory (probe state, don't
  recall it); making silence impossible (empty ≠ pass); surprise-is-information (a mismatch stops
  shipment). Does NOT cover metric-lift experiments (→ saaradhi-methodology), the adversarial
  critique of a draft's REASONING (→ sdlc-self-critique-loop), or WHAT earns a test
  (→ sdlc-testing-and-qa-reasoning) — this skill proves that one specific change works. Trigger
  phrases: "is it done", "verify this", "did it actually work", "prove it", "ship it",
  "mark complete", "looks good to me", "should be fine now".
---

# Verification discipline — measure, never eyeball

**Mechanism.** Cheap sessions declare done when the code *looks* right; frontier sessions declare done only when a command they wrote in advance prints the number they predicted. This skill is the full-depth treatment of `sdlc-model-elevation-protocol` Stage 5: how to design verification so it cannot rubber-stamp a broken change, and what evidence a "done" claim must carry. It is project-agnostic; where it needs a worked example it cites an on-disk artifact in this repo.

## When NOT to use (load the sibling instead)

| If the real question is… | Use instead |
|---|---|
| Did a change move a business/product METRIC (funnel, conversion, latency baseline)? | metric measurement → `diagnostics-and-instrumentation` (project) or your project's equivalent |
| Is a metric-improvement CLAIM real (prediction-before-data, one-mechanism, refutation)? | experiment discipline → `saaradhi-methodology` |
| Is the DRAFT's reasoning sound — did I merge two facts, cherry-pick, miss a falsifier? | self-critique of drafts → `sdlc-self-critique-loop` |
| WHAT deserves a test, and is a test strong enough to trust? | `sdlc-testing-and-qa-reasoning` |
| Is the correct-but-is-it-GOOD judgment (polish, taste)? | `sdlc-quality-bar-and-taste` |

Boundary in one line: this skill proves **a specific change does what it was supposed to**; the metric skills prove **the deployment is succeeding**. Different questions, different evidence.

## 1. Acceptance criteria + expected numbers BEFORE building (pass/fail)

Write down, before the first line of the change: the criterion, the exact command that checks it, and the number/state you EXPECT it to print. Predicting the observation first is what turns verification from a rubber stamp into a test — you cannot rationalize a surprise you already committed to a prediction about.

- **Gate:** if you cannot write the verification command *and its expected output* now, the plan is not concrete — stop and make it concrete. (Same gate as elevation Stage 1.4.)
- For FULL-depth changes, keep a **predicted-vs-observed table**: one row per check, prediction filled before running, observed filled after, verdict per row.

Worked precedent [EXECUTED 2026-07-04]: `saaradhi-methodology` Discipline A refuses to run any experiment until direction + magnitude + falsifier are written down first (`.claude/skills/saaradhi-methodology/SKILL.md` §1); the same skill's Hard Rule 2 makes the predicted-vs-observed table mandatory in every closure. The genesis authoring voice generalizes it below the experiment level: every command in a runbook is written "Run X. Expect Y. If Z instead → …" (`.claude/skills/AUTHORING.md` §"Audience and voice"). Prediction-first is the house style, not just an experiment rule.

## 2. The verification pyramid — verify at the highest level the change can affect

Each level proves strictly more than the one below and costs more. **Verify at the highest level your change can reach; a lower-level pass reported as if it were a higher one is the most common false "done".**

| Level | Proves | Does NOT prove |
|---|---|---|
| 0 · parse / typecheck / lint / schema-valid | the artifact is well-formed | that it does the right thing |
| 1 · unit | a component behaves on the inputs you chose | that the pieces work together |
| 2 · end-to-end drive of the REAL flow | the real path produces the real effect | that it moved the outcome at scale |
| 3 · the metric in production | the outcome actually moved | (→ `saaradhi-methodology` / diagnostics — out of scope here) |

A change to product source always has a runtime surface (Level 2); typechecking it is Level 0 and is not verification of the change. Route Level 3 out to the metric skills — this skill stops at Level 2.

Worked example [EXECUTED 2026-07-04]: `python evals/harness/run_evals.py` → "8/8 golden files structurally valid", exit 0 (`evals/harness/run_evals.py`). That is a **Level 0** structural check — the goldens are well-formed. `validation-and-qa` states the boundary explicitly ("golden-pass ≠ shipped"): stage-2 replay against a live agent (Level 2) does not exist yet. Reporting the green stage-1 run as "the agent works" would be a pyramid-level lie. Verify at the level your change can affect, and name the level you reached.

## 3. Design verification so silence can't pass (empty ≠ pass)

The dangerous failure is the one that returns success by doing nothing. Build the check so that the absent, the empty, and the skipped are **loud failures**, not quiet zeros. This is the constructive procedure behind `sdlc-quality-bar-and-taste` signature 10 (which only flags its absence).

- **No inputs → non-zero exit, not clean pass.** Worked example [EXECUTED 2026-07-04]: `run_evals.py` on an empty corpus prints "NO GOLDEN CONVERSATIONS … this is exit 2, not a pass" and returns **2**, distinct from both pass (0) and failure (1) (`evals/harness/run_evals.py:59-61`). A suite that returns 0 when it found nothing to run is worse than no suite.
- **Destructive ops refuse by default.** `onboard.py` on an existing client dir → "REFUSING … already exists", exit 1 (`scripts/onboard.py:50-51`) [EXECUTED 2026-07-04].
- **Invariants enforced in code, not prose.** `funnel_logger.py` rejects a raw `+91…` phone number with exit 1 (PII guard, invariant 6) rather than trusting callers to remember (`scripts/funnel_logger.py:52-55`) [EXECUTED 2026-07-04].

Gate: for every verification you add, ask "what does this print when the thing it checks is *missing entirely*?" If the answer is "pass", redesign it.

## 4. Trust disk, not memory

Before asserting a file, record, or state exists, **probe it** — `ls`, `wc -l`, `grep -c`, a status read — never claim it from recollection. An agent's belief about its own prior output is unreliable in both directions.

Worked example [EXECUTED 2026-07-04]: during the genesis session's interrupted multi-agent fan-out, the traps register was *believed* absent, and was confirmed absent by a `glob` before re-authoring — files thought complete were partial and vice versa (`multi-agent-orchestration` §5; trap T-008 mitigation in `docs/known-traps.md`). The probe is cents; the wrong-memory claim is a corrupted deliverable.

## 5. Surprise is information — a mismatch stops shipment until explained

Run the check, compare to your prediction. Any mismatch — even a "better" one — **halts the done-claim until a mechanism explains it**. A surprise in verification is not noise to smooth over; it is the check telling you your model of the change is wrong.

Worked example [EXECUTED 2026-07-04]: the Refuter's one-curl check on the fallback n8n instance predicted "available", observed `404 - No workspace here` (hibernated). The mismatch was not waved away — it corrected a live architecture assumption (`docs/n8n-integration.md` §0; `sdlc-self-critique-loop` §1, trap T-003). Contrast the anti-pattern named in `sdlc-quality-bar-and-taste` signature 8: reporting "mostly works" over a surprise instead of stopping to explain it.

## The done gate (pass/fail)

**No "done" claim ships without the verification command's actual output attached**, at the highest pyramid level the change could affect, with any surprise explained. "Done", "should be fine", "looks good" with no pasted evidence fails this gate. Report format: outcome first → command + real output → level reached → anything still unverified, labeled.

## Provenance and maintenance

Worked examples are on-disk artifacts [EXECUTED 2026-07-04 during genesis]: `evals/harness/run_evals.py` (exit 2 / 8-of-8), `scripts/onboard.py:50` (overwrite refusal), `scripts/funnel_logger.py:52` (PII guard), `docs/n8n-integration.md` §0 + trap T-003 (surprise), trap T-008 + `multi-agent-orchestration` §5 (trust-disk), `saaradhi-methodology` §1 + `AUTHORING.md` voice (predict-first). The procedure itself — the pyramid, the four rules, the done gate — is the distilled genesis practice; its transfer effectiveness to Opus/Sonnet sessions is [CANDIDATE — verify on first downstream run]: the first session using it should record whether a "done" was caught at the gate (log per `USING-SDLC-SKILLS.md`). Re-verify examples: `python evals/harness/run_evals.py` on an empty temp dir → exit 2; `grep -n "reference_id" scripts/funnel_logger.py`. Last updated: 2026-07-05.
