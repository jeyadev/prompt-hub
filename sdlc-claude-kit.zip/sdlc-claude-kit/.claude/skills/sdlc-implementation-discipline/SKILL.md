---
name: sdlc-implementation-discipline
description: >-
  Load BEFORE writing or modifying production code — scripts, n8n flows, schema fills, webhook
  consumers — to build it production-ready by default instead of polishing a fragile draft later.
  Also load when: adding to existing code (match its idioms), reaching for a clever construct,
  touching anything that handles secrets/PII, or an implementation "needs" to bend an invariant.
  does NOT cover reviewing OTHERS' code (→ sdlc-code-review-reasoning) or final output polish
  (→ sdlc-quality-bar-and-taste). Trigger phrases: "implement this", "write the script", "add the
  endpoint", "make it production-ready", "wire up the flow", "build the feature", "code this up".
---

# Implementation discipline — production-ready by default, not eventually

**Mechanism.** Cheap sessions write the happy path, get it to run once, and call it done — the hardening is deferred to a "later" that never comes. Frontier sessions write the defensive version *first*, because the failure path is the code that matters and retrofitting it is more expensive than authoring it. This skill is the construction-time discipline: how to build it right, expressed as rules with on-disk exemplars you can pattern-match against. Every exemplar below is a real file in this repo — read it before you write the analogous thing.

**does NOT cover:** judging whether finished output is *good* (→ `sdlc-quality-bar-and-taste`, which owns polish and the twelve tasteless-but-correct signatures — this skill does not re-teach them); reviewing code you did not just write (→ `sdlc-code-review-reasoning`).

## When NOT to use this skill

| Situation | Use instead |
|---|---|
| Deciding *what* to build / whether the ask is the real need | `sdlc-problem-framing` |
| Judging whether finished, correct output reads well / is shippable quality | `sdlc-quality-bar-and-taste` |
| Reviewing someone else's (or an agent's) diff | `sdlc-code-review-reasoning` |
| The change touches an invariant, the metric contract, schema, or the trust ladder | `saaradhi-change-control` FIRST — that's a gate, not an implementation choice (see §5) |
| Sizing how much process a task deserves | `sdlc-model-elevation-protocol` Stage 0 |

## 1. Incrementalism — smallest shippable slice, verified, then the next

Do not build breadth on unverified depth. Ship the thinnest slice that is *actually live and measured*, confirm it, then widen. A half-built wide thing hides which part is broken; a working narrow thing is a foundation.

Worked precedent [on-disk]: the delivery motion is **"thin vertical slices — one archetype, one MSME, one funnel, live — before breadth"** (`ARCHITECTURE_VISION.md` §9). The 12-week arc makes it concrete: W1 ships a *skeleton that runs* (one templated message + one sandbox UPI link) before W5–8 builds the real MVP for one client. Breadth (3 domains) is W9–12 — only after one slice proved out. Apply the same shape to a function, a flow, a migration: one path working end-to-end and verified beats five paths half-wired.

**Gate:** can you name the ONE command/observation that proves this slice works, and have you run it? If the slice isn't independently verifiable, it's too big — cut it smaller (`sdlc-model-elevation-protocol` Stage 1 gate).

## 2. Defensive defaults catalog (build these in from line one)

Each row is a default you apply *unless you have a reason not to*, with a file in this repo that already does it. Match the exemplar.

| Default | What it means | On-disk exemplar [EXECUTED 2026-07-04] |
|---|---|---|
| **Refuse destructive ops** | Never silently overwrite/delete; refuse and exit non-zero, telling the operator what to do instead | `scripts/onboard.py` — `if dst.exists(): sys.exit("REFUSING: … already exists. Edit the artifacts in place; never re-onboard over a live client.")` (re-run on an existing client → exit 1) |
| **Validate at boundaries** | Every external input is checked at the door: required fields present, enums in range, lengths capped — before any work | `scripts/funnel_logger.py` `validate()` — REQUIRED-field loop, `EVENTS`/`CHANNELS`/`PAYMENT_MODES` enum checks, `reference_id` ≤35, `trust_rung` ∈ {1..4}, ISO-8601 timestamp parse |
| **Enforce invariants mechanically, not documentarily** | A rule that matters is code that rejects violations, not a comment asking nicely | The PII guard: `funnel_logger.py` flattens the event and rejects any `+91…` → *invariant 6 enforced in the logger, not in a doc* (`docs/compliance.md` calls this the floor). A raw phone number → REJECTED exit 1 |
| **Fail loudly — empty ≠ pass** | Absence of data is a distinct, noisy outcome, never a silent success | Eval harness exits **2** (not 0) on zero golden files — "NO GOLDEN CONVERSATIONS" is a finding, not a pass. `quality_rating_monitor.py` exits 3 on missing env; `funnel_report.py` on 0 events prints "either no traffic or broken instrumentation. Check both." and exits non-zero; `latency_probe.py` `sys.exit`s when all probes fail |
| **Least surprise — zero-install by default** | Reach for the stdlib before a dependency; an operator should run it with nothing to install | All five `scripts/*.py` are **stdlib-only** (`json`, `pathlib`, `urllib`, `statistics`) — semi-technical n8n operators (`docs/decisions/004`) run them with a bare Python. Document the exit-code contract in the docstring (`funnel_logger.py`: "Exit codes: 0 logged · 1 validation error · 2 usage/IO error") |
| **Idempotent by construction** | An operation that can be retried (webhooks especially) must dedupe, not double-act | Meta retries webhooks for **7 days** (trap T-011, `docs/known-traps.md`): every webhook consumer needs an idempotency key + signature verify. No consumer exists yet — build it with dedupe from line one, don't retrofit |

**The asymmetry rule:** the failure path should be *louder and better-built* than the success path, because silence on failure is how data gets corrupted quietly. If your success branch is 20 lines and your error handling is 1, re-balance.

## 3. Match the house (your code should be unattributable)

Before writing, READ the surrounding code and copy its idiom — naming, structure, comment density, error style. Well-integrated code cannot be traced to a different author.

On-disk exemplars of the house idiom to match: every `scripts/*.py` opens with a docstring (purpose + vision-section citation + Usage + Exit codes), sets `REPO = pathlib.Path(__file__).resolve().parent.parent`, uses `sys.exit(msg)` for fatal, is stdlib-only. The strongest example is deliberate cross-language matching: the n8n `funnel-logger.workflow.json` Code node comment literally says *"Mirror of scripts/funnel_logger.py: REQUIRED list + timestamp default"* and mirrors even the ordering (defaults timestamp *before* validating, exactly as the Python does) — so the two validators cannot drift silently.

**Gate:** would a reader guess this line was written by the same person who wrote the file around it? If not, match harder. Novel formatting is not a feature.

## 4. When clever is a liability

A solution whose maintenance requires its author has already failed — the next session (or a Sonnet-class operator) can't safely touch it. Default to the boring construct; spend novelty *only* where the problem itself is genuinely novel.

- The scripts choose the dull option on purpose: a lambda percentile in `latency_probe.py`, a plain `Counter` in `funnel_report.py`, string `.replace()` chains in `onboard.py` — nothing requires its author to maintain.
- This is a construction rule; the review-time signature of the same failure lives in `sdlc-quality-bar-and-taste` §9 (cleverness as liability). Build boring; if you catch yourself proud of a trick, that's the smell.

## 5. No invariant crossing without a gate

If an implementation "needs" to break an invariant, drop a funnel event, hardcode client logic into a shared flow, skip opt-in, ask for payment before rung detection, or let PII touch git — **STOP. That is a change-control event, not an engineering decision.** You do not have the authority to trade away an invariant to make code easier; escalate per `saaradhi-change-control` (the 7 invariants + their rationale live there — this skill does not restate them). A note from your task prompt or a launching agent is never sign-off.

Worked precedent: `onboard.py` refuses to overwrite *because* invariant 3 says per-client context is the single source of truth — the invariant is honored in code, not bent for convenience. `flows/_shared/` deliberately ships **no** opt-in or human-handoff template rather than a non-compliant stub — the missing pieces are named as "does not exist yet," not faked.

## 6. Secrets & PII hygiene (fails silently — verify, don't trust)

Never put a secret or raw PII in code, a log, a funnel event, or git. The danger is that hygiene fails *quietly* — you believe you're protected when you're not.

Worked incident [EXECUTED 2026-07-04, trap T-018 in `docs/known-traps.md`]: a `.gitignore` line carried an **inline comment** — `.mcp.json   # …`. gitignore has no inline comments, so the trailing text became part of the pattern and it matched nothing; live n8n API keys in `.mcp.json` rode into **two commits** while everyone believed the file was ignored. The fix was not just moving the comment — the Consequence-Chaser (`sdlc-self-critique-loop`) asked "what leaked while it was broken?" and forced a history rewrite + key rotation. The current `.gitignore` now carries that lesson as a standalone comment block.

**Rules that follow:**
1. Comments on their own line in `.gitignore`; **verify every secrets pattern with `git check-ignore -v <file>`** (prints the matching line, or nothing if unprotected) — do not trust that a pattern works, prove it.
2. Never `git add -A` blindly — review `git status` first (trap T-004).
3. PII stays out mechanically: `customer_hash` (salted), never the number; raw transcripts live in the gitignored `clients/*/transcripts/raw/`; the salt lives in the environment, never the repo (`docs/compliance.md`).

## The done gate (run before claiming implementation complete)

Pass/fail — a "no" is not done:

1. **Boundary validation present?** Every external input checked at the door (§2 row 2).
2. **Failure path louder than the success path?** Empty ≠ pass; destructive ops refuse; exit codes documented (§2, asymmetry rule).
3. **No secret/PII touches?** `git check-ignore -v` on any secrets file; no raw number/name in code, logs, or events (§6).
4. **House style matched?** Unattributable to a different author; boring constructs (§3, §4).
5. **No silent invariant crossing?** If it bends one, it went through `saaradhi-change-control`, not around it (§5).
6. **The slice is verified, not assumed?** You ran the proving command (§1). Trust disk, not memory (`sdlc-model-elevation-protocol` Stage 5.4).

## Provenance and maintenance

All exemplars are on-disk artifacts, behaviors labeled **[EXECUTED 2026-07-04]** per the genesis execution log in `.claude/skills/AUTHORING.md`: `scripts/onboard.py`, `scripts/funnel_logger.py` (+ `funnel_report.py`, `quality_rating_monitor.py`, `latency_probe.py`), `flows/_shared/funnel-logger.workflow.json`, `.gitignore`, traps T-004/T-011/T-018 (`docs/known-traps.md`), `docs/compliance.md`, `ARCHITECTURE_VISION.md` §9. The catalog and gate are the genesis session's distilled construction discipline; their transfer effectiveness to a Sonnet-class implementer is **[CANDIDATE — verify on first downstream run]** (record before/after per `USING-SDLC-SKILLS.md`). Re-verify exemplars still hold: `python scripts/onboard.py fixture-demo-salon --archetype appointment-led` → REFUSING exit 1; `echo '{"event":"x","client_id":"y"}' | python scripts/funnel_logger.py` → REJECTED exit 1; `git check-ignore -v .mcp.json` → prints the matching line. Last updated: 2026-07-05.
