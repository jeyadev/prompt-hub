# CDS Exception Monitor — Implementation Specification

> **Purpose**: This is the canonical spec file for AI-assisted development. Feed this to GitHub Copilot (Claude Opus 4.6 / Sonnet) as project context. Every file, function signature, type, and behavior is defined here. The AI should implement FROM this spec, not invent architecture.

> **Owner**: Jey (VP SRE, JPMC — Asset & Wealth Management, Shared Services)
> **Scope**: Daily proactive exception monitoring for CDS platform — 12 services, 100+ APIs
> **Build target**: 5 days to working app via vibe coding

---

## 0. WHAT THIS IS AND ISN'T

### What it IS
A daily exception monitoring tool that:
1. Connects to **Splunk MCP** to fetch all exceptions/errors across CDS services for the day
2. Aggregates and groups exceptions by type, module, service, and frequency
3. Connects to a **Domain MCP** (CDS knowledge base files) to map exceptions to CDS modules and retrieve context (what the module does, known issues, dependencies, remediation history)
4. Feeds aggregated exceptions + domain context to an **LLM (Claude)** for correlation analysis — grouping related exceptions, identifying root cause hypotheses, separating known vs novel patterns, and ranking by priority
5. Displays results in a **single HTML dashboard** — the daily exception report

### What it ISN'T
- Not a real-time alerting system (runs on-demand or scheduled, not streaming)
- Not AEGIS (no agent execution, no runbooks, no approval gates, no remediation)
- Not a replacement for Splunk dashboards (this is the AI-enriched analysis layer on top)
- Not a ticketing system (though it can recommend ticket creation)

### How it relates to AEGIS
This is a **standalone tool** that delivers immediate value independently. It maps to AEGIS H3 Module M6 (Exception Pattern Monitor) from the roadmap. If AEGIS matures, this can become a data source for the AEGIS Strategist. But it ships and runs on its own.

### The value proposition (2-sentence pitch for Kunal)
"Instead of our SREs manually checking Splunk every morning for exceptions they might have missed, this tool automatically pulls every exception across all 12 CDS services, maps them to our modules using our own knowledge base, and uses AI to correlate related errors and surface what actually needs attention — with context and suggested next steps. It turns a 30-minute daily ritual into a 2-minute dashboard scan."

---

## 1. ARCHITECTURE OVERVIEW

```
┌─────────────────────────────────────────────────────────────┐
│                    CDS Exception Monitor                     │
│                                                              │
│  ┌──────────┐    ┌──────────────┐    ┌───────────────────┐  │
│  │ Splunk   │    │  Domain MCP  │    │  Claude API       │  │
│  │ MCP      │    │  (CDS KB)    │    │  (Correlation)    │  │
│  │          │    │              │    │                   │  │
│  │ Fetches  │    │ Module info  │    │ Groups related    │  │
│  │ errors & │    │ Dependencies │    │ Root cause hyp.   │  │
│  │ exceptions│   │ Known issues │    │ Priority ranking  │  │
│  │ for day  │    │ Remediation  │    │ Known vs novel    │  │
│  └────┬─────┘    └──────┬───────┘    └────────┬──────────┘  │
│       │                 │                      │             │
│       ▼                 ▼                      ▼             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              Orchestrator (main.py)                   │   │
│  │                                                       │   │
│  │  1. Fetch exceptions from Splunk                      │   │
│  │  2. Parse & aggregate by module/type/count            │   │
│  │  3. Enrich with domain context from KB                │   │
│  │  4. Send to LLM for correlation analysis              │   │
│  │  5. Generate HTML report                              │   │
│  └──────────────────────┬───────────────────────────────┘   │
│                         │                                    │
│                         ▼                                    │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              HTML Dashboard (report.html)             │   │
│  │                                                       │   │
│  │  • Executive summary (total exceptions, top modules)  │   │
│  │  • Correlated exception groups with root cause hyp.   │   │
│  │  • Known vs novel pattern breakdown                   │   │
│  │  • Module-level drill-down                            │   │
│  │  • Recommended actions + ticket suggestions           │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

### Why this architecture

**Two MCP servers, not direct API calls** — Splunk MCP is already tested from AEGIS work. Domain MCP provides structured access to CDS knowledge base files. Both use SID-based auth from VDI. Reusing the MCP pattern means the same client pool code from AEGIS works here.

**LLM for correlation, not for extraction** — Splunk handles the data extraction (it's better at structured queries). The LLM's job is the part humans are good at but slow at: seeing patterns across 50+ distinct exception types and correlating them into "these 12 exceptions are all caused by the same downstream timeout."

**Single HTML output, not a React app** — This is a daily report, not a real-time dashboard. One HTML file that opens in a browser. No build step, no npm, no React. Python generates HTML from a Jinja2 template. This keeps the build time under 5 days.

**Deterministic fingerprinting BEFORE LLM** — The spec enforces a principle from our earlier research: rule-based classification first (exception type, module, count threshold), then LLM enrichment on top. The LLM never sees raw logs — it sees pre-aggregated, structured data. This keeps costs low and responses fast.

---

## 2. FILE STRUCTURE

```
cds-exception-monitor/
├── config.py                  # All configuration — Splunk queries, paths, thresholds
├── models.py                  # Pydantic models for exceptions, modules, reports
├── mcp_client.py              # MCP client — connects to Splunk + Domain MCP servers
├── splunk_fetcher.py          # Splunk query execution + response parsing
├── domain_enricher.py         # Domain MCP queries + module context mapping
├── aggregator.py              # Exception grouping, dedup, fingerprinting
├── correlator.py              # LLM correlation engine — Claude API call
├── report_generator.py        # Jinja2 HTML report generation
├── main.py                    # Orchestrator — ties everything together
├── templates/
│   └── report.html.j2         # Jinja2 template for the HTML dashboard
├── output/                    # Generated reports land here
│   └── report_2026-04-02.html
├── mcp.json                   # MCP server config (copied from DevGPT/Cline)
├── prompts/
│   └── correlator_system.md   # System prompt for the LLM correlator
│   └── correlator_user.md     # User prompt template (exception data injected here)
├── known_patterns/
│   └── known_exceptions.json  # Curated list of known exception patterns + remediation
└── requirements.txt           # Python dependencies
```

**10 Python files. One template. One prompt. One known-patterns file.** That's it.

---

## 3. CONFIGURATION — `config.py`

```python
"""
CDS Exception Monitor — Configuration

All tunable parameters live here. Nothing is hardcoded in other files.
Copilot: implement this exactly. Do not scatter config across files.
"""

from pydantic_settings import BaseSettings
from pathlib import Path
from typing import Optional


class Settings(BaseSettings):
    """All configuration loaded from environment variables with sensible defaults."""

    # ── Paths ──
    project_root: Path = Path(__file__).parent
    output_dir: Path = Path(__file__).parent / "output"
    templates_dir: Path = Path(__file__).parent / "templates"
    prompts_dir: Path = Path(__file__).parent / "prompts"
    known_patterns_file: Path = Path(__file__).parent / "known_patterns" / "known_exceptions.json"
    mcp_config_path: Path = Path(__file__).parent / "mcp.json"

    # ── Splunk Configuration ──
    # These are parameterized — Jey fills in the actual values for his environment
    splunk_index: str = "FILL_IN"                        # e.g., "app_cds" or "cds_prod"
    splunk_source_filter: str = ""                       # e.g., "source=cds-*" — optional additional filter
    splunk_error_levels: str = "ERROR OR FATAL OR EXCEPTION"  # SPL filter for log levels
    splunk_time_range: str = "-24h@h"                    # Default: last 24 hours
    splunk_max_results: int = 10000                      # Max events to pull
    splunk_mcp_server_name: str = "splunk"               # Key in mcp.json

    # ── Splunk Field Mapping ──
    # Maps Splunk log fields to our internal model. Jey adjusts these to match
    # actual CDS log format. These are the field names IN SPLUNK.
    splunk_field_time: str = "_time"
    splunk_field_level: str = "level"                    # or "log_level", "severity"
    splunk_field_source: str = "source"                  # service/app identifier
    splunk_field_logger: str = "logger"                  # Java logger name — maps to module
    splunk_field_exception_class: str = "exception_class"  # e.g., "java.lang.NullPointerException"
    splunk_field_message: str = "message"                # log message
    splunk_field_stack_trace: str = "stack_trace"        # stack trace (may be truncated in Splunk)
    splunk_field_host: str = "host"                      # hostname / pod name
    splunk_field_thread: str = "thread"                  # thread name (optional)
    splunk_field_trace_id: str = "trace_id"              # OTel trace ID if available

    # ── Domain MCP Configuration ──
    domain_mcp_server_name: str = "domain"               # Key in mcp.json
    domain_mcp_tool_search: str = "search"               # Tool name to search KB files
    domain_mcp_tool_read: str = "read_file"              # Tool name to read a specific KB file

    # ── LLM Configuration ──
    llm_model: str = "claude-sonnet-4-20250514"          # Sonnet for speed. Opus for depth.
    llm_max_tokens: int = 4096
    llm_temperature: float = 0.1                         # Low temp for analytical tasks
    # Note: API key is handled via environment variable ANTHROPIC_API_KEY
    # OR via MCP proxy — no key in this file.

    # ── Aggregation Thresholds ──
    min_count_for_report: int = 1                        # Include exceptions with count >= this
    high_severity_threshold: int = 50                    # Exceptions with count > this = high severity
    critical_severity_threshold: int = 200               # Exceptions with count > this = critical
    novel_pattern_lookback_days: int = 7                 # If not seen in last N days = novel

    # ── Report Configuration ──
    report_title: str = "CDS Daily Exception Report"
    report_max_groups: int = 20                          # Max correlated groups to show
    report_max_exceptions_per_group: int = 15            # Max exceptions to list per group

    # ── MCP Client Configuration ──
    mcp_call_timeout: int = 30                           # Seconds per MCP call
    mcp_connect_timeout: int = 15                        # Seconds to establish MCP connection

    class Config:
        env_prefix = "CDS_MONITOR_"                      # All env vars prefixed: CDS_MONITOR_SPLUNK_INDEX=...
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
```

### Critical config decisions

**Why Splunk field mapping is explicit**: CDS log format is not standardized across all 12 services. Some may use `level`, others `log_level`, others `severity`. By externalizing field names, Jey can adjust per-service or set up a common alias. The spec assumes a baseline set — Jey overrides what doesn't match.

**Why known_patterns is a JSON file, not a database**: For MVP, a curated JSON file that Jey and team maintain is faster to build and easier to update than a vector store. The file contains known exception patterns with their fingerprints, descriptions, and remediation steps. This is the "deterministic before probabilistic" principle — check the known list first, then use LLM for unknowns.

---

## 4. DATA MODELS — `models.py`

```python
"""
CDS Exception Monitor — Data Models

All data structures used across the pipeline. Pydantic models for validation.
Copilot: implement these exactly. Every field has a reason.
"""

from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from enum import Enum


# ═══════════════════════════════════════════════════════════════
# ENUMS
# ═══════════════════════════════════════════════════════════════

class Severity(str, Enum):
    """Exception severity based on count thresholds from config."""
    LOW = "low"              # count < high_severity_threshold
    HIGH = "high"            # count >= high_severity_threshold
    CRITICAL = "critical"    # count >= critical_severity_threshold


class PatternStatus(str, Enum):
    """Whether this exception pattern is known or novel."""
    KNOWN = "known"          # Matches a known pattern in known_exceptions.json
    NOVEL = "novel"          # Not seen in lookback window / not in known patterns
    RECURRING = "recurring"  # Known pattern but count is abnormally high


# ═══════════════════════════════════════════════════════════════
# RAW DATA (from Splunk)
# ═══════════════════════════════════════════════════════════════

class RawException(BaseModel):
    """Single exception event as returned from Splunk. Minimal parsing."""
    timestamp: datetime
    level: str                                # ERROR, FATAL, EXCEPTION
    source: str                               # Service/app identifier from Splunk
    logger: Optional[str] = None              # Java logger name — e.g., "com.jpmc.cds.gateway.DocumentController"
    exception_class: Optional[str] = None     # e.g., "java.lang.NullPointerException"
    message: str                              # Log message
    stack_trace: Optional[str] = None         # May be truncated
    host: Optional[str] = None                # Hostname / pod name
    thread: Optional[str] = None              # Thread name
    trace_id: Optional[str] = None            # OTel trace ID if available


# ═══════════════════════════════════════════════════════════════
# AGGREGATED DATA (after grouping)
# ═══════════════════════════════════════════════════════════════

class ExceptionFingerprint(BaseModel):
    """
    Unique identity of an exception pattern. Two exceptions with the same
    fingerprint are considered "the same error."

    Fingerprint = hash(source + exception_class + top_stack_frame)

    Why these three:
    - source: which service
    - exception_class: what type of error
    - top_stack_frame: where in code (disambiguates two NPEs in different methods)
    """
    fingerprint_hash: str                     # SHA-256 of the components below
    source: str                               # Service name
    exception_class: str                      # Exception type (or "UNKNOWN" if not parsed)
    top_stack_frame: Optional[str] = None     # First non-framework line in stack trace
    message_template: Optional[str] = None    # Templatized message (variables replaced with <VAR>)


class AggregatedExceptionGroup(BaseModel):
    """
    A group of identical exceptions (same fingerprint) with aggregate stats.
    This is the primary unit of analysis.
    """
    fingerprint: ExceptionFingerprint
    count: int                                # Total occurrences in the time window
    first_seen: datetime                      # Earliest occurrence
    last_seen: datetime                       # Latest occurrence
    host_count: int                           # Number of distinct hosts affected
    hosts: list[str] = Field(default_factory=list)  # List of affected hosts (truncated to 10)
    severity: Severity = Severity.LOW         # Computed from count thresholds
    pattern_status: PatternStatus = PatternStatus.NOVEL  # Known, novel, or recurring
    sample_message: str = ""                  # One representative log message
    sample_stack_trace: Optional[str] = None  # One representative stack trace
    trace_ids: list[str] = Field(default_factory=list)   # Sample trace IDs for drill-down (max 5)
    level: str = "ERROR"                      # Predominant log level


# ═══════════════════════════════════════════════════════════════
# DOMAIN CONTEXT (from Domain MCP / CDS KB)
# ═══════════════════════════════════════════════════════════════

class ModuleContext(BaseModel):
    """
    Context about a CDS module/service retrieved from the Domain MCP.
    This is what makes the report CDS-aware rather than generic.
    """
    module_name: str                          # Human-readable module name
    source_identifier: str                    # Maps to Splunk 'source' field
    description: str = ""                     # What this module does
    dependencies: list[str] = Field(default_factory=list)  # Upstream/downstream dependencies
    known_issues: list[str] = Field(default_factory=list)  # Known operational issues
    owner_team: str = ""                      # Which team owns this module
    remediation_notes: str = ""               # General remediation guidance
    criticality: str = "standard"             # "critical", "high", "standard"


class EnrichedExceptionGroup(BaseModel):
    """
    AggregatedExceptionGroup + domain context.
    This is what gets sent to the LLM for correlation.
    """
    group: AggregatedExceptionGroup
    module_context: Optional[ModuleContext] = None  # None if no KB match found
    known_pattern_match: Optional[dict] = None      # Match from known_exceptions.json


# ═══════════════════════════════════════════════════════════════
# LLM CORRELATION OUTPUT
# ═══════════════════════════════════════════════════════════════

class CorrelatedCluster(BaseModel):
    """
    A group of related exception groups that the LLM has identified as
    likely sharing a root cause or causal chain.
    """
    cluster_id: str                           # "cluster_001", "cluster_002", etc.
    title: str                                # Human-readable title, e.g., "Pithos Connection Timeout Cascade"
    root_cause_hypothesis: str                # LLM's hypothesis for what's causing these
    confidence: str                           # "high", "medium", "low"
    impact_summary: str                       # What's the business/operational impact
    exception_fingerprints: list[str]         # Fingerprint hashes of the grouped exceptions
    total_count: int                          # Sum of all exception counts in this cluster
    affected_modules: list[str]               # Which CDS modules are involved
    recommended_actions: list[str]            # Ordered list of suggested next steps
    related_known_issues: list[str] = Field(default_factory=list)  # References to known issues from KB
    suggested_ticket: Optional[str] = None    # Suggested Jira/ServiceNow ticket summary


class CorrelationReport(BaseModel):
    """
    Full LLM correlation output. This is the structured analysis that
    gets rendered into the HTML dashboard.
    """
    generated_at: datetime
    time_range_start: datetime
    time_range_end: datetime
    total_exceptions: int                     # Total exception count for the day
    total_unique_patterns: int                # Distinct fingerprints
    total_novel_patterns: int                 # Patterns not seen before
    executive_summary: str                    # 3-5 sentence overview for leadership
    clusters: list[CorrelatedCluster]         # Correlated exception groups
    uncorrelated: list[str]                   # Fingerprint hashes the LLM couldn't group
    module_health_summary: dict[str, str]     # module_name → "healthy" / "degraded" / "impacted"
    trend_observations: list[str]             # Any notable trends vs previous days


# ═══════════════════════════════════════════════════════════════
# KNOWN PATTERN (from known_exceptions.json)
# ═══════════════════════════════════════════════════════════════

class KnownPattern(BaseModel):
    """
    Entry in the curated known_exceptions.json file.
    Deterministic matching — checked BEFORE LLM correlation.
    """
    pattern_id: str                           # Unique ID, e.g., "KP-001"
    exception_class: str                      # Regex or exact match
    message_pattern: str                      # Regex pattern to match message
    source_filter: Optional[str] = None       # Optional: only match for specific source
    description: str                          # What this error is
    root_cause: str                           # Known root cause
    remediation: str                          # Known remediation steps
    severity_override: Optional[Severity] = None  # Override computed severity if needed
    last_updated: str = ""                    # When this pattern was last reviewed
    jira_reference: Optional[str] = None      # Link to relevant Jira ticket
```

### Why these models

**ExceptionFingerprint** is the linchpin. Without consistent fingerprinting, you can't tell if 500 NullPointerExceptions are the same bug or 500 different bugs. The triple of (source, exception_class, top_stack_frame) gives you the right granularity — same exception in the same code path in the same service = same pattern.

**Separation of AggregatedExceptionGroup and EnrichedExceptionGroup** is deliberate. Aggregation happens before enrichment. If the Domain MCP is down, you still get aggregated data — just without module context. The pipeline degrades gracefully.

**KnownPattern with regex** means the team can say "any TimeoutException from cds-gateway with 'Pithos' in the message = known issue KP-012, remediation: check Pithos connection pool." Deterministic matching runs in milliseconds. The LLM only processes what's left.

---

## 5. MCP CLIENT — `mcp_client.py`

```python
"""
CDS Exception Monitor — MCP Client

Connects to Splunk MCP and Domain MCP servers using mcp.json config.
Reuses the same pattern from AEGIS — SID-based auth from VDI,
API token fallback in .env.

Copilot: implement this file. Key behaviors:
- Reads mcp.json for server configs
- Creates MCP ClientSession per server
- Provides call_tool() and list_tools() methods
- Handles timeouts and connection errors gracefully
- Logs all MCP calls for debugging
"""

import json
import asyncio
import logging
from pathlib import Path
from typing import Any, Optional
from contextlib import asynccontextmanager

# MCP SDK imports
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from config import settings

logger = logging.getLogger(__name__)


class McpClient:
    """
    Manages connections to MCP servers defined in mcp.json.

    Usage:
        client = McpClient()
        async with client.connect("splunk") as session:
            tools = await session.list_tools()
            result = await session.call_tool("search", {"query": "..."})
    """

    def __init__(self, config_path: Optional[Path] = None):
        """
        Args:
            config_path: Path to mcp.json. Defaults to settings.mcp_config_path.
        """
        self.config_path = config_path or settings.mcp_config_path
        self.server_configs: dict[str, dict] = {}
        self._load_config()

    def _load_config(self) -> None:
        """
        Load mcp.json. Expected format (from DevGPT/Cline):

        {
            "mcpServers": {
                "splunk": {
                    "command": "npx",
                    "args": ["-y", "@anthropic/splunk-mcp-server"],
                    "env": {
                        "SPLUNK_URL": "https://splunk.jpmc.internal:8089",
                        "SPLUNK_AUTH_MODE": "sid"
                    }
                },
                "domain": {
                    "command": "npx",
                    "args": ["-y", "@custom/domain-kb-mcp-server"],
                    "env": {
                        "KB_ROOT": "/path/to/cds-knowledge-base/"
                    }
                }
            }
        }

        Also supports "servers" key for alternate mcp.json formats.
        """
        with open(self.config_path) as f:
            raw = json.load(f)

        # Handle both "mcpServers" and "servers" key conventions
        self.server_configs = raw.get("mcpServers", raw.get("servers", {}))
        logger.info(f"Loaded MCP config with servers: {list(self.server_configs.keys())}")

    @asynccontextmanager
    async def connect(self, server_name: str):
        """
        Connect to a named MCP server and yield a ClientSession.

        Args:
            server_name: Key in mcp.json (e.g., "splunk", "domain")

        Yields:
            ClientSession — use for list_tools() and call_tool()

        Raises:
            KeyError: if server_name not in mcp.json
            TimeoutError: if connection takes > mcp_connect_timeout
        """
        if server_name not in self.server_configs:
            available = list(self.server_configs.keys())
            raise KeyError(f"Server '{server_name}' not in mcp.json. Available: {available}")

        cfg = self.server_configs[server_name]
        server_params = StdioServerParameters(
            command=cfg["command"],
            args=cfg.get("args", []),
            env=cfg.get("env", None),
        )

        async with asyncio.timeout(settings.mcp_connect_timeout):
            async with stdio_client(server_params) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    logger.info(f"Connected to MCP server: {server_name}")
                    yield session


async def call_tool(
    session: ClientSession,
    tool_name: str,
    arguments: dict[str, Any],
    timeout: int = None,
) -> dict:
    """
    Call an MCP tool with timeout and error handling.

    Args:
        session: Active MCP ClientSession
        tool_name: Name of the tool to call
        arguments: Tool arguments
        timeout: Override default timeout

    Returns:
        Parsed JSON response from the tool, or {"error": "..."} on failure

    Behavior:
        - Logs the call (tool name + arguments summary, NOT full response)
        - Wraps in asyncio.timeout
        - Catches and returns errors as dict (never raises to caller)
    """
    timeout = timeout or settings.mcp_call_timeout
    try:
        async with asyncio.timeout(timeout):
            logger.info(f"MCP call: {tool_name}({_summarize_args(arguments)})")
            result = await session.call_tool(tool_name, arguments)

            # MCP returns result.content — may be list of content blocks
            if hasattr(result, 'content') and result.content:
                # Extract text content
                for block in result.content:
                    if hasattr(block, 'text'):
                        try:
                            return json.loads(block.text)
                        except json.JSONDecodeError:
                            return {"raw_text": block.text}
                return {"raw_content": str(result.content)}
            return {"empty": True}

    except asyncio.TimeoutError:
        logger.error(f"MCP call timed out: {tool_name} (>{timeout}s)")
        return {"error": f"Timeout after {timeout}s", "tool": tool_name}
    except Exception as e:
        logger.error(f"MCP call failed: {tool_name} — {e}")
        return {"error": str(e), "tool": tool_name}


def _summarize_args(args: dict) -> str:
    """Summarize arguments for logging without dumping huge queries."""
    summary = {}
    for k, v in args.items():
        if isinstance(v, str) and len(v) > 100:
            summary[k] = v[:100] + "..."
        else:
            summary[k] = v
    return str(summary)
```

### MCP client design rationale

**Single client, multiple servers**: One `McpClient` reads `mcp.json` and connects to any named server. The orchestrator connects to "splunk" for exceptions and "domain" for KB context.

**Context manager pattern**: `async with client.connect("splunk") as session` ensures cleanup. MCP stdio connections need proper lifecycle management.

**Error returns, not raises**: `call_tool()` returns `{"error": "..."}` instead of raising. The orchestrator checks for errors and continues — if Splunk times out, the report says "Splunk data unavailable" instead of crashing.

**Logging without leaking**: Logs tool names and argument summaries, not full responses (which could contain PII or sensitive data in a JPMC context).

---

## 6. SPLUNK FETCHER — `splunk_fetcher.py`

```python
"""
CDS Exception Monitor — Splunk Fetcher

Executes Splunk queries via MCP to fetch exceptions for the day.
Parses raw Splunk results into RawException models.

Copilot: implement this file.

KEY SPLUNK QUERY STRATEGY:
We run TWO queries, not one.

Query 1 (Aggregated): Gets exception counts grouped by type/source.
    → Fast. Returns summary stats. Used for the report overview.

Query 2 (Sampled): Gets sample raw events for each exception type.
    → Slower. Returns actual log lines with stack traces. Used for
    fingerprinting, LLM context, and drill-down.

Why two? A single query that returns both aggregates AND raw events
would be either too large (all events) or lose detail (only aggregates).
"""

import logging
from datetime import datetime
from typing import Optional

from mcp import ClientSession

from config import settings
from models import RawException
from mcp_client import call_tool

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# SPLUNK QUERY TEMPLATES
# ═══════════════════════════════════════════════════════════════

def build_aggregate_query() -> str:
    """
    Build the SPL query that returns exception counts grouped by type and source.

    Returns something like:
        index=cds_prod (level=ERROR OR level=FATAL)
        | stats count as exception_count,
                earliest(_time) as first_seen,
                latest(_time) as last_seen,
                dc(host) as host_count,
                values(host) as hosts
          by source, exception_class, logger
        | where exception_count >= 1
        | sort -exception_count

    IMPORTANT: Jey must verify that these field names match actual CDS Splunk schema.
    Adjust in config.py if they don't.
    """
    index = settings.splunk_index
    levels = settings.splunk_error_levels
    time_range = settings.splunk_time_range
    source_filter = settings.splunk_source_filter

    # Field references from config
    f_time = settings.splunk_field_time
    f_level = settings.splunk_field_level
    f_source = settings.splunk_field_source
    f_logger = settings.splunk_field_logger
    f_exc_class = settings.splunk_field_exception_class
    f_host = settings.splunk_field_host

    level_clause = " OR ".join([f'{f_level}={l.strip()}' for l in levels.split(" OR ")])

    query = f"""search index={index} ({level_clause}) earliest={time_range}"""

    if source_filter:
        query += f" {source_filter}"

    query += f"""
| stats count as exception_count,
        earliest({f_time}) as first_seen,
        latest({f_time}) as last_seen,
        dc({f_host}) as host_count,
        values({f_host}) as hosts
  by {f_source}, {f_exc_class}, {f_logger}
| where exception_count >= {settings.min_count_for_report}
| sort -exception_count
| head {settings.splunk_max_results}"""

    return query.strip()


def build_sample_query(source: str, exception_class: str, limit: int = 3) -> str:
    """
    Build SPL query to fetch sample raw events for a specific exception type.
    Used to get stack traces and message details for fingerprinting.

    Args:
        source: The service/source to filter
        exception_class: The exception class to filter
        limit: Number of sample events to fetch

    Returns:
        SPL query string
    """
    index = settings.splunk_index
    levels = settings.splunk_error_levels
    time_range = settings.splunk_time_range
    f_level = settings.splunk_field_level

    level_clause = " OR ".join([f'{f_level}={l.strip()}' for l in levels.split(" OR ")])

    query = f"""search index={index} ({level_clause}) earliest={time_range}
  {settings.splunk_field_source}="{source}"
  {settings.splunk_field_exception_class}="{exception_class}"
| head {limit}
| table {settings.splunk_field_time}, {settings.splunk_field_level},
        {settings.splunk_field_source}, {settings.splunk_field_logger},
        {settings.splunk_field_exception_class}, {settings.splunk_field_message},
        {settings.splunk_field_stack_trace}, {settings.splunk_field_host},
        {settings.splunk_field_thread}, {settings.splunk_field_trace_id}"""

    return query.strip()


# ═══════════════════════════════════════════════════════════════
# FETCHER FUNCTIONS
# ═══════════════════════════════════════════════════════════════

async def fetch_aggregate_exceptions(session: ClientSession) -> list[dict]:
    """
    Execute the aggregate query and return parsed results.

    Args:
        session: Active Splunk MCP session

    Returns:
        List of dicts, each representing one exception group with counts.
        Empty list if query fails.

    Behavior:
        - Calls the Splunk MCP search tool
        - Parses the result (Splunk MCP returns JSON array of events)
        - Returns raw dicts — parsing into models happens in aggregator.py
    """
    query = build_aggregate_query()
    logger.info(f"Running aggregate Splunk query")

    result = await call_tool(session, "search", {
        "query": query,
        "output_mode": "json",
    })

    if "error" in result:
        logger.error(f"Aggregate query failed: {result['error']}")
        return []

    # Splunk MCP may return results in different structures
    # Handle both: {"results": [...]} and direct list
    if isinstance(result, list):
        return result
    elif isinstance(result, dict):
        return result.get("results", result.get("data", []))
    return []


async def fetch_sample_events(
    session: ClientSession,
    source: str,
    exception_class: str,
    limit: int = 3,
) -> list[RawException]:
    """
    Fetch sample raw events for a specific exception type.
    Used for fingerprinting (stack trace) and LLM context.

    Args:
        session: Active Splunk MCP session
        source: Service name to filter
        exception_class: Exception class to filter
        limit: Max events to fetch

    Returns:
        List of RawException models. Empty list on failure.
    """
    query = build_sample_query(source, exception_class, limit)

    result = await call_tool(session, "search", {
        "query": query,
        "output_mode": "json",
    })

    if "error" in result:
        logger.warning(f"Sample query failed for {source}/{exception_class}: {result['error']}")
        return []

    raw_events = result if isinstance(result, list) else result.get("results", [])
    return [_parse_raw_event(evt) for evt in raw_events if evt]


def _parse_raw_event(event: dict) -> RawException:
    """
    Parse a single Splunk event dict into a RawException model.
    Handles missing fields gracefully — Splunk events are messy.
    """
    return RawException(
        timestamp=_parse_splunk_time(event.get(settings.splunk_field_time, "")),
        level=event.get(settings.splunk_field_level, "ERROR"),
        source=event.get(settings.splunk_field_source, "unknown"),
        logger=event.get(settings.splunk_field_logger),
        exception_class=event.get(settings.splunk_field_exception_class),
        message=event.get(settings.splunk_field_message, ""),
        stack_trace=event.get(settings.splunk_field_stack_trace),
        host=event.get(settings.splunk_field_host),
        thread=event.get(settings.splunk_field_thread),
        trace_id=event.get(settings.splunk_field_trace_id),
    )


def _parse_splunk_time(time_str: str) -> datetime:
    """Parse Splunk timestamp. Handles ISO format and epoch."""
    if not time_str:
        return datetime.now()
    try:
        # Try ISO format first
        return datetime.fromisoformat(time_str.replace("Z", "+00:00"))
    except ValueError:
        try:
            # Try epoch seconds
            return datetime.fromtimestamp(float(time_str))
        except (ValueError, OSError):
            return datetime.now()
```

### Splunk fetcher design rationale

**Two-query strategy is non-negotiable**. A single query returning everything would either overwhelm the MCP response (10K events with full stack traces) or lose the detail you need (aggregates only, no stack traces for fingerprinting). The aggregate query gives you the overview fast; the sample query runs selectively for the top exception types.

**Field mapping externalized to config**: This is the part most likely to need adjustment. CDS logs may use different field names across the 12 services. Better to fail obviously ("field not found") and fix in config than to hardcode field names buried in query strings.

**Splunk MCP tool name assumed to be "search"**: Validate during Day 1 MCP connection test. The Splunk MCP server may expose tools like `search`, `query`, `run_search`, or `execute_spl`. Use `list_tools()` to discover the actual name and update config.

---

## 7. DOMAIN ENRICHER — `domain_enricher.py`

```python
"""
CDS Exception Monitor — Domain Enricher

Connects to the Domain MCP (CDS knowledge base) to retrieve module context.
Maps Splunk source identifiers → CDS module names and context.

Copilot: implement this file.

DOMAIN MCP ASSUMPTIONS:
The Domain MCP serves CDS knowledge base files — markdown or structured docs
containing information about each CDS module: what it does, dependencies,
known issues, ownership, remediation guidance.

The MCP server likely exposes tools like:
- "search" or "query" — search KB files by keyword/topic
- "read_file" or "get_document" — read a specific KB file by path/name
- "list_files" or "list_documents" — enumerate available KB files

IMPORTANT: Jey must verify actual tool names on Day 1 by calling list_tools()
on the domain MCP server. Update config.py with correct tool names.

MODULE MAPPING STRATEGY:
The Splunk 'source' field (e.g., "cds-gateway", "cds-doc-service") needs to
map to CDS module names in the knowledge base. This mapping can be:
1. Direct match (source name = KB file name)
2. Alias table (maintained in config or a mapping file)
3. Fuzzy search (ask the Domain MCP to search for the source name)

We use option 3 for MVP: search the KB for the source name and use the
best match. If this is too noisy, add an explicit mapping table in Phase 2.
"""

import logging
from typing import Optional

from mcp import ClientSession

from config import settings
from models import ModuleContext
from mcp_client import call_tool

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# MODULE CONTEXT CACHE
# ═══════════════════════════════════════════════════════════════

# In-memory cache for the duration of a single run.
# Avoids re-querying the Domain MCP for the same module.
_module_cache: dict[str, Optional[ModuleContext]] = {}


async def get_module_context(
    session: ClientSession,
    source_identifier: str,
) -> Optional[ModuleContext]:
    """
    Retrieve CDS module context from the Domain MCP.

    Args:
        session: Active Domain MCP session
        source_identifier: The Splunk 'source' value (e.g., "cds-gateway")

    Returns:
        ModuleContext if found, None if no match or MCP error.

    Behavior:
        1. Check in-memory cache first
        2. Search Domain MCP for the source identifier
        3. If search returns results, fetch the most relevant document
        4. Parse into ModuleContext model
        5. Cache the result
    """
    # Cache check
    if source_identifier in _module_cache:
        return _module_cache[source_identifier]

    # Search KB for this module
    search_result = await call_tool(session, settings.domain_mcp_tool_search, {
        "query": source_identifier,
    })

    if "error" in search_result:
        logger.warning(f"Domain MCP search failed for '{source_identifier}': {search_result['error']}")
        _module_cache[source_identifier] = None
        return None

    # Parse search results — structure depends on Domain MCP implementation
    # Expected: list of documents/files with titles and content
    context = _parse_module_from_search(source_identifier, search_result)
    _module_cache[source_identifier] = context

    if context:
        logger.info(f"Found module context for '{source_identifier}' → {context.module_name}")
    else:
        logger.info(f"No module context found for '{source_identifier}'")

    return context


async def get_all_module_contexts(
    session: ClientSession,
    source_identifiers: list[str],
) -> dict[str, Optional[ModuleContext]]:
    """
    Batch-retrieve module context for multiple sources.

    Args:
        session: Active Domain MCP session
        source_identifiers: List of unique source values from Splunk

    Returns:
        Dict mapping source_identifier → ModuleContext (or None)
    """
    results = {}
    for source_id in source_identifiers:
        results[source_id] = await get_module_context(session, source_id)
    return results


def _parse_module_from_search(
    source_identifier: str,
    search_result: dict,
) -> Optional[ModuleContext]:
    """
    Parse Domain MCP search results into a ModuleContext.

    This function handles the messy part: the Domain MCP may return
    results in various formats depending on implementation.

    Expected result structures to handle:
    1. {"documents": [{"title": "...", "content": "..."}]}
    2. {"results": [{"file": "...", "text": "..."}]}
    3. {"raw_text": "...full document content..."}

    The function extracts:
    - module_name: from document title or first heading
    - description: from document body
    - dependencies: look for "Dependencies" section
    - known_issues: look for "Known Issues" section
    - owner_team: look for "Owner" or "Team" field
    - remediation_notes: look for "Remediation" or "Troubleshooting" section

    Copilot: implement robust parsing here. Use regex or string matching
    to extract sections from KB documents. The KB files are likely markdown
    with headers like ## Dependencies, ## Known Issues, etc.
    """
    # Extract document text from various result formats
    doc_text = ""
    doc_title = source_identifier

    if isinstance(search_result, dict):
        if "documents" in search_result:
            docs = search_result["documents"]
            if docs:
                doc_text = docs[0].get("content", docs[0].get("text", ""))
                doc_title = docs[0].get("title", source_identifier)
        elif "results" in search_result:
            results = search_result["results"]
            if results:
                doc_text = results[0].get("text", results[0].get("content", ""))
                doc_title = results[0].get("file", results[0].get("title", source_identifier))
        elif "raw_text" in search_result:
            doc_text = search_result["raw_text"]

    if not doc_text:
        return None

    # Parse markdown sections
    return ModuleContext(
        module_name=doc_title,
        source_identifier=source_identifier,
        description=_extract_section(doc_text, ["description", "overview", "what it does"]),
        dependencies=_extract_list_section(doc_text, ["dependencies", "depends on", "upstream", "downstream"]),
        known_issues=_extract_list_section(doc_text, ["known issues", "known problems", "caveats"]),
        owner_team=_extract_field(doc_text, ["owner", "team", "maintained by"]),
        remediation_notes=_extract_section(doc_text, ["remediation", "troubleshooting", "runbook", "recovery"]),
        criticality=_extract_field(doc_text, ["criticality", "priority", "tier"]) or "standard",
    )


def _extract_section(text: str, header_variants: list[str]) -> str:
    """
    Extract content under a markdown header matching any of the variants.
    Returns text from the matching header to the next same-level header.

    Example:
        text = "## Overview\nThis module handles...\n## Dependencies\n..."
        _extract_section(text, ["overview"]) → "This module handles..."
    """
    import re
    for variant in header_variants:
        # Match ## Header or ### Header (case-insensitive)
        pattern = rf'(?:^|\n)##+ *{re.escape(variant)}[^\n]*\n(.*?)(?=\n##|\Z)'
        match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
        if match:
            return match.group(1).strip()
    return ""


def _extract_list_section(text: str, header_variants: list[str]) -> list[str]:
    """
    Extract a markdown list section as a list of strings.
    Each "- item" or "* item" becomes one list entry.
    """
    section = _extract_section(text, header_variants)
    if not section:
        return []
    import re
    items = re.findall(r'[-*]\s+(.+)', section)
    return [item.strip() for item in items if item.strip()]


def _extract_field(text: str, field_variants: list[str]) -> str:
    """
    Extract a key-value field like "Owner: Platform Team" or "**Owner**: Platform Team".
    """
    import re
    for variant in field_variants:
        pattern = rf'(?:\*\*)?{re.escape(variant)}(?:\*\*)?[:\s]+(.+?)(?:\n|$)'
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1).strip()
    return ""


def clear_cache():
    """Clear the module context cache. Call between runs."""
    _module_cache.clear()
```

---

## 8. AGGREGATOR — `aggregator.py`

```python
"""
CDS Exception Monitor — Aggregator

Takes raw Splunk aggregate results + sample events and produces
AggregatedExceptionGroups with fingerprints. Then checks against
known patterns.

Copilot: implement this file.

FINGERPRINTING LOGIC:
fingerprint_hash = sha256(source + exception_class + top_stack_frame)

Where top_stack_frame is the first non-framework line in the stack trace.
"Non-framework" means: not java.lang.*, not org.springframework.*,
not com.sun.*, etc. We want the first line that's CDS application code.

If no stack trace is available, use:
fingerprint_hash = sha256(source + exception_class + message_template)

Where message_template replaces variable parts with <VAR>:
"Document 12345 not found" → "Document <VAR> not found"
"""

import hashlib
import json
import re
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from config import settings
from models import (
    AggregatedExceptionGroup,
    EnrichedExceptionGroup,
    ExceptionFingerprint,
    KnownPattern,
    ModuleContext,
    PatternStatus,
    RawException,
    Severity,
)

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════
# FRAMEWORK PACKAGES TO SKIP IN STACK TRACES
# ═══════════════════════════════════════════════════════════════

FRAMEWORK_PREFIXES = [
    "java.lang.",
    "java.util.",
    "java.io.",
    "java.net.",
    "javax.",
    "sun.",
    "com.sun.",
    "org.springframework.",
    "org.apache.",
    "io.netty.",
    "reactor.",
    "org.hibernate.",
    "com.zaxxer.",       # HikariCP
    "org.eclipse.jetty.",
    "io.undertow.",
]


# ═══════════════════════════════════════════════════════════════
# FINGERPRINTING
# ═══════════════════════════════════════════════════════════════

def compute_fingerprint(
    source: str,
    exception_class: str,
    stack_trace: Optional[str] = None,
    message: str = "",
) -> ExceptionFingerprint:
    """
    Compute a stable fingerprint for an exception.

    Priority:
    1. source + exception_class + top_stack_frame (if stack trace available)
    2. source + exception_class + message_template (fallback)

    Args:
        source: Service/app identifier
        exception_class: Exception class name
        stack_trace: Full stack trace string
        message: Log message

    Returns:
        ExceptionFingerprint with computed hash
    """
    top_frame = _extract_top_app_frame(stack_trace) if stack_trace else None
    msg_template = _templatize_message(message) if not top_frame else None

    # Build hash input
    if top_frame:
        hash_input = f"{source}|{exception_class}|{top_frame}"
    else:
        hash_input = f"{source}|{exception_class}|{msg_template or message}"

    fingerprint_hash = hashlib.sha256(hash_input.encode()).hexdigest()[:16]

    return ExceptionFingerprint(
        fingerprint_hash=fingerprint_hash,
        source=source,
        exception_class=exception_class or "UNKNOWN",
        top_stack_frame=top_frame,
        message_template=msg_template,
    )


def _extract_top_app_frame(stack_trace: str) -> Optional[str]:
    """
    Extract the first application-code line from a stack trace,
    skipping framework packages.

    Example stack trace:
        at java.lang.NullPointerException
        at org.springframework.web.servlet.DispatcherServlet.doDispatch(...)
        at com.jpmc.cds.gateway.DocumentController.findDocument(DocumentController.java:142)
        at com.jpmc.cds.gateway.service.DocumentService.lookup(DocumentService.java:89)

    Returns: "com.jpmc.cds.gateway.DocumentController.findDocument(DocumentController.java:142)"
    """
    if not stack_trace:
        return None

    lines = stack_trace.strip().split("\n")
    for line in lines:
        line = line.strip()
        if not line.startswith("at "):
            continue
        frame = line[3:].strip()  # Remove "at " prefix

        # Skip framework packages
        is_framework = any(frame.startswith(prefix) for prefix in FRAMEWORK_PREFIXES)
        if not is_framework and frame:
            return frame

    return None


def _templatize_message(message: str) -> str:
    """
    Replace variable parts of a log message with <VAR> to create a template.

    Examples:
        "Document 12345 not found" → "Document <VAR> not found"
        "Connection to host-abc-01:8080 timed out after 30000ms"
            → "Connection to <VAR>:<VAR> timed out after <VAR>ms"
        "User session abc-def-ghi expired" → "User session <VAR> expired"
    """
    # Replace UUIDs
    msg = re.sub(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', '<VAR>', message, flags=re.IGNORECASE)
    # Replace hex strings (8+ chars)
    msg = re.sub(r'\b[0-9a-f]{8,}\b', '<VAR>', msg)
    # Replace numbers (but not single digits that might be meaningful)
    msg = re.sub(r'\b\d{2,}\b', '<VAR>', msg)
    # Replace IP addresses
    msg = re.sub(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', '<VAR>', msg)
    # Replace hostnames (word-word-word pattern)
    msg = re.sub(r'\b[a-zA-Z]+-[a-zA-Z0-9]+-[a-zA-Z0-9]+\b', '<VAR>', msg)
    # Collapse consecutive <VAR>s
    msg = re.sub(r'(<VAR>\s*){2,}', '<VAR> ', msg)
    return msg.strip()


# ═══════════════════════════════════════════════════════════════
# AGGREGATION
# ═══════════════════════════════════════════════════════════════

def build_exception_groups(
    aggregate_results: list[dict],
    sample_events: dict[str, list[RawException]],
) -> list[AggregatedExceptionGroup]:
    """
    Build AggregatedExceptionGroups from Splunk aggregate query results
    and sample raw events.

    Args:
        aggregate_results: Rows from the aggregate Splunk query. Each row has:
            - source, exception_class, logger, exception_count, first_seen,
              last_seen, host_count, hosts
        sample_events: Dict mapping "source|exception_class" → list of RawException
            (from sample queries). Used for stack traces and fingerprinting.

    Returns:
        List of AggregatedExceptionGroup, sorted by count descending.
    """
    groups: list[AggregatedExceptionGroup] = []

    for row in aggregate_results:
        source = row.get("source", row.get(settings.splunk_field_source, "unknown"))
        exc_class = row.get("exception_class", row.get(settings.splunk_field_exception_class, "UNKNOWN"))
        count = int(row.get("exception_count", row.get("count", 1)))

        # Get sample event for this exception type (for stack trace)
        sample_key = f"{source}|{exc_class}"
        samples = sample_events.get(sample_key, [])
        sample_trace = samples[0].stack_trace if samples else None
        sample_msg = samples[0].message if samples else row.get("message", "")
        sample_trace_ids = [s.trace_id for s in samples if s.trace_id][:5]

        # Compute fingerprint
        fingerprint = compute_fingerprint(source, exc_class, sample_trace, sample_msg)

        # Compute severity
        severity = _compute_severity(count)

        # Parse hosts
        hosts_raw = row.get("hosts", [])
        if isinstance(hosts_raw, str):
            hosts_raw = [h.strip() for h in hosts_raw.split(",")]
        elif not isinstance(hosts_raw, list):
            hosts_raw = []

        group = AggregatedExceptionGroup(
            fingerprint=fingerprint,
            count=count,
            first_seen=_safe_parse_time(row.get("first_seen", "")),
            last_seen=_safe_parse_time(row.get("last_seen", "")),
            host_count=int(row.get("host_count", len(hosts_raw))),
            hosts=hosts_raw[:10],
            severity=severity,
            sample_message=sample_msg,
            sample_stack_trace=sample_trace,
            trace_ids=sample_trace_ids,
            level=row.get(settings.splunk_field_level, "ERROR"),
        )
        groups.append(group)

    # Sort by count descending
    groups.sort(key=lambda g: g.count, reverse=True)
    return groups


def _compute_severity(count: int) -> Severity:
    """Compute severity from count thresholds in config."""
    if count >= settings.critical_severity_threshold:
        return Severity.CRITICAL
    elif count >= settings.high_severity_threshold:
        return Severity.HIGH
    return Severity.LOW


def _safe_parse_time(time_str: str) -> datetime:
    """Parse time string with fallback to now."""
    if not time_str:
        return datetime.now()
    try:
        return datetime.fromisoformat(str(time_str).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        try:
            return datetime.fromtimestamp(float(time_str))
        except (ValueError, OSError, TypeError):
            return datetime.now()


# ═══════════════════════════════════════════════════════════════
# KNOWN PATTERN MATCHING
# ═══════════════════════════════════════════════════════════════

def load_known_patterns() -> list[KnownPattern]:
    """Load known exception patterns from JSON file."""
    path = settings.known_patterns_file
    if not path.exists():
        logger.warning(f"Known patterns file not found: {path}")
        return []
    with open(path) as f:
        raw = json.load(f)
    return [KnownPattern(**p) for p in raw.get("patterns", raw if isinstance(raw, list) else [])]


def match_known_patterns(
    groups: list[AggregatedExceptionGroup],
    known_patterns: list[KnownPattern],
) -> list[EnrichedExceptionGroup]:
    """
    Match exception groups against known patterns.
    Returns EnrichedExceptionGroups with pattern_status updated.

    Matching logic:
    1. For each group, check each known pattern
    2. Match on: exception_class (exact or regex) + message_pattern (regex)
    3. If source_filter is set on the pattern, also match source
    4. First match wins (patterns should be ordered by specificity)
    """
    enriched: list[EnrichedExceptionGroup] = []

    for group in groups:
        matched_pattern = None
        for pattern in known_patterns:
            if _pattern_matches(group, pattern):
                matched_pattern = pattern
                break

        if matched_pattern:
            group.pattern_status = PatternStatus.KNOWN
            if matched_pattern.severity_override:
                group.severity = matched_pattern.severity_override

        enriched_group = EnrichedExceptionGroup(
            group=group,
            known_pattern_match=matched_pattern.model_dump() if matched_pattern else None,
        )
        enriched.append(enriched_group)

    return enriched


def _pattern_matches(group: AggregatedExceptionGroup, pattern: KnownPattern) -> bool:
    """Check if an exception group matches a known pattern."""
    # Exception class match (exact or regex)
    exc_class = group.fingerprint.exception_class
    if not re.match(pattern.exception_class, exc_class, re.IGNORECASE):
        return False

    # Message match (regex)
    if pattern.message_pattern:
        if not re.search(pattern.message_pattern, group.sample_message, re.IGNORECASE):
            return False

    # Source filter (optional)
    if pattern.source_filter:
        if not re.match(pattern.source_filter, group.fingerprint.source, re.IGNORECASE):
            return False

    return True
```

---

## 9. CORRELATOR — `correlator.py`

```python
"""
CDS Exception Monitor — LLM Correlator

Sends enriched exception groups to Claude for correlation analysis.
The LLM's job: group related exceptions, hypothesize root causes,
rank by priority, and suggest actions.

Copilot: implement this file.

KEY DESIGN PRINCIPLE:
The LLM receives PRE-AGGREGATED, PRE-ENRICHED data. It never sees raw logs.
This means:
- Lower token cost (structured summary, not 10K log lines)
- Faster response (smaller context)
- Better analysis (LLM works on the right abstraction level)
- Deterministic base (fingerprinting/matching already done)

The LLM adds: correlation across exception types, root cause reasoning,
priority ranking, and human-readable action items.
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

import httpx

from config import settings
from models import (
    CorrelatedCluster,
    CorrelationReport,
    EnrichedExceptionGroup,
)

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# PROMPT CONSTRUCTION
# ═══════════════════════════════════════════════════════════════

def load_system_prompt() -> str:
    """Load the system prompt from prompts/correlator_system.md"""
    path = settings.prompts_dir / "correlator_system.md"
    if path.exists():
        return path.read_text()
    return _default_system_prompt()


def build_user_prompt(enriched_groups: list[EnrichedExceptionGroup]) -> str:
    """
    Build the user prompt with exception data injected.

    Format: structured text/JSON that the LLM can parse and reason over.
    NOT raw logs. The LLM sees:
    - Exception fingerprint, class, source, count, severity
    - Module context (if available)
    - Known pattern match (if any)
    - Sample message and stack trace
    """
    # Load template if exists
    template_path = settings.prompts_dir / "correlator_user.md"
    if template_path.exists():
        template = template_path.read_text()
    else:
        template = _default_user_template()

    # Build exception data block
    exception_data = _format_exceptions_for_llm(enriched_groups)

    # Build summary stats
    total = sum(g.group.count for g in enriched_groups)
    novel = sum(1 for g in enriched_groups if g.group.pattern_status.value == "novel")
    known = sum(1 for g in enriched_groups if g.group.pattern_status.value == "known")
    critical = sum(1 for g in enriched_groups if g.group.severity.value == "critical")
    high = sum(1 for g in enriched_groups if g.group.severity.value == "high")

    # Inject into template
    prompt = template.replace("{{EXCEPTION_DATA}}", exception_data)
    prompt = prompt.replace("{{TOTAL_EXCEPTIONS}}", str(total))
    prompt = prompt.replace("{{UNIQUE_PATTERNS}}", str(len(enriched_groups)))
    prompt = prompt.replace("{{NOVEL_PATTERNS}}", str(novel))
    prompt = prompt.replace("{{KNOWN_PATTERNS}}", str(known))
    prompt = prompt.replace("{{CRITICAL_COUNT}}", str(critical))
    prompt = prompt.replace("{{HIGH_COUNT}}", str(high))
    prompt = prompt.replace("{{DATE}}", datetime.now().strftime("%Y-%m-%d"))

    return prompt


def _format_exceptions_for_llm(groups: list[EnrichedExceptionGroup]) -> str:
    """
    Format enriched exception groups as structured text for the LLM.
    Each group becomes a numbered block with key attributes.
    """
    blocks = []
    for i, eg in enumerate(groups, 1):
        g = eg.group
        fp = g.fingerprint
        mc = eg.module_context
        kp = eg.known_pattern_match

        block = f"""--- EXCEPTION #{i} ---
Fingerprint: {fp.fingerprint_hash}
Exception Class: {fp.exception_class}
Source/Service: {fp.source}
Count: {g.count}
Severity: {g.severity.value}
Pattern Status: {g.pattern_status.value}
First Seen: {g.first_seen.isoformat()}
Last Seen: {g.last_seen.isoformat()}
Hosts Affected: {g.host_count}
Level: {g.level}
Sample Message: {g.sample_message[:500]}"""

        if fp.top_stack_frame:
            block += f"\nTop Stack Frame: {fp.top_stack_frame}"
        if fp.message_template:
            block += f"\nMessage Template: {fp.message_template}"

        if mc:
            block += f"""
--- Module Context ---
Module: {mc.module_name}
Description: {mc.description[:300]}
Dependencies: {', '.join(mc.dependencies[:5])}
Known Issues: {', '.join(mc.known_issues[:3])}
Criticality: {mc.criticality}"""

        if kp:
            block += f"""
--- Known Pattern Match ---
Pattern ID: {kp.get('pattern_id', 'N/A')}
Known Root Cause: {kp.get('root_cause', 'N/A')}
Known Remediation: {kp.get('remediation', 'N/A')}"""

        blocks.append(block)

    return "\n\n".join(blocks)


# ═══════════════════════════════════════════════════════════════
# LLM CALL
# ═══════════════════════════════════════════════════════════════

async def run_correlation(
    enriched_groups: list[EnrichedExceptionGroup],
) -> CorrelationReport:
    """
    Send enriched exception data to Claude for correlation analysis.

    Args:
        enriched_groups: Enriched exception groups (aggregated + domain context + known matches)

    Returns:
        CorrelationReport with clusters, executive summary, and recommendations.

    Behavior:
        1. Build system + user prompts
        2. Call Claude API (Sonnet for speed)
        3. Parse structured JSON response into CorrelationReport
        4. Fallback: if JSON parsing fails, extract what we can
    """
    system_prompt = load_system_prompt()
    user_prompt = build_user_prompt(enriched_groups)

    logger.info(f"Sending {len(enriched_groups)} exception groups to LLM for correlation")

    # Call Claude API
    response = await _call_claude(system_prompt, user_prompt)

    if not response:
        logger.error("LLM call returned empty response")
        return _build_fallback_report(enriched_groups)

    # Parse LLM response into CorrelationReport
    try:
        report = _parse_llm_response(response, enriched_groups)
        logger.info(f"LLM correlation complete: {len(report.clusters)} clusters identified")
        return report
    except Exception as e:
        logger.error(f"Failed to parse LLM response: {e}")
        return _build_fallback_report(enriched_groups)


async def _call_claude(system_prompt: str, user_prompt: str) -> Optional[str]:
    """
    Call Claude API via httpx.

    Uses ANTHROPIC_API_KEY from environment.
    Falls back to empty response on any error.
    """
    import os
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        logger.error("ANTHROPIC_API_KEY not set. LLM correlation unavailable.")
        return None

    try:
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": settings.llm_model,
                    "max_tokens": settings.llm_max_tokens,
                    "temperature": settings.llm_temperature,
                    "system": system_prompt,
                    "messages": [
                        {"role": "user", "content": user_prompt}
                    ],
                },
            )
            response.raise_for_status()
            data = response.json()

            # Extract text from response
            text_parts = []
            for block in data.get("content", []):
                if block.get("type") == "text":
                    text_parts.append(block["text"])
            return "\n".join(text_parts)

    except Exception as e:
        logger.error(f"Claude API call failed: {e}")
        return None


def _parse_llm_response(
    response_text: str,
    enriched_groups: list[EnrichedExceptionGroup],
) -> CorrelationReport:
    """
    Parse the LLM's JSON response into a CorrelationReport.

    Expected JSON structure (defined in system prompt):
    {
        "executive_summary": "...",
        "clusters": [
            {
                "cluster_id": "cluster_001",
                "title": "...",
                "root_cause_hypothesis": "...",
                "confidence": "high|medium|low",
                "impact_summary": "...",
                "exception_fingerprints": ["abc123", "def456"],
                "affected_modules": ["cds-gateway", "cds-doc-service"],
                "recommended_actions": ["...", "..."],
                "related_known_issues": ["..."],
                "suggested_ticket": "..."
            }
        ],
        "uncorrelated": ["fingerprint_hash_1", "..."],
        "module_health_summary": {"cds-gateway": "degraded", ...},
        "trend_observations": ["..."]
    }
    """
    # Strip markdown code fences if present
    clean = response_text.strip()
    if clean.startswith("```"):
        clean = clean.split("\n", 1)[1] if "\n" in clean else clean[3:]
    if clean.endswith("```"):
        clean = clean[:-3]
    clean = clean.strip()
    if clean.startswith("json"):
        clean = clean[4:].strip()

    parsed = json.loads(clean)

    total = sum(g.group.count for g in enriched_groups)
    novel = sum(1 for g in enriched_groups if g.group.pattern_status.value == "novel")

    clusters = []
    for c in parsed.get("clusters", []):
        cluster = CorrelatedCluster(
            cluster_id=c.get("cluster_id", ""),
            title=c.get("title", "Unnamed Cluster"),
            root_cause_hypothesis=c.get("root_cause_hypothesis", ""),
            confidence=c.get("confidence", "low"),
            impact_summary=c.get("impact_summary", ""),
            exception_fingerprints=c.get("exception_fingerprints", []),
            total_count=sum(
                g.group.count for g in enriched_groups
                if g.group.fingerprint.fingerprint_hash in c.get("exception_fingerprints", [])
            ),
            affected_modules=c.get("affected_modules", []),
            recommended_actions=c.get("recommended_actions", []),
            related_known_issues=c.get("related_known_issues", []),
            suggested_ticket=c.get("suggested_ticket"),
        )
        clusters.append(cluster)

    return CorrelationReport(
        generated_at=datetime.now(),
        time_range_start=min((g.group.first_seen for g in enriched_groups), default=datetime.now()),
        time_range_end=max((g.group.last_seen for g in enriched_groups), default=datetime.now()),
        total_exceptions=total,
        total_unique_patterns=len(enriched_groups),
        total_novel_patterns=novel,
        executive_summary=parsed.get("executive_summary", ""),
        clusters=clusters,
        uncorrelated=parsed.get("uncorrelated", []),
        module_health_summary=parsed.get("module_health_summary", {}),
        trend_observations=parsed.get("trend_observations", []),
    )


def _build_fallback_report(
    enriched_groups: list[EnrichedExceptionGroup],
) -> CorrelationReport:
    """
    Build a minimal report when LLM is unavailable.
    No correlation — just aggregated data presented as-is.
    """
    total = sum(g.group.count for g in enriched_groups)
    novel = sum(1 for g in enriched_groups if g.group.pattern_status.value == "novel")

    return CorrelationReport(
        generated_at=datetime.now(),
        time_range_start=min((g.group.first_seen for g in enriched_groups), default=datetime.now()),
        time_range_end=max((g.group.last_seen for g in enriched_groups), default=datetime.now()),
        total_exceptions=total,
        total_unique_patterns=len(enriched_groups),
        total_novel_patterns=novel,
        executive_summary=f"LLM correlation unavailable. Showing {len(enriched_groups)} exception patterns ({total} total events). {novel} novel patterns detected.",
        clusters=[],
        uncorrelated=[g.group.fingerprint.fingerprint_hash for g in enriched_groups],
        module_health_summary={},
        trend_observations=[],
    )


# ═══════════════════════════════════════════════════════════════
# DEFAULT PROMPTS (used if prompt files don't exist)
# ═══════════════════════════════════════════════════════════════

def _default_system_prompt() -> str:
    return """You are an expert SRE analyzing daily exception data for a critical shared-services platform (CDS) at a major financial institution. The platform has 12 services, 100+ APIs, and serves multiple downstream consumers across Asset & Wealth Management.

Your task: Analyze the exception data provided and produce a structured correlation report.

RULES:
1. Group related exceptions into clusters that likely share a root cause or causal chain.
2. For each cluster, provide a root cause hypothesis, confidence level, impact assessment, and recommended actions.
3. Consider module dependencies — if Module A depends on Module B, exceptions in both may be correlated.
4. Distinguish between: symptoms (downstream effects) and causes (origin of the problem).
5. Prioritize by: business impact > exception count > novelty.
6. Flag novel patterns that haven't been seen before — these need human investigation.
7. For known patterns with existing remediation, confirm the known fix applies to today's context.

OUTPUT FORMAT: Respond with ONLY a JSON object (no markdown, no explanation outside JSON):
{
    "executive_summary": "3-5 sentence overview for leadership. Focus on: what's broken, what's the impact, what needs immediate attention.",
    "clusters": [
        {
            "cluster_id": "cluster_001",
            "title": "Human-readable cluster name",
            "root_cause_hypothesis": "What you think is causing this group of exceptions",
            "confidence": "high|medium|low",
            "impact_summary": "Business/operational impact",
            "exception_fingerprints": ["hash1", "hash2"],
            "affected_modules": ["module1", "module2"],
            "recommended_actions": ["Action 1 (most important first)", "Action 2"],
            "related_known_issues": ["Reference to known issues from KB if any"],
            "suggested_ticket": "Suggested Jira ticket summary if warranted"
        }
    ],
    "uncorrelated": ["fingerprint_hashes that don't fit any cluster"],
    "module_health_summary": {"module_name": "healthy|degraded|impacted"},
    "trend_observations": ["Notable trends compared to normal operations"]
}"""


def _default_user_template() -> str:
    return """## CDS Daily Exception Report — {{DATE}}

**Summary**: {{TOTAL_EXCEPTIONS}} total exceptions across {{UNIQUE_PATTERNS}} unique patterns.
{{NOVEL_PATTERNS}} novel patterns. {{KNOWN_PATTERNS}} known patterns.
{{CRITICAL_COUNT}} critical severity. {{HIGH_COUNT}} high severity.

## Exception Data

{{EXCEPTION_DATA}}

---

Analyze these exceptions. Group correlated ones into clusters. Identify root causes. Rank by priority. Provide actionable recommendations.

Respond with ONLY the JSON object as specified in your instructions."""
```

---

## 10. REPORT GENERATOR — `report_generator.py`

```python
"""
CDS Exception Monitor — Report Generator

Renders the CorrelationReport into an HTML dashboard using Jinja2.

Copilot: implement this file.

The HTML report is a SINGLE self-contained file. All CSS is inline.
No JavaScript frameworks. Minimal JS for expand/collapse and filtering.
Opens in any browser.
"""

import logging
from datetime import datetime
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from config import settings
from models import CorrelationReport, EnrichedExceptionGroup

logger = logging.getLogger(__name__)


def generate_report(
    report: CorrelationReport,
    enriched_groups: list[EnrichedExceptionGroup],
    output_path: Path = None,
) -> Path:
    """
    Generate HTML report from correlation analysis.

    Args:
        report: LLM correlation output
        enriched_groups: Full enriched exception data (for drill-down)
        output_path: Where to save. Defaults to output/report_YYYY-MM-DD.html

    Returns:
        Path to generated HTML file

    Behavior:
        - Loads Jinja2 template from templates/report.html.j2
        - Injects report data + enriched groups
        - Writes self-contained HTML file
    """
    if output_path is None:
        settings.output_dir.mkdir(parents=True, exist_ok=True)
        date_str = datetime.now().strftime("%Y-%m-%d")
        output_path = settings.output_dir / f"report_{date_str}.html"

    # Set up Jinja2
    env = Environment(
        loader=FileSystemLoader(str(settings.templates_dir)),
        autoescape=select_autoescape(["html"]),
    )

    # Register custom filters
    env.filters["severity_color"] = _severity_color
    env.filters["status_badge"] = _status_badge
    env.filters["health_color"] = _health_color
    env.filters["truncate_smart"] = _truncate_smart
    env.filters["format_count"] = _format_count

    template = env.get_template("report.html.j2")

    # Build template context
    # Create a lookup from fingerprint hash → enriched group
    groups_by_hash = {
        eg.group.fingerprint.fingerprint_hash: eg
        for eg in enriched_groups
    }

    context = {
        "report": report,
        "enriched_groups": enriched_groups,
        "groups_by_hash": groups_by_hash,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "date": datetime.now().strftime("%Y-%m-%d"),
        "settings": settings,
    }

    html = template.render(**context)
    output_path.write_text(html, encoding="utf-8")
    logger.info(f"Report generated: {output_path}")
    return output_path


def _severity_color(severity: str) -> str:
    """Map severity to CSS color."""
    return {
        "critical": "#ff4444",
        "high": "#ff8800",
        "low": "#44aa44",
    }.get(severity, "#888888")


def _status_badge(status: str) -> str:
    """Map pattern status to badge HTML."""
    colors = {
        "known": ("background:#2d5a2d; color:#88cc88;", "KNOWN"),
        "novel": ("background:#5a2d2d; color:#cc8888;", "NOVEL"),
        "recurring": ("background:#5a4a2d; color:#ccaa88;", "RECURRING"),
    }
    style, label = colors.get(status, ("background:#333; color:#aaa;", status.upper()))
    return f'<span style="padding:2px 8px; border-radius:4px; font-size:11px; font-weight:600; {style}">{label}</span>'


def _health_color(health: str) -> str:
    """Map module health to CSS color."""
    return {
        "healthy": "#44aa44",
        "degraded": "#ff8800",
        "impacted": "#ff4444",
    }.get(health, "#888888")


def _truncate_smart(text: str, length: int = 200) -> str:
    """Truncate text at word boundary."""
    if len(text) <= length:
        return text
    truncated = text[:length].rsplit(" ", 1)[0]
    return truncated + "..."


def _format_count(count: int) -> str:
    """Format large numbers with commas."""
    return f"{count:,}"
```

---

## 11. ORCHESTRATOR — `main.py`

```python
"""
CDS Exception Monitor — Main Orchestrator

Ties everything together. This is the entry point.

Usage:
    python main.py                    # Run with defaults (last 24h)
    python main.py --time-range -4h   # Last 4 hours
    python main.py --output report.html  # Custom output path
    python main.py --no-llm           # Skip LLM correlation (aggregates only)
    python main.py --dry-run          # Show Splunk queries without executing

Copilot: implement this file exactly as specified.
"""

import asyncio
import argparse
import logging
import sys
from datetime import datetime
from pathlib import Path

from config import settings
from models import EnrichedExceptionGroup
from mcp_client import McpClient
from splunk_fetcher import fetch_aggregate_exceptions, fetch_sample_events
from domain_enricher import get_all_module_contexts, clear_cache
from aggregator import build_exception_groups, load_known_patterns, match_known_patterns
from correlator import run_correlation
from report_generator import generate_report

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


async def run(
    time_range: str = None,
    output_path: Path = None,
    skip_llm: bool = False,
    dry_run: bool = False,
    skip_domain: bool = False,
) -> Path:
    """
    Main execution pipeline.

    Steps:
        1. Connect to Splunk MCP
        2. Run aggregate query → get exception counts by type/source
        3. For top N exception types, fetch sample events (stack traces)
        4. Build fingerprints and AggregatedExceptionGroups
        5. Match against known patterns (deterministic)
        6. Connect to Domain MCP → enrich with module context
        7. Send to LLM for correlation (unless --no-llm)
        8. Generate HTML report
        9. Return path to report

    Args:
        time_range: Override Splunk time range (e.g., "-4h", "-1d@d")
        output_path: Override output file path
        skip_llm: If True, skip LLM correlation (useful for testing pipeline)
        dry_run: If True, print queries but don't execute
        skip_domain: If True, skip Domain MCP enrichment

    Returns:
        Path to generated HTML report
    """
    # Override time range if provided
    if time_range:
        settings.splunk_time_range = time_range

    mcp = McpClient()

    # ── STEP 1: Fetch aggregate exceptions from Splunk ──
    logger.info("=" * 60)
    logger.info(f"CDS Exception Monitor — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    logger.info(f"Time range: {settings.splunk_time_range}")
    logger.info("=" * 60)

    if dry_run:
        from splunk_fetcher import build_aggregate_query
        print("\n--- AGGREGATE QUERY ---")
        print(build_aggregate_query())
        print("\n(Dry run — no queries executed)")
        return Path("/dev/null")

    logger.info("Step 1: Fetching aggregate exceptions from Splunk...")
    async with mcp.connect(settings.splunk_mcp_server_name) as splunk_session:
        aggregate_results = await fetch_aggregate_exceptions(splunk_session)
        logger.info(f"  → {len(aggregate_results)} exception types found")

        if not aggregate_results:
            logger.info("No exceptions found. Generating empty report.")
            # Generate minimal report and return
            from models import CorrelationReport
            empty_report = CorrelationReport(
                generated_at=datetime.now(),
                time_range_start=datetime.now(),
                time_range_end=datetime.now(),
                total_exceptions=0,
                total_unique_patterns=0,
                total_novel_patterns=0,
                executive_summary="No exceptions detected in the specified time range. All CDS services appear healthy.",
                clusters=[],
                uncorrelated=[],
                module_health_summary={},
                trend_observations=["No exceptions — this is a good day."],
            )
            return generate_report(empty_report, [], output_path)

        # ── STEP 2: Fetch sample events for top exception types ──
        logger.info("Step 2: Fetching sample events for fingerprinting...")
        # Only fetch samples for top 50 exception types (by count) to avoid excessive MCP calls
        top_results = sorted(aggregate_results, key=lambda r: int(r.get("exception_count", r.get("count", 0))), reverse=True)[:50]

        sample_events = {}
        for row in top_results:
            source = row.get("source", row.get(settings.splunk_field_source, "unknown"))
            exc_class = row.get("exception_class", row.get(settings.splunk_field_exception_class, "UNKNOWN"))
            key = f"{source}|{exc_class}"
            samples = await fetch_sample_events(splunk_session, source, exc_class, limit=3)
            if samples:
                sample_events[key] = samples

        logger.info(f"  → Fetched samples for {len(sample_events)} exception types")

    # ── STEP 3: Build fingerprints and aggregate groups ──
    logger.info("Step 3: Building fingerprints and aggregating...")
    groups = build_exception_groups(aggregate_results, sample_events)
    logger.info(f"  → {len(groups)} aggregated exception groups")

    # ── STEP 4: Match known patterns ──
    logger.info("Step 4: Matching against known patterns...")
    known_patterns = load_known_patterns()
    enriched_groups = match_known_patterns(groups, known_patterns)
    known_count = sum(1 for eg in enriched_groups if eg.group.pattern_status.value == "known")
    novel_count = sum(1 for eg in enriched_groups if eg.group.pattern_status.value == "novel")
    logger.info(f"  → {known_count} known, {novel_count} novel patterns")

    # ── STEP 5: Enrich with domain context ──
    if not skip_domain:
        logger.info("Step 5: Enriching with CDS module context...")
        try:
            async with mcp.connect(settings.domain_mcp_server_name) as domain_session:
                unique_sources = list(set(eg.group.fingerprint.source for eg in enriched_groups))
                module_contexts = await get_all_module_contexts(domain_session, unique_sources)

                # Attach module context to enriched groups
                for eg in enriched_groups:
                    source = eg.group.fingerprint.source
                    eg.module_context = module_contexts.get(source)

                matched = sum(1 for mc in module_contexts.values() if mc is not None)
                logger.info(f"  → {matched}/{len(unique_sources)} sources mapped to modules")
        except Exception as e:
            logger.warning(f"Domain MCP unavailable — continuing without module context: {e}")
    else:
        logger.info("Step 5: Skipping domain enrichment (--skip-domain)")

    # ── STEP 6: LLM correlation ──
    if not skip_llm:
        logger.info("Step 6: Running LLM correlation analysis...")
        report = await run_correlation(enriched_groups)
    else:
        logger.info("Step 6: Skipping LLM correlation (--no-llm)")
        from correlator import _build_fallback_report
        report = _build_fallback_report(enriched_groups)

    # ── STEP 7: Generate HTML report ──
    logger.info("Step 7: Generating HTML report...")
    report_path = generate_report(report, enriched_groups, output_path)
    logger.info(f"  → Report saved to: {report_path}")

    # ── Summary ──
    logger.info("=" * 60)
    logger.info(f"DONE — {report.total_exceptions:,} exceptions, "
                f"{report.total_unique_patterns} patterns, "
                f"{len(report.clusters)} correlated clusters")
    logger.info(f"Report: {report_path}")
    logger.info("=" * 60)

    clear_cache()
    return report_path


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(description="CDS Daily Exception Monitor")
    parser.add_argument("--time-range", "-t", default=None,
                        help="Splunk time range (e.g., '-4h', '-1d@d'). Default: -24h")
    parser.add_argument("--output", "-o", default=None,
                        help="Output HTML file path")
    parser.add_argument("--no-llm", action="store_true",
                        help="Skip LLM correlation (show aggregates only)")
    parser.add_argument("--skip-domain", action="store_true",
                        help="Skip Domain MCP enrichment")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print Splunk queries without executing")
    args = parser.parse_args()

    output_path = Path(args.output) if args.output else None

    result = asyncio.run(run(
        time_range=args.time_range,
        output_path=output_path,
        skip_llm=args.no_llm,
        dry_run=args.dry_run,
        skip_domain=args.skip_domain,
    ))

    print(f"\nReport: {result}")


if __name__ == "__main__":
    main()
```

---

## 12. KNOWN PATTERNS FILE — `known_patterns/known_exceptions.json`

```json
{
    "description": "Curated known exception patterns for CDS platform. Maintained by SRE team. Deterministic matching runs before LLM correlation.",
    "last_updated": "2026-04-02",
    "patterns": [
        {
            "pattern_id": "KP-001",
            "exception_class": "java.net.ConnectException",
            "message_pattern": "(?i)pithos.*connection.*refused",
            "source_filter": null,
            "description": "Pithos connection refused — typically indicates Pithos service is down or unreachable",
            "root_cause": "Pithos service unavailability or network partition",
            "remediation": "1. Check Pithos service health in Dynatrace. 2. Check network connectivity from CDS pods to Pithos. 3. Check Pithos deployment status. 4. If during migration window, verify migration state.",
            "severity_override": "critical",
            "last_updated": "2026-04-02",
            "jira_reference": null
        },
        {
            "pattern_id": "KP-002",
            "exception_class": "java.net.SocketTimeoutException",
            "message_pattern": "(?i)(read|connect).*timed?\\s*out",
            "source_filter": null,
            "description": "Socket timeout — downstream service or database responding too slowly",
            "root_cause": "Downstream latency or connection pool exhaustion",
            "remediation": "1. Identify the downstream target from the stack trace. 2. Check downstream service latency in Dynatrace. 3. Check connection pool metrics. 4. If widespread, check for GC pressure or resource contention.",
            "severity_override": null,
            "last_updated": "2026-04-02",
            "jira_reference": null
        },
        {
            "pattern_id": "KP-003",
            "exception_class": "java.lang.NullPointerException",
            "message_pattern": ".*",
            "source_filter": null,
            "description": "Generic NPE — needs stack trace analysis to determine root cause",
            "root_cause": "Application bug — null reference in code path",
            "remediation": "1. Check top stack frame to identify the code location. 2. If in CDS application code, create a Jira ticket with the stack trace. 3. If in framework code, check for misconfigured dependencies.",
            "severity_override": null,
            "last_updated": "2026-04-02",
            "jira_reference": null
        }
    ]
}
```

**Jey: Add your team's known patterns here.** Start with the top 10 exceptions your team sees regularly. Each entry becomes a deterministic match that the LLM doesn't need to waste tokens on. This file is the "knowledge base quality > AI sophistication" principle in action.

---

## 13. PROMPTS — `prompts/correlator_system.md`

```markdown
You are an expert SRE analyzing daily exception data for the CDS (Common Capabilities / Shared Services) platform at JPMorgan Chase. CDS is a critical shared-services platform within Asset & Wealth Management that supports document lifecycle workflows. It has 12 services, 100+ APIs, and serves multiple downstream consumers across AWM.

## Your Task

Analyze the exception data provided and produce a structured correlation report as JSON.

## Analysis Framework

1. **Cluster Related Exceptions**: Group exceptions that likely share a root cause or are part of a causal chain. Consider:
   - Same exception class across multiple services → possible shared dependency failure
   - Timeout exceptions in service A + connection errors in service B → A likely depends on B
   - Spike in one module following a spike in another → cascade pattern
   - Same time window + different modules → common infrastructure issue

2. **Root Cause Reasoning**: For each cluster:
   - Distinguish symptoms (downstream effects) from causes (origin point)
   - Use module dependency information to trace causal chains
   - Consider: Is this a code bug, infrastructure issue, dependency failure, or capacity problem?

3. **Priority Ranking**: Rank clusters by:
   - Business impact (critical modules > standard modules)
   - Exception count (volume indicates blast radius)
   - Novelty (novel patterns need investigation; known patterns need confirmation)
   - Spread (multi-host > single-host; multi-module > single-module)

4. **Actionable Recommendations**: For each cluster:
   - What should the SRE team do first?
   - Is this a "fix now" or "monitor and investigate"?
   - Should a ticket be created?
   - For known patterns: does the known remediation apply to today's context?

## Output Rules

- Respond with ONLY a JSON object. No markdown fences, no explanation outside JSON.
- Every exception fingerprint must appear in exactly one cluster OR in the uncorrelated list.
- Confidence levels: "high" = strong evidence, "medium" = reasonable hypothesis, "low" = speculative.
- Executive summary must be readable by a non-technical leader in 10 seconds.
- recommended_actions must be ordered: most important first.
- If you see patterns that suggest an emerging incident (not yet an outage but trending toward one), flag it explicitly.

## CDS-Specific Context

- CDS is undergoing an active migration from IBM CM to Pithos. Pithos-related errors may indicate migration issues.
- The platform runs on JPMC Private Cloud (Gaia/CPSR/GKP).
- Downstream consumers across AWM depend on CDS APIs — failures have broad blast radius.
- Common failure modes: connection pool exhaustion, Pithos connectivity, document retrieval timeouts, queue processing delays.
```

---

## 14. JINJA2 TEMPLATE — `templates/report.html.j2`

```
Copilot: Generate a self-contained HTML template with these sections.
All CSS must be inline (in a <style> tag). Minimal JS for expand/collapse.
Dark theme. Monospace accents for technical data.

TEMPLATE STRUCTURE:

<html>
<head>
  <title>CDS Exception Report — {{ date }}</title>
  <style>
    /* Dark theme. Clean. Professional. Monospace for data. */
    /* Color scheme: dark background, white text, accent colors for severity */
    /* Critical: #ff4444, High: #ff8800, Low/Healthy: #44aa44 */
    /* Novel: red-tinted badge, Known: green-tinted badge */
  </style>
</head>
<body>

  <!-- HEADER -->
  <!-- Report title, date, generation time -->

  <!-- EXECUTIVE SUMMARY -->
  <!-- report.executive_summary in a highlighted card -->
  <!-- Key stats: total exceptions, unique patterns, novel count, clusters -->

  <!-- MODULE HEALTH OVERVIEW -->
  <!-- Grid of module health badges from report.module_health_summary -->
  <!-- Color-coded: green=healthy, orange=degraded, red=impacted -->

  <!-- CORRELATED CLUSTERS (main content) -->
  <!-- For each cluster in report.clusters: -->
  <!--   Cluster title + confidence badge -->
  <!--   Root cause hypothesis -->
  <!--   Impact summary -->
  <!--   Affected modules (as badges) -->
  <!--   Exception list (expandable): -->
  <!--     For each fingerprint in cluster.exception_fingerprints: -->
  <!--       Look up in groups_by_hash → show exception class, source, count, severity -->
  <!--       Expandable: sample message, stack trace, module context -->
  <!--   Recommended actions (numbered list) -->
  <!--   Suggested ticket (if present) -->

  <!-- UNCORRELATED EXCEPTIONS -->
  <!-- Exceptions the LLM couldn't group. Still show them with details. -->

  <!-- FULL EXCEPTION TABLE -->
  <!-- Sortable table of ALL exception groups -->
  <!-- Columns: Source | Exception | Count | Severity | Status | Module | First Seen | Last Seen -->
  <!-- Click to expand: message, stack trace -->

  <!-- TREND OBSERVATIONS -->
  <!-- report.trend_observations as a list -->

  <!-- FOOTER -->
  <!-- Generation metadata, config used, link to prompts -->

  <script>
    /* Minimal JS: expand/collapse for exception details */
    /* Filter buttons: All | Critical | High | Novel */
    /* Sort table by clicking column headers */
  </script>

</body>
</html>
```

**NOTE FOR COPILOT**: The Jinja2 template should be ~300-400 lines. Don't over-engineer the JS. The expand/collapse is the only interactive feature that matters. Everything else is static HTML. Use CSS Grid for layout. The report must look professional when opened in Chrome on a VDI.

---

## 15. REQUIREMENTS — `requirements.txt`

```
pydantic>=2.0
pydantic-settings>=2.0
httpx>=0.24
jinja2>=3.1
mcp>=1.0
```

**That's it.** Five dependencies. No database, no web framework, no React. This is a script that generates an HTML file.

---

## 16. BUILD ORDER CHECKLIST

```
PHASE 0 — MCP Connection Test (~0.5 day)
  [ ] Copy mcp.json from DevGPT/Cline config
  [ ] Verify Splunk MCP server name + tools (list_tools)
  [ ] Verify Domain MCP server name + tools (list_tools)
  [ ] Run a test Splunk search via MCP → confirm real data returns
  [ ] Run a test Domain MCP search → confirm KB content returns
  [ ] Document actual tool names in config.py
  [ ] GATE: Both MCP servers return data. If not, debug auth (SID/token).

PHASE 1 — Splunk Pipeline (~1.5 days)
  [ ] config.py — fill in actual Splunk field names
  [ ] models.py — all models implemented
  [ ] mcp_client.py — McpClient + call_tool
  [ ] splunk_fetcher.py — aggregate + sample queries
  [ ] aggregator.py — fingerprinting + grouping + known patterns
  [ ] known_patterns/known_exceptions.json — seed with 3-5 patterns
  [ ] TEST: python main.py --no-llm --skip-domain → prints aggregated groups
  [ ] TEST: fingerprints are stable (same exception → same hash)
  [ ] TEST: known patterns match correctly
  [ ] GATE: Aggregated exception data looks correct in terminal output.

PHASE 2 — Domain Enrichment (~1 day)
  [ ] domain_enricher.py — search + parse module context
  [ ] TEST: python main.py --no-llm → groups now have module context
  [ ] TEST: module descriptions, dependencies, known issues populated
  [ ] GATE: At least 50% of sources map to modules. If less, add alias mapping.

PHASE 3 — LLM Correlation (~1 day)
  [ ] prompts/correlator_system.md — finalize system prompt
  [ ] prompts/correlator_user.md — finalize user template
  [ ] correlator.py — Claude API call + JSON parsing
  [ ] TEST: python main.py → full pipeline with LLM correlation
  [ ] TEST: LLM produces valid JSON that parses into CorrelationReport
  [ ] TEST: clusters make sense (related exceptions grouped together)
  [ ] TEST: executive summary is leadership-readable
  [ ] GATE: Correlation output adds genuine insight beyond raw aggregation.

PHASE 4 — HTML Report (~1 day)
  [ ] templates/report.html.j2 — Jinja2 template
  [ ] report_generator.py — template rendering
  [ ] TEST: python main.py → opens in Chrome → looks professional
  [ ] TEST: expand/collapse works for exception details
  [ ] TEST: filter buttons work (All / Critical / High / Novel)
  [ ] TEST: all data from correlation report is rendered
  [ ] GATE: Report is something Jey would show in a governance meeting.

PHASE 5 — Hardening (~0.5 day)
  [ ] Error handling — every MCP call gracefully degrades
  [ ] Logging — clean, structured, not overwhelming
  [ ] CLI args — all flags work (--time-range, --no-llm, --dry-run, etc.)
  [ ] Add 5+ more known patterns to known_exceptions.json
  [ ] Run against a full production day's data
  [ ] GATE: End-to-end run completes without errors on real data.
```

---

## 17. ARCHITECTURAL DECISIONS LOG

| # | Decision | Rationale | Alternative Considered | Why Rejected |
|---|----------|-----------|----------------------|-------------|
| AD-01 | Two Splunk queries (aggregate + sample) | Aggregate gives overview fast; samples give stack traces for fingerprinting | Single query returning everything | Too much data through MCP; response size > practical limit |
| AD-02 | Deterministic known-pattern matching before LLM | Faster, cheaper, more predictable for known issues; LLM focuses on unknowns | LLM for everything | Wastes tokens on known issues; less deterministic; slower |
| AD-03 | Single HTML file output (Jinja2) | No build step; opens anywhere; 5-day timeline | React app / Streamlit | Overkill for a daily report; adds complexity for no gain |
| AD-04 | Fingerprint = hash(source + exc_class + top_frame) | Groups identical errors in same code path; stable across runs | Message-only fingerprinting | Messages have variable content; would create too many unique fingerprints |
| AD-05 | Domain MCP for module context (not hardcoded mapping) | Uses existing KB; adapts as KB evolves; doesn't require code changes | Static JSON module map | Would need manual maintenance; diverges from actual KB |
| AD-06 | Claude Sonnet (not Opus) for correlation | Faster for daily use; good enough for structured analysis task | Opus for deeper reasoning | Overkill for correlation; Sonnet handles structured data well |
| AD-07 | JSON output from LLM (not free text) | Parseable; renderable; consistent; testable | Free-text analysis | Hard to render in HTML template; inconsistent structure |
| AD-08 | In-memory module cache (not persistent) | Simple; no database; cache only lives for one run | SQLite / file cache | Overengineering for a tool that runs once daily |
| AD-09 | requirements.txt not pyproject.toml | Simpler for a script-level project; works everywhere | Full Python packaging | This isn't a library — it's a script with 10 files |
| AD-10 | No scheduler built in | Use OS cron / Task Scheduler / existing orchestrator | Built-in APScheduler | Adds dependency; cron is simpler and more transparent |
