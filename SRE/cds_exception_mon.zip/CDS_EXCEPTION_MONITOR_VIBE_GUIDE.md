# Vibe Coding Playbook — CDS Exception Monitor

> **What this is**: A mental model + tactical guide for building the CDS Exception Monitor
> using GitHub Copilot (Claude Opus 4.6 / Sonnet) as your pair programmer.
>
> This is a 5-day build. Simpler than AEGIS — no agents, no execution engine,
> no approval gates. The pipeline is: query → aggregate → enrich → correlate → display.
> If you've done the AEGIS MCP work, Day 0 is already half done.

---

## THE MENTAL MODEL: PIPELINE, NOT AGENT

AEGIS was an agent system — it reasons, plans, executes, and adapts.
This tool is a **pipeline** — data flows in one direction through fixed stages.

```
Pipeline thinking:
  Splunk → Parse → Fingerprint → Enrich → Correlate → Render
  
  Each stage has:
  - A clear input type
  - A clear output type
  - A graceful degradation mode (what happens if this stage fails?)
  
  If Splunk fails    → stop (no data = no report)
  If Domain MCP fails → continue without module context
  If LLM fails       → show aggregated data without correlation
  If rendering fails  → print JSON to terminal as fallback
```

This means you can build and test each stage independently.
Stage N doesn't care how Stage N-1 produced its output —
it only cares about the output shape.

**Vibe coding implication**: You can literally build this left-to-right.
Each session adds one pipeline stage. At the end of each session,
you have a working pipeline that's one stage longer.

---

## RULES FOR WORKING WITH COPILOT

### Rule 1: One Stage Per Session

Each coding session = one pipeline stage. Don't mix stages.

```
Session 1: MCP connection → real Splunk data in terminal
Session 2: Splunk queries → aggregated exception data
Session 3: Fingerprinting + known patterns → classified exceptions
Session 4: Domain enrichment → exceptions with module context
Session 5: LLM correlation → structured analysis
Session 6: HTML report → visual output
Session 7: Integration + hardening → production-ready
```

### Rule 2: Feed the Spec Section, Not the Whole Spec

Before each session, paste the relevant section of `CDS_EXCEPTION_MONITOR_SPEC.md`.
Don't dump the whole spec — Copilot works better with focused context.

**Session opener pattern:**
```
I'm building the CDS Exception Monitor. Here's the spec for today's component:

[paste relevant section from IMPLEMENTATION_SPEC]

My current state:
- [what's already built and working]
- [what I'm building in this session]

Implement [specific file] following the spec exactly.
```

### Rule 3: Validate Output Shape at Every Stage

After each stage, print the output and visually verify:
- Aggregate query returns rows with expected fields
- Fingerprints are stable (run twice, same hash)
- Domain context has actual content, not empty strings
- LLM response parses into valid JSON
- HTML opens in browser without errors

### Rule 4: The Fallback Test

For each stage, test the "what if this breaks?" path:
```
"Now test: what happens if [Splunk/Domain MCP/LLM] is unavailable?
Comment out the real call and return an error response.
Does the pipeline continue? Does the report generate?"
```

This is critical. In production, Domain MCP will occasionally be down.
The LLM will occasionally return garbage. Your pipeline must survive.

---

## DAY-BY-DAY CODING PLAN

### DAY 0 (0.5 day): MCP CONNECTION VALIDATION

If you've already done AEGIS MCP setup, this is fast. If not, it's your first gate.

```
FIRST PROMPT:
"I have an mcp.json file with MCP server configurations for Splunk
and a domain knowledge base. Here's my mcp.json:

[paste your actual mcp.json]

Write a minimal Python script that:
1. Reads mcp.json
2. Connects to the Splunk MCP server
3. Calls list_tools()
4. Prints available tools and their descriptions
5. Then connects to the domain MCP server
6. Calls list_tools()
7. Prints available tools and their descriptions

Use the official mcp Python SDK."

OUTCOME A — Both servers connect:
  Document the actual tool names. Update config.py:
  - splunk_mcp_server_name = "actual_name"
  - domain_mcp_tool_search = "actual_search_tool_name"
  - domain_mcp_tool_read = "actual_read_tool_name"

OUTCOME B — Splunk works, Domain MCP fails:
  Build the pipeline first with Splunk only (--skip-domain flag).
  Debug Domain MCP separately.

OUTCOME C — Auth errors on either:
  Same SID passthrough debugging from AEGIS. Try:
  1. API token fallback in .env
  2. Check if npx is available on VDI
  3. Run MCP server command directly in terminal
```

**THEN — test a real Splunk query:**
```
"Now use the Splunk MCP search tool to run this query:
  search index=<your_index> level=ERROR earliest=-1h | head 10
Print the raw results."
```

**AND — test a Domain MCP search:**
```
"Now use the Domain MCP search tool to search for 'cds-gateway'.
Print the raw results."
```

**WIN: Both return real data. Document the response shapes.**

---

### DAY 1 (1.5 days): SPLUNK PIPELINE + AGGREGATION

```
SESSION 1A — Config + Models (30 min):

"I'm building the CDS Exception Monitor. Implement these two files
per the spec:

[paste Section 3: config.py from spec]
[paste Section 4: models.py from spec]

My Splunk field names are: [paste your actual field names from Day 0 testing]

Update config.py with my actual field names."
```

```
SESSION 1B — MCP Client (30 min):

"Now implement mcp_client.py per the spec:

[paste Section 5: mcp_client.py from spec]

I've already verified MCP connection works. The Splunk server is
named '[actual name]' and the search tool is named '[actual name]'."
```

```
SESSION 1C — Splunk Fetcher (1 hour):

"Now implement splunk_fetcher.py per the spec:

[paste Section 6: splunk_fetcher.py from spec]

IMPORTANT: Here's what a raw Splunk response looks like from my MCP:
[paste the raw response from your Day 0 test]

Make sure the parser handles this exact format."

TEST:
"Write a test script that:
1. Connects to Splunk MCP
2. Runs the aggregate query for the last 1 hour
3. Prints the parsed results: source, exception_class, count
Show me the output."
```

```
SESSION 1D — Aggregator (1 hour):

"Now implement aggregator.py per the spec:

[paste Section 8: aggregator.py from spec]

Use the real aggregate data from the previous test as input."

TEST:
"Run the full pipeline so far:
1. Fetch aggregate exceptions from Splunk
2. Fetch sample events for top 5 exception types
3. Build fingerprinted exception groups
4. Print: fingerprint_hash | source | exception_class | count | severity

Then run it again and verify fingerprint hashes are identical."
```

**DAY 1 WIN**: Terminal output showing aggregated, fingerprinted exceptions from real Splunk data.

---

### DAY 2 (1 day): DOMAIN ENRICHMENT + KNOWN PATTERNS

```
SESSION 2A — Known Patterns (30 min):

"Create known_patterns/known_exceptions.json with these patterns:

[describe your top 5-10 known exceptions — Jey, fill this in]

Example: 
- ConnectionException with 'Pithos' in message = known Pithos connectivity issue
- SocketTimeoutException = known downstream timeout pattern
- NullPointerException in DocumentController = known bug in doc retrieval

Then implement the match_known_patterns function and test it against
today's real exceptions."

TEST:
"Run the pipeline with --no-llm --skip-domain. Show me which exceptions
matched known patterns and which are novel."
```

```
SESSION 2B — Domain Enricher (1 hour):

"Now implement domain_enricher.py per the spec:

[paste Section 7: domain_enricher.py from spec]

Here's what the Domain MCP search tool returns for a query:
[paste raw Domain MCP response from Day 0]

Make sure the parser handles this format. The KB files are
[markdown/JSON/structured text — describe your actual KB format]."

TEST:
"Run the full pipeline with --no-llm. Show me the enriched groups:
source | exception_class | count | module_name | dependencies"
```

**DAY 2 WIN**: Exceptions mapped to CDS modules with context. Known patterns flagged deterministically.

---

### DAY 3 (1 day): LLM CORRELATION

```
SESSION 3A — Prompts (30 min):

"Create the correlator system prompt at prompts/correlator_system.md:

[paste Section 13 from spec]

And the user template at prompts/correlator_user.md.

Then show me what the complete user prompt looks like when populated
with today's real exception data. I want to review it before sending
to the LLM."

REVIEW: Read the populated prompt. Does it contain:
- All exception groups with counts and fingerprints?
- Module context for each?
- Known pattern matches?
- Clear instructions for JSON output?
If not, refine before proceeding.
```

```
SESSION 3B — Correlator (1 hour):

"Now implement correlator.py per the spec:

[paste Section 9: correlator.py from spec]

IMPORTANT: My ANTHROPIC_API_KEY is set in .env. The model is
claude-sonnet-4-20250514. Temperature 0.1."

TEST:
"Run the full pipeline including LLM correlation.
Print the correlation report:
- Executive summary
- Each cluster: title, root cause, confidence, affected modules
- Number of uncorrelated exceptions"
```

```
SESSION 3C — Correlation Quality Check:

"Here's the LLM correlation output:
[paste the JSON response]

Review this critically:
1. Do the clusters make sense? Are related exceptions grouped?
2. Are the root cause hypotheses reasonable?
3. Is the executive summary leadership-readable?
4. Are the recommended actions actually actionable?

If any cluster seems wrong, suggest prompt changes to fix it."
```

**DAY 3 WIN**: LLM produces meaningful correlation that adds insight beyond raw aggregation.

---

### DAY 4 (1 day): HTML REPORT

```
SESSION 4A — Template (2 hours):

"Create the Jinja2 HTML template at templates/report.html.j2.

[paste Section 14 from spec: template structure]

Design requirements:
- Dark theme (background #1a1a2e, text #e0e0e0)
- Self-contained — all CSS inline in <style>
- Monospace font for technical data (fingerprints, exception classes)
- Cards for each cluster with expand/collapse for details
- Color-coded severity badges
- Module health overview at the top
- Must look professional in Chrome on my VDI

Here's the data model it receives:
[paste the Pydantic models: CorrelationReport, CorrelatedCluster, EnrichedExceptionGroup]"
```

```
SESSION 4B — Report Generator (30 min):

"Implement report_generator.py per the spec:

[paste Section 10: report_generator.py from spec]"

TEST:
"Run the full pipeline end-to-end: python main.py
Open the generated HTML in Chrome. Screenshot or describe what you see."
```

```
SESSION 4C — Polish:

"The report looks [describe issues]. Fix:
- [list specific visual issues]
- Add filter buttons at the top: All | Critical | High | Novel
- Make the cluster cards collapsible
- Add a 'Copy as JSON' button for each cluster
- Make the full exception table sortable by count"
```

**DAY 4 WIN**: Professional HTML report that Jey would show in a governance meeting.

---

### DAY 5 (0.5 day): HARDENING + FIRST PRODUCTION RUN

```
SESSION 5A — Error Handling:

"Review all files for error handling:
1. What happens if Splunk returns 0 results?
2. What happens if Domain MCP is down?
3. What happens if LLM returns invalid JSON?
4. What happens if a Splunk field is missing from an event?
5. What happens if mcp.json is malformed?

For each case, ensure the pipeline degrades gracefully and the report
still generates with whatever data is available."
```

```
SESSION 5B — CLI Polish:

"Verify all CLI flags work:
  python main.py                      → full run, last 24h
  python main.py -t -4h               → last 4 hours
  python main.py --no-llm             → skip LLM
  python main.py --skip-domain        → skip Domain MCP
  python main.py --dry-run            → show queries only
  python main.py -o custom_report.html → custom output path"
```

```
SESSION 5C — Production Run:

"Run against a full 24-hour production window.
Review the report critically:
- Are the exception counts plausible?
- Do the module mappings make sense?
- Are the correlations insightful?
- Is the executive summary accurate?
- Would this save an SRE 30 minutes of manual Splunk checking?"
```

**DAY 5 WIN**: Production-quality report from real CDS data.

---

## DEBUGGING PLAYBOOK

### When Splunk MCP returns empty results:
```
1. Verify the index name in config.py
2. Try a simpler query: "search index=<name> | head 5"
3. Check if the time range is correct (timezone issues?)
4. Verify the MCP tool name (search vs query vs run_search)
5. Try the same query in Splunk web UI — does it return data?
```

### When fingerprints are unstable (different hash each run):
```
1. Check if stack_trace content varies (timestamp in stack?)
2. Check if message has variable content that's not templatized
3. Add logging to compute_fingerprint to see input components
4. Verify _extract_top_app_frame is consistent
```

### When Domain MCP returns no matches:
```
1. Check the actual KB file names — do they match source names?
2. Try a broader search query
3. Check if the Domain MCP search tool needs different arguments
4. Consider adding an explicit source → module mapping dict
5. If <50% mapping rate, build a manual mapping file as fallback
```

### When LLM returns unparseable JSON:
```
1. Check if the response starts with ```json (strip markdown fences)
2. Check if the response is truncated (increase max_tokens)
3. Check if the prompt is too large (reduce exception count)
4. Add "Respond with ONLY valid JSON." to the system prompt
5. Add a retry with a shorter prompt (top 20 exceptions only)
```

### When the HTML report looks broken:
```
1. Check for Jinja2 escaping issues (use |e filter for user data)
2. Check for unclosed HTML tags (Jinja2 loops with conditionals)
3. Verify all template variables are populated (check context dict)
4. Open browser dev tools console — look for JS errors
```

---

## THE QUALITY BAR

Before you call this done, run this checklist:

```
PIPELINE QUALITY
  [ ] Runs end-to-end on real production data without errors
  [ ] Handles Splunk returning 0 results gracefully
  [ ] Handles Domain MCP being down gracefully
  [ ] Handles LLM returning garbage gracefully
  [ ] All CLI flags work correctly
  [ ] Fingerprints are stable across runs
  [ ] Known patterns match correctly (test with at least 5 patterns)

CORRELATION QUALITY
  [ ] LLM clusters make sense (related exceptions grouped)
  [ ] Root cause hypotheses are reasonable, not generic
  [ ] Executive summary is leadership-readable
  [ ] Novel patterns are flagged for investigation
  [ ] Recommended actions are specific, not boilerplate

REPORT QUALITY
  [ ] Opens clean in Chrome on VDI
  [ ] Dark theme, professional look
  [ ] Expand/collapse works for exception details
  [ ] Filter buttons work (All/Critical/High/Novel)
  [ ] Module health overview is accurate
  [ ] Would show this in a governance meeting? If no, iterate.

OPERATIONAL QUALITY
  [ ] Total runtime < 5 minutes for a full day's data
  [ ] LLM cost < $0.50 per run (Sonnet, structured data)
  [ ] Logging is clean and structured (not overwhelming)
  [ ] Output file naming is date-stamped
  [ ] Can run via cron / Task Scheduler without interaction
```

---

## WHAT COMES NEXT (After MVP)

Once the basic pipeline works, here are the highest-value additions
in priority order:

### 1. Trend Comparison (2 days)
Store daily fingerprint counts in a JSON file. Compare today vs
yesterday / last 7-day average. Flag: "NullPointerException in
cds-gateway increased 300% compared to 7-day average." This turns
the report from "here's today" to "here's what changed."

### 2. Scheduled Execution (0.5 day)
Set up a cron job or Windows Task Scheduler to run at 9:00 AM IST
daily. Email the HTML report or save to a shared drive.

### 3. Multi-Day Dashboard (3 days)
Instead of per-day HTML files, build a lightweight web UI (Flask +
HTMX, no React) that shows trends over time. Exception counts by
module as time-series charts.

### 4. AEGIS Integration (2 days)
Feed the daily correlation report into AEGIS as a context source.
When AEGIS investigates an incident, it checks: "Was this exception
pattern flagged in today's morning report?"

### 5. Slack Notification (1 day)
Post the executive summary + critical clusters to a Slack channel.
The team sees it at standup without opening the report.

---

## SESSION TRACKING TEMPLATE

Copy this for each coding session:

```
## Session [N] — [Date]
### Goal: [one sentence]
### Phase: [0/1/2/3/4/5]
### Files touched: [list]
### What worked:
### What didn't:
### Blockers:
### Actual Splunk tool name: [filled in on Day 0]
### Actual Domain MCP tool names: [filled in on Day 0]
### Next session should:
```

---

## THE MOST IMPORTANT THING

This tool's value is not in the code — it's in the **daily operational habit**
it creates. If your team opens this report every morning before standup and
spends 2 minutes scanning it instead of 30 minutes in Splunk, you've won.

The code is the easy part. The habit is the hard part.

Build it, run it for a week, iterate based on what the team actually looks at,
and cut everything they don't. A 5-section report the team reads every day
beats a 20-section report nobody opens.
