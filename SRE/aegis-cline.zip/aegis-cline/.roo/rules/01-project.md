# 01 — Project Context

## What AEGIS is

AEGIS is an agentic incident automation platform for SRE operations in a Tier-1 bank. It diagnoses production incidents, generates dynamic runbooks against the affected service, and executes remediation through MCP-based tool integrations — under human approval gates calibrated to risk.

It is not a chatbot. It is not a general-purpose agent framework. It is an opinionated SRE platform with a specific architecture and a specific risk posture.

## The architecture in one paragraph

A **Strategist** agent receives an incident signal (alert, ticket, or human invocation), enriches it with observability and code context, and emits a **Dynamic Runbook** — a structured plan with ranked hypotheses, confidence-scored steps, and pre-staged actions. **Sub-Agents** execute individual steps through **MCP servers** (Splunk, Dynatrace, AIOps, SLO Tracker, Remediation, Confluence, Jira). A **Verify Loop** re-queries observability after execution and either declares the incident resolved, escalates, or hands back to the Strategist with new context.

## The three fix modes

Every onboarded service is in exactly one of these modes at any moment:

- `suggest_only` — AEGIS proposes the runbook. Humans drive every action. AEGIS executes nothing.
- `approval_required` — AEGIS proposes and stages actions. Humans approve. AEGIS then executes.
- `auto` — AEGIS executes scoped actions without per-incident approval. Only available for Tier-3 services after passing graduation criteria. One-click rollback is always present.

The mode is a property of the **service**, not the agent. The same agent serves all three modes; the mode is enforced at the action gate, not the prompt.

## Current stack

- **Language:** Python 3.12
- **Service framework:** FastAPI with async-first handlers
- **Models:** Anthropic Claude — Opus for Strategist, Sonnet for Sub-Agents, Haiku for high-volume classification
- **Data:** PostgreSQL (in flight — migrating from SQLite) with `pgvector` for embeddings
- **Tool integration:** MCP (Model Context Protocol) — every external system goes through MCP, no direct API calls in agent code
- **UI:** React (separate repo: `aegis-console`)
- **Streaming:** Server-Sent Events for agent reasoning streams
- **Identity (planned):** JPMC IDAnywhere via OIDC
- **Secrets (planned):** HashiCorp Vault

## Current phase

We are at the **end of Phase 0 (MVP)** and at the **start of Phase 1 (Production Hardening)**. The roadmap is in `ROADMAP.md`. The order of phases is non-negotiable — hardening earns code context, code context earns onboarding scale.

## What AEGIS is not

- Not a generic agent framework. Don't introduce abstractions that try to make it one.
- Not a replacement for human SREs. It is a force multiplier that earns trust through evidence.
- Not allowed to take destructive action without a clear, written, human-approved policy.
- Not a place to experiment with bleeding-edge agent patterns at the cost of operability.

## Vocabulary used in this codebase

- **Incident** — a real or potential service degradation requiring response.
- **Signal** — the upstream event that triggers an incident (Dynatrace problem, Splunk alert, human invocation).
- **Runbook** — a structured plan, not a wiki page. It is a typed object with steps, hypotheses, confidence scores, and gates.
- **Step** — a single action in a runbook. Maps to one Sub-Agent invocation.
- **Action** — a Sub-Agent's effect on the world (restart, scale, toggle flag, page).
- **Mode** — `suggest_only` | `approval_required` | `auto`.
- **Engagement** — the relationship with an onboarded app team. Has lifecycle stages: Discovery → Onboard → Shadow → Promote → Sustain.

Use these terms consistently. Don't introduce synonyms. If a new concept is needed, propose it explicitly in a task discussion, don't invent it in code.
