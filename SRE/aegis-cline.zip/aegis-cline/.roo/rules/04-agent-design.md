# 04 — Agent Design Principles

When designing or modifying an agent, work from these principles. They are the difference between an agent that survives in production and one that doesn't.

## 1. The smallest useful agent

Before adding capability to an agent, ask: can the orchestrator handle this deterministically? If yes, do that. An agent earns its complexity by being the right tool for a fuzzy job, not by being the default tool.

Concretely: classification is often a Haiku call, not an agent. Routing is often a deterministic function, not an agent. The Strategist is an agent because synthesising observability + code + history into a ranked-hypothesis runbook is genuinely fuzzy. The mode-checker is not an agent because "is this service in auto mode?" is a database read.

## 2. Tool-use over freeform output

When an agent emits structured information, use Anthropic's tool-use API. The model emits a tool call with a typed payload; you parse it into a Pydantic model. This is more reliable than JSON-mode and far more reliable than parsing free text.

The exception is genuinely open-ended outputs (the hypothesis narrative, the human-facing summary). For those, JSON-mode with a strict schema works.

## 3. Explicit confidence, not implied confidence

Every hypothesis, every step, every recommendation carries a numerical confidence score. The score is part of the schema, not buried in prose. Downstream gates (the auto-execution gate, the alerting gate) read the score, not the text.

If you find yourself writing a prompt that asks for "your best judgment," ask for a score on the same axis the gate is reading from. Otherwise the gate is uncalibrated.

## 4. Context windows are budgets, not buffers

Don't dump everything available into the prompt. Curate. The Strategist gets the alert, the curated observability summary, the curated code context, and the top-3 historically similar incidents — not the entire log stream and the whole repository.

Curation logic lives in `orchestrator/context.py`. It is testable, observable, and tuneable. If a curation rule was helpful, write it down; if it wasn't, delete it.

## 5. Failure modes documented before merge

Before an agent ships or a meaningful change merges, the PR includes an entry in `docs/failure-modes.md` describing:
- How the agent fails (what does the wrong output look like?)
- What's the blast radius if the failure isn't caught?
- What catches it? (eval, gate, human, downstream check)
- What's the residual risk we accept?

If you can't fill this in, you don't understand the change well enough to merge it.

## 6. Evals are the contract

A change to an agent's prompt or logic must be accompanied by an eval result that demonstrates it didn't regress on the golden set. The eval harness is the contract between the agent's authors and the rest of the system. "It worked when I tried it manually" is not evidence.

The eval harness lives in `evals/`. Adding a new case is easy. Run before pushing.

## 7. Graceful degradation, not silent failure

If a context source (e.g. the code resolver) returns nothing useful, the agent falls back to a degraded mode (symptom-only runbook) and **says so** in its output. The runbook is tagged `code_context: unavailable` and the gate adjusts accordingly. Silent degradation is the worst failure mode — the operator thinks they have a code-aware suggestion when they don't.

## 8. Streaming is for humans, not for downstream agents

We stream agent tokens to the human operator's console because they're watching it think. We do not feed one agent's mid-flight tokens to another agent. Inter-agent communication is on completed, typed outputs. Streaming-in is a footgun: it forces downstream agents to handle partial state, and it couples failure modes.

## 9. Determinism where you can, agents where you must

A retry policy is deterministic. A timeout is deterministic. A circuit breaker is deterministic. A "should I retry?" decision rarely needs an agent. Strategist invocations are expensive; reserve them for the decisions that genuinely benefit from synthesis.

A useful test: if a senior SRE could write a 20-line function that captures 90% of the decision, that's a function. If the decision varies meaningfully with context and the SRE would need a 5-page runbook, that's an agent.

## 10. The agent doesn't own the world model

The Strategist doesn't track which services are in which mode. It doesn't track the current on-call. It doesn't track whether a deploy is in flight. All of those are external state, fetched as part of context, and re-fetched per invocation. Agents are stateless; the world is stateful.

This is why the audit log is the source of truth: it can be replayed. If state lived in the agent, replay would be impossible.

## 11. Cost is a design constraint

Every prompt design decision has a cost. Prompt-caching is a real lever — use it for stable system prompts and the project ruleset. A Strategist invocation that costs $0.40 per incident at 5,000 incidents/month is $2K/month — fine. The same Strategist invoked once per log line is bankrupting.

Watch the cost dashboard. If a feature lands and costs jump, the feature owes an explanation.

## 12. The eval set is alive

A static golden set rots. Add new cases from real incidents on a weekly cadence. Retire stale cases when the underlying system has changed. The set is curated, not collected.

The eval set lives in `evals/golden/`. New cases land via PR, with the labeling provenance documented.
