# 05 — Security & Governance

AEGIS operates inside a Tier-1 bank. The security and governance posture is not "best practice" — it is a precondition for the platform existing at all. Treat every item below as a hard rule.

## Secrets

- **No secrets in code, tests, configs, or logs.** Ever.
- Secrets resolve through Vault references at runtime. Code references look like `vault:secret/aegis/splunk/token`, never the raw value.
- Local development: `direnv` with `.envrc` that pulls from Vault on shell activation. `.envrc` itself contains no secrets, only the Vault path pattern.
- CI scans every commit with `gitleaks`. A failed scan blocks the merge. If a secret was committed, rotate it, then clean history.
- Test fixtures use obvious fake values: `sk-test-FAKE-DO-NOT-USE`, not anything that could pass as real.

## Identity & authorisation

- All human access through SSO (JPMC IDAnywhere via OIDC). No local accounts.
- All service-to-service identity through scoped service principals, not shared accounts.
- RBAC at the granularity of: agent definitions, runbook execution, action approval, audit log read. No role implies another except by explicit grant.
- Just-in-time elevation for `auto`-mode promotions and for production data access. Logged, reviewed weekly.

## Data classification & PII

- Every log line, every alert, every ticket text is treated as **potentially containing PII or customer data** until proven otherwise by the redaction layer at ingestion.
- The redaction layer runs **before** anything is sent to an LLM. We do not send raw production data to model APIs.
- Patterns redacted by default: card numbers, account numbers, names alongside account context, SSNs, phone numbers, emails alongside customer context, IP addresses where customer-identifying.
- The redaction layer is testable, has a golden set of its own, and any change to it requires an eval pass.

## Prompt injection

- All external text (logs, tickets, comments, file contents from indexed repos) is partitioned in the prompt with explicit delimiters and a system instruction that the content within is data, not instruction.
- Tool-use schemas constrain the model's output channel; the model cannot exfiltrate by writing instructions that bypass the schema.
- An injection-detection eval runs on every release. The set includes both naive injections (`"Ignore all prior instructions"`) and sophisticated ones (instructions hidden in seemingly innocuous log content).

## Audit log

- Every decision, tool call, action, and mode change is written to the immutable audit log.
- Audit storage is **separate** from operational data. Different database, different credentials, different backup policy.
- Retention: 7 years.
- Write path is append-only at the storage layer (no DELETE, no UPDATE). Enforced by storage permissions, not by application discipline.
- Audit-log access is itself audited.

## Action governance

- Destructive actions (delete, drop, truncate, force-quit a transaction) are **never** available in `auto` mode. This is enforced in the executor, not just the runbook generator.
- Production data write actions require `approval_required` mode minimum.
- Every action carries an idempotency key. Replays are safe.
- Every action has a documented rollback path that ships with the action, not after.

## Change management

- Production AEGIS releases go through change control. The CAB integration in Phase 4 makes this automatic; until then, it's a manual ticket per release.
- Mode promotions (`suggest_only` → `approval_required` → `auto`) for an onboarded service are change events. They are reviewed, approved, and logged. The agent does not auto-promote.

## Third-party dependencies

- Every new dependency requires: a license check (allow-list), a security scan (no known criticals), and a justification in the PR.
- Direct vendor SDK use for production systems is **prohibited** — go through MCP. (Restated here because it's a security property, not just an architecture one: bypassing MCP bypasses audit logging.)
- Pin versions. Renovate (or equivalent) opens PRs for upgrades; humans review.

## Model interactions

- All Anthropic API traffic goes through a single egress proxy that enforces token-budget caps, logs request shape, and applies the redaction rules above.
- Model output is **never** trusted as control plane. The output is parsed, validated, and gated. The model cannot directly cause a write to production.
- We do not send model-API traffic from developer laptops to production data. Local development uses synthetic incidents and mocked context.

## Reportable events

The following must be reported immediately (not in a weekly digest):

- Any suspected prompt injection that bypassed the partition layer.
- Any secret committed to a repo, including ones caught by CI.
- Any production action executed without the appropriate audit log entry.
- Any agent operating in `auto` mode for a service that was supposed to be in a lower mode.
- Any access to the audit log by an identity outside the auditor role.

Use the channel in `docs/incident-response.md`. There is no penalty for over-reporting; there is a serious one for under-reporting.

## What the agent should not invent

- Don't write your own crypto. We use `cryptography` for symmetric, JWT libraries for tokens, never roll your own.
- Don't write your own RBAC engine. We use Casbin with policies in `policies/`.
- Don't add new identity providers without an explicit task and security review.
- Don't bypass the redaction layer to "see real data" during development. Use synthetic fixtures.
