# 02 — Architecture Invariants

These are non-negotiable properties of the system. If a task would violate one of these, **stop and flag it before writing code**. Invariants change through an explicit RFC in `docs/`, not through a refactor.

## Invariant 1 — Tool integration goes through MCP

No agent code calls Splunk, Dynatrace, Jira, Confluence, or any external system directly. Every external interaction goes through an MCP server. If a new integration is needed, the answer is "add an MCP adapter," not "import the vendor SDK."

Rationale: uniform observability, uniform auth, uniform retry/circuit-breaker behavior, uniform audit logging. Bypassing MCP loses all of these.

## Invariant 2 — Three fix modes, enforced at the action gate

`suggest_only`, `approval_required`, `auto` — these are the only modes. The mode lives on the **service**, not the agent. The Sub-Agent executor checks mode immediately before executing an action; it does not trust the runbook to enforce it.

A Sub-Agent that runs an action without checking the service's current mode is a bug, regardless of how convenient the optimization.

## Invariant 3 — Immutable audit log

Every agent decision, every tool call, every action execution, and every mode change is written to an append-only audit log. The audit log is the source of truth for "what happened and why." It is consulted in post-mortems and audits. Do not write code paths that bypass it.

Schema is in `docs/audit-schema.md`. Retention is 7 years. Storage is separate from the operational database.

## Invariant 4 — Idempotency on every action

Every Sub-Agent action carries an idempotency key derived from `(incident_id, step_id, action_signature)`. Replaying the same action with the same key is a no-op that returns the original result. This holds even across crashes, retries, and operator intervention.

Network partitions and operator double-clicks happen weekly. Idempotency is what keeps them from cascading.

## Invariant 5 — Confidence thresholds gate auto-execution

The Strategist emits a confidence score on every hypothesis and every step. The executor refuses to execute in `auto` mode below a configurable per-action threshold. The threshold is part of the service's profile, not a constant.

Default: 0.75 for low-blast-radius actions (restart, scale-up), 0.90 for higher-blast-radius (revert, feature-flag toggle), `auto` mode never available for destructive actions (delete, drop, truncate).

## Invariant 6 — Structured outputs, always

Agents emit JSON conforming to a Pydantic schema. Free-text from a model is parsed into a typed object before any downstream code touches it. Validation failures are loud, not silently coerced.

Implementation: prefer tool-use as the structured output mechanism. Fall back to JSON-mode only when tool-use is awkward (e.g. open-ended hypothesis lists).

## Invariant 7 — Token budgets per agent

Every agent has a token budget per invocation, declared in its config. The orchestrator enforces it. An agent that blows its budget produces no output, raises an exception, and is logged.

Default budgets:
- Strategist (Opus): 8K context retrieval + 4K output
- Sub-Agent (Sonnet): 4K context + 2K output
- Classifier (Haiku): 2K context + 512 output

Tune per-agent in code, but never remove the cap.

## Invariant 8 — Prompt injection defence on every external input

Anything that came from outside AEGIS — log lines, ticket text, Slack messages, Confluence pages — is treated as untrusted input. It is partitioned in the prompt with explicit delimiters and a system-level instruction that the content within is data, not instruction.

This is checked by the eval harness. Any code path that splices external text directly into a prompt without partitioning is a regression.

## Invariant 9 — No secrets in code, configs, or logs

Secrets resolve through Vault references at runtime. The codebase contains references like `vault:secret/aegis/splunk/token`, never the secret itself. CI fails on commits that contain anything resembling a credential.

If you need a secret for local development, use `direnv` with a `.envrc` that pulls from Vault on activation. Never commit `.env`.

## Invariant 10 — Rollback path before action ships

Every Sub-Agent action ships with a documented rollback path. The rollback is either automatic (transactional), staged (pre-computed and waiting), or documented (in the runbook with the on-call playbook). Actions without a rollback story do not merge.
