# 06 — Task Discipline

How to work inside this codebase. This rule exists because thinking budget is finite, conversation context decays, and over-planning is a more common failure than under-planning.

## Before starting any task

1. **Read the rules.** All of `.roo/rules/` should be in context. If you're starting a fresh session, that happens automatically. If you're not sure, confirm.
2. **Read the task file** in `tasks/` if one was referenced. The task file is the spec — do not infer scope from a one-line user message when a task file exists.
3. **Check `.roo/memory.md`** for anything you (the agent) previously learned about this codebase that's relevant.

## Scope confirmation

For any task estimated to take more than ~30 minutes of agent work, **restate the scope before writing code.** The restatement includes:

- What you're going to do (in one paragraph).
- What you're explicitly **not** doing (the things adjacent that might tempt scope creep).
- Any assumptions you're making about the codebase or the requirements.
- Any open questions the user should answer before you start.

Wait for confirmation. The 60 seconds spent here saves the 60 minutes of unwinding a wrong direction.

For trivial tasks (a typo fix, a one-line config change), skip the confirmation — but you should know which category you're in.

## Tight task scope is a feature

Tasks in `tasks/` are intentionally narrow. If a task seems to need to span multiple files or systems, that's usually a sign the task should be split, not that you should make the change anyway.

If you decide a task as written is wrong, **say so** rather than executing a different task than the one written. Propose the new scope; let the human approve the change.

## One task, one branch, one PR

Each task gets its own branch named `task/NNN-short-name`. Commits on that branch implement only that task. The PR title references the task: `feat(orchestrator): execute task 003 — audit log schema`.

Do not rebase other people's branches. Do not merge unrelated work into your branch. If your task is blocked by another, say so and stop, don't sneak the other work in.

## Thinking budget discipline

- **Cap thinking tokens** for routine implementation. Routine = the architecture is decided and the task file describes it. 2,000–5,000 thinking tokens is plenty.
- **Higher budget** for genuinely architectural moments: new agent design, new MCP integration, new invariant being considered. 10,000+ is fine here.
- **No thinking** for mechanical tasks: rename, reformat, dependency bump. Use the `--no-thinking` mode or equivalent.

Over-planning is the more common failure than under-planning. If you find yourself producing a 3-page plan for a 30-line change, you've miscalibrated.

## When to clear context

Aggressively. Specifically:

- **After every merged task.** Start a new session.
- **When the conversation has been about three different things.** Drift accumulates; the rules in `.roo/rules/` will re-anchor.
- **When you're getting weird outputs.** Stale context is the most common cause. Clear and retry before debugging the prompt.

`/newtask` is your friend. The rules persist; the conversation does not need to.

## Use `memory.md`

When you learn something durable about this codebase, append to `.roo/memory.md`. Examples:

- "The Splunk MCP times out on queries > 60s; chunk them at the orchestrator."
- "Postgres `pgvector` extension must be `CREATE EXTENSION`'d before migrations run."
- "The Dynatrace MCP returns `entity_id` not `entityId` despite docs — adapter normalizes."

The user can read it; future agent sessions read it. It is the project's running journal.

Do not put anything in `memory.md` that should be in code (constants, schemas) or in docs (architecture decisions). It's for tacit knowledge that doesn't have a better home.

## Test as you go

Tests are not a separate task. They land in the same PR as the code they test. The CI gate requires it.

If a task as written says "implement X" without mentioning tests, **add the tests anyway**. It's not scope creep; it's table stakes.

## When to stop and ask

- The task touches an invariant (Rule 02).
- The task requires a new dependency.
- The task requires a schema change with no migration story.
- The task requires production credentials or production data access.
- The task seems to be solving the wrong problem.

In all of these, stop and ask. The human cost of one clarifying question is much smaller than the cost of unwinding a wrong direction.

## What "done" looks like for a task

- Code implements the task as specified.
- Tests cover the happy path and at least the two most likely failure modes.
- Type-check passes (`mypy --strict` on touched packages).
- Lint passes (`ruff`, `black`).
- The eval harness (if relevant) passes with no regression.
- The PR description references the task file and explains what changed.
- If an invariant was relevant, it's restated in the PR description as evidence of compliance.
- If a failure mode was added or changed, `docs/failure-modes.md` is updated.

If any of these is missing, the task is not done. Don't ask the human to merge an incomplete task.
