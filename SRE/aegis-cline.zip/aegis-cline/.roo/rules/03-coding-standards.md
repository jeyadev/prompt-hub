# 03 — Coding Standards

## Language & version

- **Python 3.12** — use modern features: `match`/`case`, structural typing, `Self`, PEP 695 type params where they help.
- **Type hints are required**, not optional. CI runs `mypy --strict` on `agents/`, `orchestrator/`, and `mcp/`.
- **No `Any`** without a comment explaining why.
- **Async-first** — agent and HTTP code is async. Sync helpers exist only for pure CPU-bound work and are clearly marked.

## Toolchain

- `ruff` for linting and import sort. Config in `pyproject.toml`. No exceptions, no `# noqa` without an issue number.
- `black` for formatting. Line length 100.
- `mypy --strict` on the core packages above.
- `pytest` with `pytest-asyncio`. Coverage gate 80% on `agents/` and `orchestrator/`.
- `pre-commit` runs all of the above. If pre-commit fails, fix the code, not the hook.

## Project layout conventions

- One agent type per file in `agents/`. Module name matches the agent's role: `agents/strategist.py`, `agents/sub_agent_remediator.py`.
- MCP adapters in `mcp/`, one per integration: `mcp/splunk.py`, `mcp/dynatrace.py`. Each exposes a typed client built on a common `mcp.base.Client`.
- Orchestration code in `orchestrator/`. The orchestrator owns the lifecycle of an incident: receive → enrich → strategise → execute → verify.
- FastAPI routers in `app/routers/`. Routers are thin — business logic lives in `orchestrator/` and `agents/`.
- Tests co-located with source: `agents/strategist.py` has `agents/test_strategist.py` next to it.

## Pydantic discipline

- **Pydantic v2** for all models that cross a boundary (HTTP, MCP, agent output, database).
- Models go in `<package>/models.py` or, for larger packages, `<package>/schemas/`.
- Validation is loud — invalid input raises `ValidationError`, not silently coerced.
- Use `Field(...)` constraints aggressively: lengths, ranges, regex, enum values.
- For agent outputs, use Pydantic to validate the structured response from the model. If parsing fails, the agent retries once with the validation error in the prompt, then raises.

## FastAPI patterns

- Dependency injection for everything: auth, DB session, MCP clients, agent factories. No globals.
- One responsibility per endpoint. If a handler is more than ~30 lines, the logic belongs in `orchestrator/` or `agents/`.
- Background work (long-running agent runs) uses an actual task queue, not `BackgroundTasks`. We use Arq on Redis for now; if changed, document why.
- SSE endpoints stream from an async generator that yields typed events: `event: token`, `event: tool_use`, `event: tool_result`, `event: done`, `event: error`.

## Database

- Migrations via Alembic. Never `create_all()` in production code paths.
- Use SQLAlchemy 2.0 style — `select(...)` not the legacy query API.
- Async sessions only — `AsyncSession`.
- No `N+1` queries — if you find yourself in a loop with a query inside, stop and write a join or a bulk fetch.

## Testing

- **Test the boundary, not the internals.** For an agent, test the prompt → output contract, not the prompt construction.
- For prompts: snapshot the prompt against a fixture; require explicit acknowledgement when it changes.
- For MCP adapters: use a recorded fixture (VCR-style) for the happy path, hand-crafted mocks for failure modes.
- For agents: use a model stub by default; mark integration tests that hit the real API with `@pytest.mark.integration` and run them only in CI nightly.
- One assertion per test where possible. If you have to use `subTest`, you probably wanted two tests.

## Commits and PRs

- Conventional commits: `feat(orchestrator): add confidence-score gate`, `fix(mcp.splunk): handle 429 with jitter`.
- One concern per commit. Don't sneak a refactor into a feature commit.
- Every PR has: title, what changed, why it changed, how it was tested, and any roadmap reference. The agent should write this; you should read it.
- No PR without tests. "It's just a config change" is not an exemption.

## Style points the agent should respect

- Functions describe what they return, not what they do. `compute_confidence_score()` not `calculate_and_return_the_score_based_on()`.
- No multi-line lambdas. If it needs two lines, it needs a name.
- Early returns over deep nesting.
- Comments explain **why**, not **what**. The code is the what.
- If a function is over 50 lines, split it. Strategist orchestration is allowed to be longer; flag it explicitly with a comment if it must be.

## What the agent should not do

- Don't introduce new dependencies without discussing them in the PR. Each dependency is a maintenance debt.
- Don't add abstraction layers speculatively. We add them when the second concrete need appears, not the first.
- Don't reformat unrelated code in a PR. Touch what the task requires.
- Don't write your own retry/circuit-breaker — use `tenacity` and `pybreaker`, both already in the stack.
