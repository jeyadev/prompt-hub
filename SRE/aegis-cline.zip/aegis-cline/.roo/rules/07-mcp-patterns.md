# 07 — MCP Patterns

Every external system AEGIS talks to goes through an MCP server. This rule describes how MCP clients should be built inside the AEGIS codebase, how to test them, and the conventions that keep them consistent.

## Adapter shape

Every MCP adapter exposes a class in `mcp/<system>.py` that:

- Inherits from `mcp.base.MCPClient`.
- Declares the MCP tools it exposes as typed methods.
- Uses Pydantic models for request and response payloads.
- Handles retry, timeout, and circuit-breaker behavior **at the base class**, not in each adapter.

Adapter authors implement business-meaningful methods. Plumbing (auth, retry, telemetry, logging) is inherited.

## The base client

`mcp.base.MCPClient` provides:

- **Transport** — SSE or stdio depending on server type, abstracted away.
- **Auth** — pulls credentials from Vault references at construction time.
- **Retry** — `tenacity` with exponential backoff and jitter. Default 3 retries on 5xx, 0 retries on 4xx.
- **Circuit breaker** — `pybreaker` per-server. After 5 consecutive failures in 60s, opens for 30s.
- **Timeout** — per-call deadline, default 30s, overridable.
- **Tracing** — every call emits an OpenTelemetry span with `mcp.server`, `mcp.tool`, `mcp.duration_ms`, `mcp.outcome`.
- **Audit** — every call is written to the audit log with the request and response (after redaction).

Adapter authors do not implement any of the above. If you find yourself writing retry logic in a Splunk adapter, stop — it belongs in the base class.

## Method naming

Adapter methods describe **what** in business terms, not **how** in protocol terms:

✅ `splunk.recent_errors_for_service("cds-gateway", window="1h")`
❌ `splunk.execute_spl("search index=app earliest=-1h | stats count by error")`

The SPL is an implementation detail of `recent_errors_for_service`. Hide it.

This makes the agent prompts clean: the model calls `recent_errors_for_service`, which is a name with semantic meaning, rather than constructing SPL from scratch.

## Error handling

Three exception types, all from `mcp.base.exceptions`:

- `MCPTransportError` — the MCP server is unreachable, returned 5xx, or timed out. Retriable.
- `MCPProtocolError` — the response shape was wrong, schema validation failed, tool not found. Not retriable.
- `MCPDataError` — the call succeeded but the data indicates a problem on the remote system (e.g. Splunk returned a parse error for our query). Caller decides what to do.

The orchestrator catches these explicitly. Sub-Agents do not catch them — they propagate, and the orchestrator decides whether to retry, degrade, or escalate.

## Schemas

Every MCP call has a Pydantic request model and a Pydantic response model in `mcp/<system>/schemas.py`. Models are versioned by file convention:

- `schemas.py` — current
- `schemas_v1.py`, `schemas_v2.py` — older, retained for replay against historical audit logs

Schemas are append-only — fields can be added (with defaults), but never removed. If a vendor changes their API in a breaking way, we version the schema, not delete it.

## Local development mocks

For each MCP server, `mcp/<system>/mock.py` provides a stub that:

- Implements the same interface as the real client.
- Returns fixture data from `mcp/<system>/fixtures/`.
- Can be configured to inject failure modes (timeout, 5xx, malformed response) for testing.

The dependency-injection wiring picks the real or mock client based on an environment variable. Default in `dev` and `test` is `mock`. Production is `real`. There is no third state.

## Testing adapters

Three layers:

1. **Unit tests** with hand-rolled mocks at the transport layer — fast, comprehensive on edge cases.
2. **Recorded tests** with VCR-style cassettes — record once against a real MCP server in a controlled environment, replay forever.
3. **Integration tests** that hit the actual MCP server — `@pytest.mark.integration`, run nightly in CI, never on PR.

The first two are mandatory for every adapter. The third is recommended for any adapter that touches a system whose API tends to drift (Dynatrace, AIOps).

## Adding a new MCP integration

A new integration is a substantial task. It includes:

- The MCP server itself, if we own it (in a separate repo). If the vendor provides one, we wrap it; we don't fork it without a reason.
- The adapter in `mcp/<system>/`.
- Schemas, mocks, fixtures.
- Unit and recorded tests.
- A new section in `docs/mcp-integrations.md` describing what the integration does and what it doesn't.
- A failure-mode entry in `docs/failure-modes.md` for the new attack surface.
- A telemetry dashboard tile.

Don't start a new MCP integration on a casual instruction. It deserves a task file.

## When to call which MCP from which agent

This is not enforced by code but it is convention:

- **Strategist** reads from observability MCPs (Splunk, Dynatrace, AIOps, SLO Tracker) and from the code-context store. It does not directly call write-MCPs (Remediation, Jira). It produces a runbook with steps; the orchestrator routes steps to Sub-Agents.
- **Sub-Agent (Remediator)** calls the Remediation MCP. It is the only path to production-mutating actions.
- **Sub-Agent (Communicator)** writes to Jira and Confluence. It does not call Remediation.
- **Sub-Agent (Verifier)** reads observability MCPs after an action to confirm recovery. It does not call Remediation.

The separation is what allows us to grant production-write capability only where we strictly need it.
