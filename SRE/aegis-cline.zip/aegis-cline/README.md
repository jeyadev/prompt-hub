# AEGIS — Roo Code / Cline Workspace

This is the development workspace for AEGIS, an agentic incident automation platform for SRE operations. It is structured to be driven primarily by Roo Code (or Cline) with Opus 4.6, with humans (you) reviewing PRs and stewarding direction.

## What this workspace contains

```
aegis/
├── .roo/
│   ├── rules/                  # Operating contract for the agent — read first
│   │   ├── 01-project.md       # What AEGIS is
│   │   ├── 02-architecture-invariants.md
│   │   ├── 03-coding-standards.md
│   │   ├── 04-agent-design.md
│   │   ├── 05-security.md
│   │   ├── 06-task-discipline.md
│   │   ├── 07-mcp-patterns.md
│   │   └── 08-feature-protocol.md   # How ideas become tasks
│   ├── mcp.json.example        # Production MCP server config (reference)
│   └── memory.md               # Living memory; agent updates as it learns
├── .roomodes                   # Custom modes: Architect, Strategist, MCP-Integrator, Eval-Engineer, Hardening
├── .clinerules                 # Compatibility shim if you ever swap to vanilla Cline
├── .clineignore                # What the agent must never touch
├── .gitignore
├── PRD.md                      # Product requirements
├── ARCHITECTURE.md             # System architecture as it stands
├── ROADMAP.md                  # Four-phase production roadmap
├── tasks/                      # Decomposed task files — one unit of work each
│   ├── README.md
│   ├── 001-postgres-migration.md
│   ├── 002-vault-secrets-integration.md
│   ├── 003-audit-log-schema.md
│   ├── 004-eval-harness-v1.md
│   ├── 005-otel-instrumentation.md
│   ├── 010-code-context-repo-onboarding.md
│   ├── 011-code-context-tree-sitter-indexing.md
│   ├── 012-code-context-pgvector-store.md
│   └── 013-code-context-incident-resolver.md
├── ideas/                      # Idea pipeline — capture → stress-test → commit
│   ├── INBOX.md                # Raw capture, no quality bar
│   ├── deferred.md             # Survived stress-test, belongs to a later phase
│   └── rejected.md             # Didn't survive — kept so future-self knows why
├── docs/
│   ├── feature-protocol.md     # How ideas become tasks (human guide)
│   ├── failure-modes.md        # Living document — top failure modes + mitigations
│   ├── eval-design.md          # How we measure runbook quality
│   ├── onboarding-runbook.md   # For human SREs to onboard their app
│   └── adr/                    # Architecture Decision Records
│       └── 0000-template.md
├── app/                        # FastAPI service entry points
├── orchestrator/               # Agent orchestration core
├── agents/                     # Individual agent implementations
├── mcp/                        # MCP client code & adapters
├── evals/                      # Eval harness
├── tests/                      # Tests
└── scripts/                    # Ops scripts
```

## Quick start

1. **Open this folder in VS Code.** With the Roo Code extension installed, the `.roo/rules/` directory is read automatically. Confirm in the Roo Code sidebar that the rules are loaded.
2. **Verify your model is Opus 4.6.** Set it in Roo Code settings if not.
3. **Set the active mode.** Default is Code. Switch to `architect-aegis` for design conversations, `hardening` for Phase 1 work, etc. See `.roomodes`.
4. **Pick a task.** Open `tasks/001-postgres-migration.md` (or any task), then start a Roo Code session with: *"Execute task 001. Read the rules first. Confirm scope before writing code."*
5. **PR per task.** Each task lands on its own branch. The agent opens a PR; you review.

## Working principles (encoded in the rules — re-stated here for orientation)

- **Read rules before writing.** The agent should never start a non-trivial task without confirming it has read `.roo/rules/`.
- **Scope confirmation.** For any task estimated > 30 minutes of agent work, the agent must restate the scope and any assumptions before it starts.
- **Single-responsibility commits.** No mixing schema changes with feature changes.
- **Tests with implementation.** Not after.
- **Failure modes documented.** Before merging anything that adds reach to AEGIS.
- **The roadmap is the spine.** If a task is off-roadmap, it needs justification, not just a good idea.

## When to clear the conversation

Aggressively. Once a task is merged, `/newtask` or clear context. Long sessions burn thinking tokens on stale state. The rules live in `.roo/rules/`; the agent re-reads them on every new task.

## What goes in `.roo/memory.md`

The agent is allowed (and encouraged) to append to `memory.md` when it learns something durable about this codebase — a quirk of the Splunk MCP, a non-obvious schema constraint, a decision and its rationale. Treat it as the project's running journal.

---

*Maintainer: Jey Ganesh · forever_an_arjuna*
