# Ideas — INBOX

Raw capture. No quality bar. Append, don't curate.

## Format

```
## YYYY-MM-DD — short title
Source: where the idea came from (incident, conversation, doc, intuition)
The idea: one paragraph. What it does. Why it occurred to you.
Status: raw | stress-tested | → <artifact>
```

When an idea is stress-tested, append the outcome inline ("→ rejected: rationale" or "→ task 014") rather than moving the entry. INBOX is the audit trail of what you thought about.

---

## 2026-05-13 — Workspace bootstrapped
Source: setup
The idea: This file exists. Start logging ideas here as they occur. The weekly review will catch what doesn't get processed sooner.
Status: → meta

---

(Append new entries below this line.)
