# Ideas — Rejected

Ideas that didn't survive stress-testing. We keep them because the same idea will come back, and your future self deserves to know why you said no the first time.

If a rejected idea comes back with new context that changes the answer, log the *new* entry separately — don't edit the old one. The history of why we changed our mind is itself valuable.

## Format

```
## YYYY-MM-DD — short title
Source: where the idea came from
The idea: one paragraph.
Rejected because: which of the six stress-test questions killed it. Be specific. "Question 1: requires bypassing audit log on actions — invariant 3."
Would change my mind if: the specific evidence or context that would warrant revisiting.
```

---

(Append new entries below this line.)
