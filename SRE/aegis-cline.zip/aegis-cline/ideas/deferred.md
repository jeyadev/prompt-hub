# Ideas — Deferred

Ideas that survived stress-testing but belong to a later phase or depend on a decision not yet made. Each one has an **activation condition** — the specific signal that says "now's the time to revisit." Not a date; a state.

Reviewed in the weekly cadence. After 90 days without activation, the idea either gets revived or killed.

## Format

```
## YYYY-MM-DD — short title
Source: where the idea came from
Target phase: 2 | 3 | 4 | unscoped
Activation condition: the specific signal — e.g. "when 5 apps are in Approval mode" or "after ADR 0004 lands"
The idea: one paragraph.
Stress-test result: which of the six questions punted this to deferred, with rationale.
```

---

(Append new entries below this line.)
