# AEGIS — Roadmap

The four-phase plan to take AEGIS from working demo to enterprise infrastructure. Each phase earns the right to start the next.

The full narrative is in the post-demo strategy brief (`docs/strategy-brief.html`). This file is the operational version — what we are doing, when, and how we know it's done.

---

## Phase 1 — Hardening (Months 1–3)

**Theme:** Make AEGIS something CISO and Audit can sign off on before it touches another production system.

### Workstreams

| # | Workstream | Owner mode |
|---|---|---|
| 1.1 | Identity (SSO via IDAnywhere) and RBAC | `hardening` |
| 1.2 | Secrets via Vault; rotate all credentials | `hardening` |
| 1.3 | Postgres migration + pgvector setup | `hardening` |
| 1.4 | Audit log to separate append-only store | `hardening` |
| 1.5 | HA deployment (active-active across two AZs) | `hardening` |
| 1.6 | OpenTelemetry instrumentation across AEGIS | `hardening` |
| 1.7 | Prompt-injection defence + injection eval suite | `eval-engineer` |
| 1.8 | Eval harness v1 (golden set, judge prompt, weekly regression) | `eval-engineer` |
| 1.9 | Per-tenant token budgets + cost telemetry | `hardening` |
| 1.10 | Kill-switch + blue/green deployment | `hardening` |

### Exit criteria

- TPRM-grade self-assessment passes.
- CISO sign-off on identity model.
- Eval harness running weekly with documented baseline.
- Zero developer-laptop dependencies in the control plane.
- All MCP adapters carry circuit-breaker, retry, idempotency, audit.

---

## Phase 2 — Code Context (Months 3–5)

**Theme:** Turn "restart the pod" into "revert PR #234, here's why."

### Workstreams

| # | Workstream | Owner mode |
|---|---|---|
| 2.1 | Repository onboarding (GitHub Enterprise, Bitbucket, GitLab) | `code-context` |
| 2.2 | Tree-sitter indexing (Java, Python, Kotlin, Go, JS/TS) | `code-context` |
| 2.3 | Symbol graph + service-topology extraction | `code-context` |
| 2.4 | pgvector store + chunking on function boundary | `code-context` |
| 2.5 | Hybrid retrieval (BM25 + dense + symbol-exact) + reranker | `code-context` |
| 2.6 | Incident-to-code resolver (stack-frame → repo/file/function) | `code-context` |
| 2.7 | Code-context MCP server | `code-context` |
| 2.8 | Code-aware Strategist prompt + schema | `strategist-dev` |
| 2.9 | Resolution capture into `incident_history` | `code-context` |
| 2.10 | Per-repo retrieval-quality evals | `eval-engineer` |

### Exit criteria

- Three pilot apps fully indexed.
- Code-aware runbooks beat symptom-only on cause-precision by ≥40% on the golden set.
- Cause-attribution hallucination rate under 5% (app-owner judged).
- Re-index latency under 5 min per push.

---

## Phase 3 — Self-Serve Onboarding (Months 5–7)

**Theme:** Stop being the bottleneck. App teams onboard themselves through a flow that earns trust before it grants autonomy.

### Workstreams

| # | Workstream | Owner mode |
|---|---|---|
| 3.1 | `aegis.yaml` declarative app profile schema | `architect-aegis` then `hardening` |
| 3.2 | Onboarding wizard (UI + API) | feature work |
| 3.3 | Pre-flight check service (connectivity, permissions per MCP) | `mcp-integrator` |
| 3.4 | Confluence-page → first-pass runbook generator | `strategist-dev` |
| 3.5 | Trust-ladder gates (Shadow → Suggest → Approve → Auto) with per-mode promotion logic | `hardening` |
| 3.6 | Per-app golden eval set construction | `eval-engineer` |
| 3.7 | Per-app scorecard (coverage, accuracy, time saved, FPR) | feature work |
| 3.8 | App-team self-service mode demotion (panic button) | `hardening` |

### Exit criteria

- Five apps onboarded without platform-team integration code.
- Median wizard-start → first-runbook under 60 minutes.
- At least two apps graduated past Shadow on their own evidence.

---

## Phase 4 — Scale, Governance, Operating Model (Months 7–12)

**Theme:** Move from "ten apps where it works" to "infrastructure the bank treats as such."

### Workstreams

| # | Workstream | Owner mode |
|---|---|---|
| 4.1 | Cross-app pattern library (anonymised) | `eval-engineer` |
| 4.2 | Shared-dependency graph (when X misbehaves, who's affected) | `architect-aegis` |
| 4.3 | Internal marketplace for agents and runbook templates | feature work |
| 4.4 | Quarterly model review process + reports | `eval-engineer` |
| 4.5 | CAB integration for mode promotions | `hardening` |
| 4.6 | Independent eval audit (twice yearly) | `eval-engineer` |
| 4.7 | Model cards per agent | `architect-aegis` |
| 4.8 | ROI dashboard (toil hours, MTTR delta, cost per incident) | feature work |
| 4.9 | Customer success function within platform SRE team | operating |
| 4.10 | Embedded SRE pattern for new onboardings (first 30 days) | operating |

### Exit criteria

- 25+ apps onboarded across three lines of business.
- Provable 40%+ MTTR reduction on Tier-1 services.
- AEGIS survives an independent audit.
- Bus-factor > 1 — a successor can run a release cycle.
