# Task 002 — Vault secrets integration

**Phase:** 1 — Hardening
**Mode:** `hardening`
**Estimated effort:** medium (1–2 days)
**Depends on:** none (can run in parallel with 001)
**Blocks:** anything that touches a credential going forward

## Objective

Replace `.env`-based secret loading with HashiCorp Vault. All secrets resolve through Vault references at runtime. The codebase contains no raw credentials, and CI fails on commits that contain anything resembling one.

## Scope (in)

- Vault client wrapper in `app/secrets/vault.py`. Methods: `get(path) -> str`, `get_dict(path) -> dict`. Async, with a small in-process cache (TTL 5 min, configurable).
- Reference syntax: `vault:secret/aegis/<system>/<key>` parsed by a resolver in `app/secrets/resolver.py`.
- Config loading (`app/config.py`) resolves Vault references at startup. References that fail to resolve crash startup with a clear message — fail fast, not silent.
- MCP base client (`mcp/base/client.py`) takes its credentials via the resolver, not raw env vars.
- Local development: `.envrc` template that pulls secrets from Vault via `vault read` on shell activation. `.envrc` itself committed; the secrets it pulls are not.
- CI: add `gitleaks` to pre-commit and to CI. Configure the allow-list for obvious fixtures.
- Documentation: `docs/runbooks/secrets.md` explains how to add a new secret, rotate one, and recover from a leak.

## Scope (out)

- Vault server provisioning — assume Vault is already available at the JPMC-provided endpoint. Local dev uses Vault in dev mode via Docker.
- Auth method beyond AppRole — token, Kubernetes auth, etc. are future tasks.
- Secret rotation automation — this task lays the foundation; per-system rotation is a separate task per system.
- Migrating prod secrets from current `.env` files in deployed environments — coordinate with platform ops, not in this PR.

## Acceptance criteria

- [ ] `vault:secret/aegis/test/value` reference resolves correctly in a unit test (against a dev-mode Vault container).
- [ ] An MCP adapter starts up correctly using only Vault-resolved credentials.
- [ ] Failing resolution crashes startup with a clear, actionable error message.
- [ ] `gitleaks` runs on every PR and on every commit via pre-commit.
- [ ] `gitleaks` catches a deliberately committed fake-secret in a test PR.
- [ ] No raw secrets remain in the codebase or in fixtures. (`grep -E "(sk-|ghp_|password\s*=)"` returns only known fakes.)
- [ ] Documentation explains the add/rotate/leak-recovery flow.
- [ ] `mypy --strict` passes on `app/secrets/`.

## Implementation notes

- Use `hvac` as the Vault client library.
- The resolver should be **lazy**: don't resolve a reference at definition time, only at first use. This makes config tests easier.
- The cache key includes the reference string and the auth identity, not just the path — different identities may see different values.
- The reference syntax extends to support: `vault:secret/path#field` to extract a specific field from a KV-v2 secret.
- Invariant 9 ("No secrets in code, configs, or logs") is what this task enforces. Restate compliance in the PR.

## Testing requirements

- Unit test: parse and validate the reference syntax.
- Unit test: resolver against a mocked Vault client, covering happy path and failure modes.
- Integration test (`@pytest.mark.integration`): real resolution against a Vault dev container.
- Failure-mode test: resolver fails clearly when a path doesn't exist, when auth fails, when Vault is unreachable.

## Exit artifacts

- `app/secrets/vault.py`, `app/secrets/resolver.py`.
- Updated `app/config.py` using the resolver.
- Updated `mcp/base/client.py` taking credentials via resolver.
- `.envrc` template (committed) and `.envrc` (gitignored, generated).
- `docs/runbooks/secrets.md`.
- `.gitleaks.toml` config.
- Pre-commit hook for gitleaks.
- CI workflow step for gitleaks.
- PR description references invariant 9.
