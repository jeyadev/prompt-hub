# Task 005 — OpenTelemetry instrumentation

**Phase:** 1 — Hardening
**Mode:** `hardening`
**Estimated effort:** medium (1–2 days)
**Depends on:** none
**Blocks:** anything that needs observability of AEGIS itself

## Objective

Instrument AEGIS with OpenTelemetry so the platform observes itself. Every incident lifecycle, every agent invocation, every MCP call emits traces. Metrics expose latency, throughput, error rates, and token cost per agent. This is the foundation for SLOs on AEGIS, for production debugging, and for the Phase 4 ROI dashboard.

## Scope (in)

- Add `opentelemetry-api`, `opentelemetry-sdk`, `opentelemetry-instrumentation-fastapi`, `opentelemetry-instrumentation-sqlalchemy`, `opentelemetry-instrumentation-asyncpg`, `opentelemetry-instrumentation-httpx` as dependencies.
- Init in `app/observability/otel.py`. Tracer provider, meter provider, OTLP exporter to the collector endpoint configured via `OTEL_EXPORTER_OTLP_ENDPOINT`.
- FastAPI auto-instrumentation for HTTP spans.
- SQLAlchemy + asyncpg instrumentation for DB spans.
- httpx instrumentation for outbound HTTP (used by Anthropic SDK).
- Custom spans:
  - `orchestrator.incident.<phase>` for each lifecycle phase.
  - `agent.<name>.invoke` with attributes: `model`, `prompt_tokens`, `completion_tokens`, `cost_usd`, `confidence_score` (if applicable), `outcome` (success | retry | failure).
  - `mcp.<server>.<tool>` with attributes: `duration_ms`, `retries`, `circuit_state`, `outcome`.
  - `action.<type>` for sub-agent action execution: `idempotency_key`, `mode`, `approval_required`, `confidence_score`.
- Custom metrics:
  - Counter: `aegis.incidents.received_total`, `aegis.incidents.resolved_total`, by service.
  - Histogram: `aegis.incident.mttr_seconds`, by service and resolution mode.
  - Counter: `aegis.agent.invocations_total`, by agent and outcome.
  - Histogram: `aegis.agent.latency_seconds`, by agent.
  - Counter: `aegis.agent.tokens_total`, by agent and direction (input/output).
  - Counter: `aegis.agent.cost_usd_total`, by agent.
- Resource attributes: `service.name=aegis-orchestrator`, `service.version`, `deployment.environment`.
- Local dev: docker-compose includes an OTel collector and Jaeger UI for traces.
- Documentation: `docs/observability.md` explaining where to find traces and metrics.

## Scope (out)

- Custom dashboards in Grafana / Dynatrace — separate task. This task ships the data; dashboards consume it.
- Log correlation (trace_id in log lines) — adjacent task, can run in parallel; not a hard dependency here.
- Alerting rules on AEGIS itself — Phase 4.

## Acceptance criteria

- [ ] A test incident produces a complete trace from webhook receipt through resolution, visible in Jaeger locally.
- [ ] All custom spans listed above appear with the listed attributes.
- [ ] All custom metrics listed above are emitted and visible in the local collector's output.
- [ ] No span attributes contain PII or secret material — verified by a unit test that checks attribute keys against an allow-list.
- [ ] The OTel exporter failing does not break AEGIS — traces are dropped silently, application continues.
- [ ] Cost overhead measured: < 3% latency overhead on a typical incident.

## Implementation notes

- Use the OTel context API to propagate trace context through async boundaries. `opentelemetry.context.attach()` / `detach()` patterns where needed.
- Don't manually create spans for every function — use the auto-instrumentation where it fits. Custom spans are for the AEGIS-specific semantic events.
- Resource attributes are set once at startup, not per-span.
- Cost-per-agent: compute from `prompt_tokens` and `completion_tokens` using current Anthropic pricing in a constants table. When pricing changes, update the table.
- Don't blow up if the OTel endpoint is unreachable — the exporter handles this internally; verify by testing with a bogus endpoint.

## Testing requirements

- Unit test: span attribute allow-list catches PII keys ("email", "ssn", "card_number").
- Integration test: a stubbed incident run produces the expected span structure (assert by traversing the in-memory exporter's spans).
- Performance test: latency overhead < 3% on a representative workflow.

## Exit artifacts

- `app/observability/otel.py`.
- `app/observability/cost.py` for token-cost computation.
- Instrumentation hooks in `orchestrator/`, `agents/`, `mcp/base/`.
- Updated `docker-compose.yml` with OTel collector and Jaeger.
- `docs/observability.md`.
- PR description references invariant 7 (observability of AEGIS itself).
