# Task 011 — Code context: tree-sitter indexing

**Phase:** 2 — Code Context
**Mode:** `code-context`
**Estimated effort:** large (3–4 days)
**Depends on:** 010 (repos available on disk)
**Blocks:** 012 (vector store consumes the indexed chunks)

## Objective

Parse onboarded repositories with tree-sitter to produce a symbol graph (classes, functions, calls, imports) and per-function chunks suitable for embedding. The symbol graph powers exact-symbol retrieval; the chunks power semantic retrieval; the service-topology extraction maps services to repos and deployment units.

## Scope (in)

- Tree-sitter integration via `py-tree-sitter` and per-language grammars: Java, Python, Kotlin, Go, JavaScript, TypeScript.
- Indexer in `app/code_context/index/`. Entry point: `index_repo(repo_id, commit_sha)`. Idempotent on `(repo_id, commit_sha, file_path)`.
- Symbol extraction per file:
  - Classes: name, qualified name, file path, byte range, docstring (if present).
  - Functions/methods: name, qualified name, signature, file path, byte range, docstring, parent class (if method).
  - Imports: module name, alias, kind (relative / absolute).
- Call graph: for each function, the set of qualified names it calls (best-effort, language-dependent). Stored as edges.
- Chunking: one chunk per function or method, with the surrounding 3 lines of context. Class-level chunks for classes whose methods aren't individually meaningful (DTOs, dataclasses).
- Service topology extraction:
  - Spring/Spring Boot: `@SpringBootApplication`, `@Service`, `@RestController`, `@FeignClient` → service name, exposed paths, downstream calls.
  - Quarkus: equivalent annotations.
  - Kubernetes manifests in the repo: parse `Deployment`/`Service`/`Ingress` YAML.
  - Terraform: parse `.tf` files for module dependencies.
- Persistence: tables `code_symbols`, `code_chunks` (without embeddings yet — task 012 adds those), `code_call_edges`, `service_topology_edges`.
- Re-index on webhook: a webhook for a push triggers re-indexing of changed files only (diff against the prior `commit_sha`).
- CLI command: `python -m aegis.code_context.index --repo <id> --commit <sha>` for manual runs.

## Scope (out)

- Embeddings — task 012.
- Retrieval — task 012/013.
- Languages beyond the listed six — add via separate tasks per language.
- Cross-repo call graph — defer; intra-repo is sufficient for v1.
- Semantic understanding beyond syntax (e.g. type-resolution across packages) — defer; tree-sitter syntax is enough for v1.

## Acceptance criteria

- [ ] All six languages parse without error on a representative sample repo.
- [ ] Symbol counts match a hand-verified count on a small test repo (Java: known 24 classes, 137 methods, etc.).
- [ ] Chunks respect function boundaries — no chunk straddles a function-end line.
- [ ] Service-topology extraction on a real Spring Boot test repo identifies the correct exposed endpoints.
- [ ] Re-index on a one-file change touches only that file's symbols and chunks.
- [ ] Full re-index of a 50K-LOC repo completes in under 5 minutes.
- [ ] `mypy --strict` passes on `app/code_context/index/`.

## Implementation notes

- Tree-sitter parsers are loaded once at process startup, not per-file. Cache the parsers.
- Chunk size: target 800–1500 tokens per chunk. Use a tokenizer estimate, not a character count — keeps chunks within embedding-model limits later.
- Qualified names should be unambiguous within a repo. Use `package.Class.method(signature)` form.
- The call graph is best-effort by design. Don't try to resolve every call — capture what's syntactically visible, mark the rest as `unresolved`.
- Service topology extraction is the most fragile part — start with the most common annotation patterns and grow the matcher over time. Don't try to handle every edge case in v1.
- Symbol storage in Postgres is fine for v1. We'll evaluate moving to a graph database in Phase 4 if the call-graph traversals get expensive.

## Testing requirements

- Unit tests per language: parse a representative fixture file, assert symbol counts and a few specific names.
- Unit test: chunk boundaries align with function boundaries on a tricky fixture.
- Unit test: re-index produces correct diff (added/changed/removed symbols).
- Integration test: end-to-end index of a small fixture repo, verify symbol and chunk row counts.

## Exit artifacts

- `app/code_context/index/` module with `parser.py`, `symbols.py`, `chunks.py`, `topology.py`, `indexer.py`.
- Alembic migration for `code_symbols`, `code_chunks` (sans-embedding), `code_call_edges`, `service_topology_edges`.
- Tree-sitter grammar binaries vendored under `vendor/tree-sitter/` (or fetched at install).
- CLI script.
- `docs/code-context/indexing.md` describing the schema and the parser quirks.
- Failure-mode entries for parser failures, OOM on huge files, malformed source files.
- PR description.
