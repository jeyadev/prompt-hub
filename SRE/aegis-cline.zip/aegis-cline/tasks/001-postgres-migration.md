# Task 001 — Postgres migration with pgvector

**Phase:** 1 — Hardening
**Mode:** `hardening`
**Estimated effort:** large (2–3 days)
**Depends on:** none
**Blocks:** 003 (audit log schema), 010+ (code context — needs pgvector)

## Objective

Replace SQLite with PostgreSQL as the operational data store, install the `pgvector` extension, and migrate all existing schema and data. This unblocks code-context embeddings (Phase 2), audit-log separation (task 003), and the general HA story.

## Scope (in)

- Add PostgreSQL as a runtime dependency (Docker Compose for local dev, Helm values for staging/prod).
- Add `pgvector` extension to the database init.
- Create Alembic migration `0001_initial` that establishes the full current schema in Postgres.
- Migrate SQLAlchemy models to async Postgres dialect (`asyncpg`).
- Update DB session management to `AsyncSession` from `async_sessionmaker`.
- Data migration script: read from SQLite, write to Postgres, verify counts and a sample of row equality.
- Update all tests to use a Postgres test container (`testcontainers-python`).
- Document the runbook for the cutover in `docs/runbooks/postgres-cutover.md`.

## Scope (out)

- The audit log is **not** in scope. The audit log moves to its own separate store in task 003. Until then, audit rows stay in the operational Postgres but tagged for migration.
- Read-replicas, HA, connection pooling tuning — these are part of task 5.x. This task gets one Postgres up and working correctly.
- Sharding strategy — explicitly deferred. We are nowhere near needing it.
- Migrating SQLite test fixtures to a different format — keep them as-is; the test infrastructure adapts.

## Acceptance criteria

- [ ] `docker compose up` brings up Postgres 16 with `pgvector` installed and AEGIS connects.
- [ ] All existing tests pass against Postgres.
- [ ] Alembic migration creates the full schema from an empty database.
- [ ] Data migration script idempotent — running twice produces no duplicates and no errors.
- [ ] Performance: a representative read (load a recent incident with its runbook and steps) is no more than 2× slower than the SQLite equivalent. Document the numbers.
- [ ] `mypy --strict` passes on `app/db/` and `orchestrator/`.
- [ ] PR description includes the cutover runbook reference.

## Implementation notes

- Use **SQLAlchemy 2.0 style** throughout. `select(...)`, not the legacy query API.
- Use **asyncpg** as the driver. Async sessions everywhere.
- `pgvector` extension is created in the migration, not in app startup. Init-once, not per-process.
- Test container should be reused across the test suite (session-scoped fixture) — startup cost is non-trivial.
- For the data migration script, batch in chunks of ~1000 rows. Wrap each chunk in its own transaction. Log progress to stdout.
- Invariant 3 (immutable audit log) — the operational Postgres holds audit rows temporarily but the storage permissions in this Postgres are read-write. Task 003 separates the audit store and tightens permissions. Document this temporary state in the PR.

## Testing requirements

- Unit tests on all existing models that previously passed against SQLite must now pass against Postgres.
- One new test: round-trip a `Runbook` with nested `Step` records, verify all fields. Postgres JSON behavior can differ from SQLite, so this is worth a dedicated test.
- One new test: insert a 1536-dimensional vector, perform a similarity query against it. Verifies pgvector is wired correctly.
- Integration test (`@pytest.mark.integration`): full data migration on a seeded SQLite, then sample comparison.

## Exit artifacts

- New Alembic migration `app/db/migrations/0001_initial.py`.
- Updated models in `app/db/models.py` (async, Postgres-typed).
- Updated session management in `app/db/session.py`.
- Data migration in `scripts/migrate_sqlite_to_postgres.py`.
- Updated `docker-compose.yml` for local dev.
- Cutover runbook: `docs/runbooks/postgres-cutover.md`.
- PR description references this task and the cutover runbook.
