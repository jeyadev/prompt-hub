# Task 003 — Immutable audit log to a separate store

**Phase:** 1 — Hardening
**Mode:** `hardening`
**Estimated effort:** large (2–3 days)
**Depends on:** 001 (Postgres migration), 002 (Vault for credentials)
**Blocks:** any production rollout

## Objective

Move the audit log into a separate, append-only store with its own credentials, its own backup policy, and its own access controls. The audit log is the source of truth for "what happened and why." It must be replayable, tamper-evident, and retainable for 7 years.

## Scope (in)

- New audit-log store: a second Postgres database, with **storage-level write-only-append** enforced via role permissions (no `DELETE`, no `UPDATE` granted to the application role).
- Audit log schema (see `docs/audit-schema.md` — create it in this task):
  - `event_id` (uuid), `occurred_at` (timestamptz), `actor_id` (str), `actor_kind` (enum), `event_type` (enum), `subject_kind` (enum), `subject_id` (str), `payload` (jsonb), `payload_hash` (sha256 of payload), `prior_hash` (sha256 of prior row's payload_hash, forming a chain), `correlation_id` (uuid for grouping).
- Append-only client in `app/audit/client.py`. Single method: `write(event)`. Returns the assigned `event_id`. Cannot return success without confirmation of durable write.
- Hash chain verification: a script that walks the chain and confirms integrity.
- Migration of existing audit rows from the operational Postgres into the new store.
- Operational Postgres retains a *pointer* to the audit store (a `event_id` reference) but no audit content.
- Document retention: 7 years. Document offline backup cadence.
- Reader role separate from writer role. Most application code only writes; the Ops Console reads through a dedicated query API.

## Scope (out)

- Tamper-evident infrastructure beyond hash chaining (HSM, blockchain anchoring) — defer; current scope is sufficient for SOX.
- Streaming export to JPMC's e-discovery platform — separate task; this one stops at the store boundary.
- UI for browsing the audit log — Ops Console gets a read-only audit panel in a separate task.

## Acceptance criteria

- [ ] Audit DB is a separate Postgres instance (separate container in dev, separate cluster in prod).
- [ ] Application role on audit DB has only `INSERT` on the audit table. No `UPDATE`, no `DELETE`. Verified with a test that attempts both and expects failures.
- [ ] Every existing audit emission point in the codebase routes through `app.audit.client.write`.
- [ ] Hash chain is correct after a sequence of writes — verified by the chain-walker script.
- [ ] Backfill of existing audit rows from operational Postgres completes without loss.
- [ ] Operational Postgres no longer contains audit content (only references).
- [ ] `docs/audit-schema.md` and `docs/runbooks/audit-recovery.md` exist and are complete.
- [ ] Read API is RBAC-gated to the auditor role.

## Implementation notes

- Use Postgres roles, not just application-level discipline, to enforce append-only. `GRANT INSERT ON audit_log TO aegis_audit_writer;` — no other DML privileges.
- Hash chain: the simplest correct approach is `payload_hash = sha256(payload)` and `prior_hash = (SELECT payload_hash FROM audit_log ORDER BY event_id DESC LIMIT 1 FOR UPDATE)`. This requires serialization; that's acceptable — audit writes are sequenced, not parallel-critical-path.
- For high-throughput periods, batched writes are acceptable as long as the batch is itself a single transaction and the hashes are computed serially within it.
- `event_type` enum: `agent_decision`, `tool_call`, `action_executed`, `mode_change`, `approval_grant`, `approval_deny`, `incident_open`, `incident_close`, `runbook_generated`, `eval_run`, `system_startup`, `system_shutdown`. Extensible; add via Alembic migration.
- Failure mode to document: if the audit write fails, the **calling operation must also fail**. We do not perform actions whose audit could not be persisted. This is non-negotiable.

## Testing requirements

- Unit test: schema validation rejects malformed events.
- Unit test: hash chain correct over a 100-event sequence.
- Unit test: chain detects tampering (manual hash modification fails verification).
- Integration test: attempting `UPDATE` or `DELETE` as the writer role fails with a permissions error.
- Integration test: a simulated action where the audit write fails causes the action to fail.

## Exit artifacts

- New `app/audit/` module with `models.py`, `client.py`, `verifier.py`.
- New Alembic migration on the audit DB.
- Script `scripts/verify_audit_chain.py`.
- Script `scripts/migrate_audit_from_operational.py`.
- `docs/audit-schema.md`.
- `docs/runbooks/audit-recovery.md`.
- Updated `docker-compose.yml` with the audit Postgres instance.
- PR description references invariants 3, 10.
