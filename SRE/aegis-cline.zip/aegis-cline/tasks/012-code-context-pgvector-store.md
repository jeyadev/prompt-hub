# Task 012 — Code context: pgvector store and hybrid retrieval

**Phase:** 2 — Code Context
**Mode:** `code-context`
**Estimated effort:** large (3–4 days)
**Depends on:** 011 (chunks available)
**Blocks:** 013 (incident-to-code resolver consumes retrieval results)

## Objective

Generate embeddings for code chunks, store them in `pgvector`, and implement hybrid retrieval (BM25 + dense + symbol-exact) with reranking. This is the retrieval substrate the incident resolver and code-aware Strategist will query.

## Scope (in)

- Embedding generation via Voyage AI `voyage-code-3` (or equivalent code-tuned model — abstract behind an interface so we can swap).
- Embedding storage: extend `code_chunks` table with an `embedding vector(1024)` column. Index with `ivfflat` (tune lists parameter against corpus size).
- BM25 index: use Postgres full-text search with a custom analyzer for code (handles `snake_case`, `camelCase`, dotted-symbol splitting).
- Symbol-exact retrieval: direct lookup against `code_symbols` for `package.Class.method`-style queries.
- Hybrid retriever in `app/code_context/retrieval/`. Interface: `retrieve(query, repo_id, k=10) -> list[RetrievalResult]`. Internally fans out to all three retrievers, then reranks.
- Reranker: simple v1 is a weighted score (configurable weights). v1.1 (separate task) introduces a cross-encoder reranker.
- Incremental embedding: on re-index, only embed changed chunks. Embedding cost is non-trivial — don't re-embed unchanged code.
- Retrieval-quality evals under `evals/retrieval/`: labeled set of (query, expected_chunks) pairs across pilot repos.

## Scope (out)

- Cross-encoder reranker — separate task once we measure v1 retrieval quality.
- Multi-repo retrieval — a single retrieve call targets a single repo. Cross-repo is the orchestrator's job.
- Embedding-model migration tooling — defer until we actually swap models.

## Acceptance criteria

- [ ] Embeddings are generated and stored for all chunks in a fixture repo.
- [ ] BM25 query for an exact identifier (`OrderProcessor`) returns it within the top-3.
- [ ] Dense query for a semantic phrase ("function that validates orders") returns relevant chunks within top-5.
- [ ] Symbol-exact query is O(1) lookup, sub-10ms.
- [ ] Hybrid retrieve completes in under 200ms for k=10 on a 50K-LOC repo.
- [ ] Incremental re-embedding skips unchanged chunks (verified by token-cost count on a re-run).
- [ ] Retrieval eval baseline score documented in `evals/retrieval/baseline.md`.
- [ ] `mypy --strict` passes on `app/code_context/retrieval/`.

## Implementation notes

- Voyage code-3 embedding dimension is 1024 (verify at integration time). The pgvector column matches.
- BM25 with `pg_trgm` is acceptable for v1; if we need richer behavior, consider `paradedb` or external Elastic in a later phase.
- Reranker weights are config, not constants. Start with `0.5 dense + 0.3 BM25 + 0.2 symbol-exact` and tune against the retrieval eval.
- The retriever caches per-repo loaded index metadata. Cache invalidation on re-index completion.
- Embedding cost: a 50K-LOC repo is ~3K chunks at ~1.2K tokens each. At Voyage pricing this is ~$0.50 per initial index — fine. Incremental updates are cents.

## Testing requirements

- Unit test: hybrid retriever combines results correctly across the three retrievers.
- Unit test: weight changes produce different rankings on a fixture.
- Unit test: incremental embedding skips unchanged chunks.
- Integration test: full retrieval cycle against a fixture repo with a known ground truth.

## Exit artifacts

- `app/code_context/retrieval/` module with `embedder.py`, `bm25.py`, `dense.py`, `symbol.py`, `hybrid.py`, `reranker.py`.
- Alembic migration adding `embedding` column and `ivfflat` index.
- Retrieval eval set under `evals/retrieval/`.
- `docs/code-context/retrieval.md` describing the retrievers and the weights.
- Failure-mode entries for embedding-service outage, dimension mismatch on model swap.
- PR description.
