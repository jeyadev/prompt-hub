# Task 013 — Code context: incident-to-code resolver

**Phase:** 2 — Code Context
**Mode:** `code-context`
**Estimated effort:** large (3–4 days)
**Depends on:** 010, 011, 012
**Blocks:** Strategist becoming code-aware (separate task in `strategist-dev` mode)

## Objective

Build the resolver that, given an incident, produces a bounded **code-context packet** the Strategist will use: the failing function source, the diffs that touched it recently, the top similar past incidents, and the assembled owner ping list. This is the bridge between observability and code.

## Scope (in)

- `app/code_context/resolver/` module.
- Input: an enriched incident object containing the alert, the affected service, observability summaries, and (importantly) any stack traces or error messages with file/line references.
- Stack-frame parser: extract `(file, line, function)` tuples from common stack-trace formats (Java, Python, Go, Node.js).
- Service-to-repo resolution: look up the service's `aegis.yaml` binding to get the repo. If a service is in multiple repos (rare but possible), use the deployment-unit info to disambiguate.
- File/function resolution: given `(file, line)`, find the enclosing function in the index. Return its source.
- Recent-change retrieval: list of commits that touched the resolved files in the last 24h, 7d, 30d windows. Includes PR number, author, message, summary diff stats.
- Similar-incident retrieval: vector-search `incident_history` for incidents with similar fingerprints. Return top-3 with their resolutions.
- Owner ping list: from CODEOWNERS for the affected paths, deduplicate, ordered by recency of contact (most recent committers first).
- **Context packet assembly:** a typed `CodeContextPacket` Pydantic model. Token-bounded to 8K (configurable). When the budget is tight, the assembler drops in priority order: ancient diffs first, then ancient similar incidents, then peripheral functions, never the failing function source.
- Confidence on the packet itself: high if stack frames resolved cleanly to functions in our index, medium if partial match, low if we're guessing.
- Graceful degradation: if the resolver cannot produce a useful packet, return an empty packet with reason. The downstream Strategist treats this as "no code context" and degrades to symptom-only runbook.

## Scope (out)

- The Strategist prompt change to consume the packet — separate task in `strategist-dev` mode (task 020 or similar).
- Cross-repo resolution beyond the v1 "service in multiple repos" case — defer.
- Synthesis of patch suggestions — explicitly out of scope for v1. We assemble context; we do not suggest code edits.
- Authoring "lessons learned" prompt caches — task 014 (resolution capture and learning).

## Acceptance criteria

- [ ] Stack-frame parser handles all four language formats on fixture inputs.
- [ ] On a synthetic incident pointing to a real fixture repo, the resolver produces a complete packet with the right function, the right recent diffs, and the right owners.
- [ ] When stack frames don't resolve, the resolver returns a clearly degraded packet with reason `stack_frames_unresolved`, not a silent low-quality packet.
- [ ] Packet token-bounding works: a too-large initial assembly is trimmed in priority order with the trimming logged.
- [ ] Resolver latency p99 under 800ms.
- [ ] `mypy --strict` passes on `app/code_context/resolver/`.

## Implementation notes

- The packet schema is a contract between this task and the future Strategist update. Treat it as a versioned interface — add fields with defaults, never remove.
- Use the existing retrieval interface for similar-incident vector search. Don't re-implement.
- Recent-change retrieval requires reading commit history — `dulwich`/`pygit2` from the on-disk clone is fast enough.
- For diff summarization, raw diff text is acceptable in v1 if it fits in the budget. A future enhancement compresses diffs semantically.
- The 8K bound is on the *prompt-rendered* size, not the Pydantic object size. Use a tokenizer to measure.

## Testing requirements

- Unit test: stack-frame parsers for each language.
- Unit test: packet token-bounding correctly trims in the documented priority order.
- Unit test: degraded packet correctly identifies the reason for degradation.
- Integration test: end-to-end resolution on a fixture repo + fixture incident.

## Exit artifacts

- `app/code_context/resolver/` module with `stack_parser.py`, `recent_changes.py`, `owners.py`, `similar_incidents.py`, `assembler.py`, `models.py`.
- `CodeContextPacket` schema in `app/code_context/resolver/models.py`.
- `docs/code-context/packet-schema.md` documenting the contract.
- Failure-mode entries for: unresolvable stack frames, missing repo binding, vector-store outage, token-budget exhaustion.
- PR description references invariant 6 (structured outputs) and rule 04 principle 4 (context windows are budgets, not buffers).
