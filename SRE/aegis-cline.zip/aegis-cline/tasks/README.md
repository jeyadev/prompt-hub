# Tasks

This directory contains decomposed task files. Each task is a unit of work small enough for a single Roo Code session to complete cleanly. Each task lands on its own branch and ships its own PR.

## Numbering convention

- `001–099`: Phase 1 — Hardening
- `100–199`: Phase 2 — Code Context (note: existing files use `010-013` as starter examples; renumber to `100+` once Phase 2 begins formally)
- `200–299`: Phase 3 — Onboarding
- `300–399`: Phase 4 — Scale & Governance
- `500–599`: Cross-cutting / infra
- `900–999`: Spikes and research

## File format

Every task file follows this shape:

```markdown
# Task NNN — Short title

**Phase:** 1 | 2 | 3 | 4 | cross-cutting
**Mode:** the .roomodes mode to use (hardening, code-context, etc.)
**Estimated effort:** small (<2h) | medium (2–8h) | large (1–3 days)
**Depends on:** task NNN if any
**Blocks:** task NNN if any

## Objective

One paragraph. What is being built, and why this task exists in this phase.

## Scope (in)

- Bullet list of what this task does.

## Scope (out)

- Bullet list of what this task does NOT do — what would be tempting to include but belongs in another task.

## Acceptance criteria

- [ ] Specific, checkable items.
- [ ] Each one is independently verifiable.

## Implementation notes

Free-form. Architectural pointers, gotchas, references to invariants.

## Testing requirements

What tests are mandatory before merge.

## Exit artifacts

- Code under <path>.
- Migration under <path> if any.
- Eval cases under <path> if any.
- `docs/failure-modes.md` updated if relevant.
- PR with the standard description template.
```

## How to start a task in Roo Code

1. Open the task file.
2. Set the Roo mode to the one named in the task header.
3. Start the session: *"Execute task NNN. Read `.roo/rules/` first if not already in context. Confirm scope before writing code."*
4. The agent restates scope; you confirm or adjust.
5. The agent works. You review.
6. When acceptance criteria are met, the agent opens a PR. You review and merge.
7. Clear context (`/newtask`) before the next task.

## Don't

- Don't bundle two tasks. If you find yourself wanting to, split the task you're on.
- Don't pick up a task whose dependencies aren't merged. Wait, or work on something else.
- Don't write a task that takes more than three days of agent work. Split it.
