# Task 004 — Eval harness v1

**Phase:** 1 — Hardening
**Mode:** `eval-engineer`
**Estimated effort:** large (3–5 days)
**Depends on:** 001 (Postgres for storing eval runs)
**Blocks:** any further prompt-engineering work that we want to defend

## Objective

Build a reproducible eval harness that runs the Strategist (and later other agents) against a curated golden set, scores outputs with both deterministic checks and an LLM judge, and produces a comparable result on every change. This is the contract between agent authors and the rest of the system — prompt changes that regress the golden set do not merge.

## Scope (in)

- Golden set under `evals/golden/strategist/`, one YAML file per case, with fields: `id`, `description`, `source` (real-incident provenance), `inputs` (alert + observability context), `expected` (ranked hypotheses, expected runbook step shape, expected confidence band).
- Eval runner in `evals/runner.py`. CLI: `python -m evals.runner --agent strategist --set golden --out runs/<timestamp>/`.
- Two scoring layers:
  - **Deterministic** checks: schema validity, presence of required hypothesis types, confidence bounds, no banned content.
  - **Judge LLM** (Sonnet-class, separate from agent under test): scores hypothesis quality, runbook plausibility, and "would a senior SRE accept this." Returns a structured `JudgeVerdict`.
- Result aggregation: per-case score, per-set score, regression detection against the previous run.
- Persistence: results stored in operational Postgres (`eval_runs` and `eval_case_results` tables). Old runs retained for trend.
- CI integration: weekly cron run on `main`. PR-time run on changes to `agents/`, `evals/`, or any prompt file. PR fails if the golden score regresses by more than a configurable threshold (default 2%).
- Reporting: a CLI command produces a Markdown report comparing two runs.
- Initial golden set: 30 hand-curated cases derived from real (anonymised) JPMC incidents, distributed across hypothesis types (deploy-induced, dependency degradation, capacity, configuration, infra).

## Scope (out)

- Online eval (live shadowing of production decisions) — Phase 3.
- Per-app eval sets — Phase 3.
- The injection-detection eval suite — separate task (005, or splits from this).
- A UI for browsing eval results — CLI is sufficient for v1.

## Acceptance criteria

- [ ] Golden set has ≥30 cases, each with documented provenance.
- [ ] Running the eval against the current Strategist produces a baseline score; the number is recorded in `evals/baseline.md`.
- [ ] Running the eval against an intentionally-degraded Strategist (a control: pass the alert through a no-op prompt) produces a measurably lower score.
- [ ] Judge LLM verdicts are reproducible to within 5% on three runs of the same input (acceptable noise floor — document it).
- [ ] CI runs the eval on prompt changes and fails the PR on regression above threshold.
- [ ] Markdown report generation works.
- [ ] `mypy --strict` passes on `evals/`.

## Implementation notes

- Use `anthropic.AsyncAnthropic` directly for the judge, with the same model-fallback chain as production.
- The judge prompt is itself versioned — store its hash with each run so we know which judge said what.
- Cases are YAML, not JSON, because humans write them. Validate against a Pydantic schema on load.
- Provenance: every case has a `source` field with the original incident ID (or "synthetic" if hand-crafted). For real incidents, the labelling was done by the platform SRE team; record who and when.
- Run output goes in `evals/runs/<timestamp>/` (gitignored). The aggregated row goes to Postgres so we can query trends.
- Cost: a full golden run is ~50 LLM calls (30 cases × ~1.5 judge calls each). At Sonnet pricing this is under $5 per run. Acceptable.

## Testing requirements

- Unit test: golden case loader rejects malformed YAML with a clear error.
- Unit test: judge verdict parser handles all defined verdict types.
- Unit test: regression detector correctly identifies a regression.
- Integration test: a full run against a stubbed Strategist and stubbed judge produces a consistent score.

## Exit artifacts

- `evals/golden/strategist/*.yaml` (≥30 cases).
- `evals/runner.py`, `evals/judge.py`, `evals/scoring.py`, `evals/reporter.py`.
- `evals/baseline.md` with the initial score.
- Postgres migration adding `eval_runs` and `eval_case_results` tables.
- CI workflow under `.github/workflows/eval.yml`.
- `docs/eval-design.md` describing the scoring methodology.
- PR description references rule 04, principle 6 ("Evals are the contract").
