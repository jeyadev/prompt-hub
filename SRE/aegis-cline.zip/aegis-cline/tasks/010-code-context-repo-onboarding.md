# Task 010 — Code context: repository onboarding

**Phase:** 2 — Code Context
**Mode:** `code-context`
**Estimated effort:** medium–large (2–3 days)
**Depends on:** 001 (Postgres), 002 (Vault), Phase 1 substantially complete
**Blocks:** 011 (indexing), 012 (vector store), 013 (resolver)

## Objective

Build the first layer of the code-context stack: the onboarding flow that connects an app's repository to AEGIS, performs an initial pull, sets up webhook delivery for incremental updates, and resolves CODEOWNERS against AD for the human routing graph.

## Scope (in)

- `app/code_context/repo/` module.
- Connector implementations: GitHub Enterprise, Bitbucket, GitLab. Common interface `RepoConnector` in `connectors/base.py`.
- Authentication: GitHub-App style for GitHub Enterprise; OAuth Apps for Bitbucket/GitLab. All tokens resolved via Vault. Tokens are short-lived and refreshable.
- Onboarding API endpoint: `POST /api/code-context/repos` with body `{app_id, host, owner, repo, default_branch}`. Persists a `RepoBinding` row, kicks off initial clone, returns a job ID for status polling.
- Webhook receiver: `POST /api/code-context/webhooks/<host>`. Verifies signatures. Enqueues an update job. Idempotent on `(repo_id, commit_sha)`.
- Clone storage: local filesystem under `/var/aegis/repos/<repo_id>/`. Sharded by repo_id prefix for filesystem health.
- CODEOWNERS parsing: parse the file, resolve usernames against the JPMC AD via the existing identity service. Persist the resolved owner graph.
- Status surfacing: a `RepoBinding` carries fields `status`, `last_indexed_at`, `last_index_error`, `commit_sha`. Surfaced via `GET /api/code-context/repos/<id>`.
- Documentation: `docs/code-context/onboarding.md`.

## Scope (out)

- Actual code parsing / indexing — task 011.
- Embedding generation — task 012.
- Incident-to-code resolution — task 013.
- UI for onboarding — Phase 3 (Onboarding wizard subsumes this).
- Migration of historical commits (we index from the current HEAD; deep history is task 015).

## Acceptance criteria

- [ ] Onboarding a public-test repo via API succeeds and the clone appears on disk.
- [ ] A webhook delivery for that repo triggers a re-pull within 30 seconds.
- [ ] Signature verification rejects forged webhook payloads in a unit test.
- [ ] Webhook idempotency: replaying the same delivery is a no-op.
- [ ] CODEOWNERS resolution produces a deterministic owner graph; resolution is cached.
- [ ] Cloning a repo failing on auth produces a clear error in the `RepoBinding.last_index_error` field, not a silent failure.
- [ ] `mypy --strict` passes on `app/code_context/repo/`.
- [ ] Audit-log entries written on every onboarding event and webhook receipt.

## Implementation notes

- Use `dulwich` or `pygit2` for git operations. Avoid shelling out to `git` from the application process.
- The webhook receiver should respond fast (200 within 1s) and enqueue actual work. Use the existing task queue.
- Clone storage location is configurable; default for dev is `/tmp/aegis-repos`, prod is a mounted volume.
- For private repos at scale, shallow clones with depth 1 work fine for indexing; deepen on demand only if we ever need historical context.
- CODEOWNERS resolution can be expensive — cache aggressively, with a TTL of 24h. Invalidate on CODEOWNERS file change (which we detect via the webhook).
- Invariant 1 (MCP-only external tool integration): GitHub/GitLab/Bitbucket are accessed directly here because they are **source-of-record systems for the codebase itself**, not the kind of integration MCP wraps. This is the documented exception. The code-context MCP server (task 014) wraps the **resulting indexed data**, not the git providers themselves.

## Testing requirements

- Unit tests on connector implementations with hand-rolled HTTP mocks.
- Unit test on webhook signature verification, with fixtures for each provider's signature scheme.
- Unit test on CODEOWNERS parsing covering globs, team references, and edge cases (escaped chars, comments).
- Integration test: onboard a real test repo on a GitHub-Enterprise-equivalent (a self-hosted Gitea container is sufficient for the test environment).

## Exit artifacts

- `app/code_context/repo/` module with connectors, binding model, onboarding service, webhook handler.
- Alembic migration for `repo_bindings`, `code_owners`, `webhook_deliveries` tables.
- API routes under `app/routers/code_context.py`.
- `docs/code-context/onboarding.md`.
- Failure-mode entries in `docs/failure-modes.md` covering: auth expiry, network partition during clone, malformed CODEOWNERS, AD resolution failure.
- PR description references invariant 1 (with the documented exception) and the failure-mode additions.
