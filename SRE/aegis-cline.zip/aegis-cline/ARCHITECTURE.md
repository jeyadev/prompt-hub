# AEGIS — Architecture

## One-paragraph statement

AEGIS is an **orchestrator-workers** agent system with an **evaluator-optimizer** loop on the runbook layer. The Strategist (an Opus-class agent) synthesises observability and code context into a structured runbook. Sub-Agents (Sonnet-class) execute individual steps through MCP servers. A Verifier sub-agent confirms recovery by re-reading the observability state. The orchestrator owns the lifecycle of an incident from signal to resolution and writes every decision to an immutable audit log.

## Layers

```
┌─────────────────────────────────────────────────────────────┐
│                     UI · React Console                       │
│        Agent Builder · Ops Console · Run History             │
└─────────────────────────────┬────────────────────────────────┘
                              │  REST + SSE
┌─────────────────────────────▼────────────────────────────────┐
│                  API · FastAPI Service                       │
│   Agent Registry · Run API · Webhook Ingestor · Mode API     │
└─────────────────────────────┬────────────────────────────────┘
                              │
┌─────────────────────────────▼────────────────────────────────┐
│              Orchestrator · Incident Lifecycle                │
│   receive → enrich → strategise → execute → verify → close    │
└─────┬────────────────────────────────────────────────┬───────┘
      │                                                │
┌─────▼────────┐  ┌────────────┐  ┌──────────────┐  ┌─▼────────┐
│  Strategist  │  │ Remediator │  │ Communicator │  │ Verifier │
│   (Opus)     │  │  (Sonnet)  │  │   (Sonnet)   │  │ (Sonnet) │
└─────┬────────┘  └─────┬──────┘  └──────┬───────┘  └────┬─────┘
      │                 │                │                │
      │                 │                │                │
┌─────▼─────────────────▼────────────────▼────────────────▼─────┐
│                     MCP Servers (Tool Layer)                   │
│  Splunk · Dynatrace · AIOps · SLO · Remediation · Confluence  │
│        · Jira · Code Context (Phase 2)                         │
└────────────────────────────┬───────────────────────────────────┘
                             │
┌────────────────────────────▼───────────────────────────────────┐
│                     Persistence                                 │
│   Postgres (state, runbooks, mode) · pgvector (incident hist,  │
│   code embeddings) · Audit log (separate store, append-only)   │
└─────────────────────────────────────────────────────────────────┘
```

## Components

### Orchestrator

Owns the incident state machine: `received → enriching → diagnosing → staging → executing → verifying → closed`. Stateless agents read context; the orchestrator owns state. Crash-safe: every state transition writes audit, and the lifecycle can be resumed by re-reading audit + state.

### Strategist

Single agent, Opus-class. Receives the enriched context packet (alert + observability + code context + history) and emits a `Runbook` — a typed object with hypotheses (each with confidence), steps (each with action type and confidence), and metadata.

Prompt is in `agents/strategist/prompt.py`. Schema is in `agents/strategist/schemas.py`. Eval cases in `evals/strategist/`.

### Sub-Agents

- **Remediator** — executes mutating actions through the Remediation MCP. The only path to production-writing capability.
- **Communicator** — writes to Jira (incident records) and Confluence (post-incident notes). Cannot remediate.
- **Verifier** — re-queries observability MCPs after an action to confirm recovery. Read-only.

Each is Sonnet-class. Each has a tight, typed contract with the orchestrator.

### MCP Servers

Each external system has its own MCP server (most we maintain; some are vendor-provided). Adapters in `mcp/<system>/` follow rule 07.

### Persistence

- **Operational data** in Postgres (in flight; migrating from SQLite). Schema in `app/db/`.
- **Vectors** (incident history, code embeddings) in `pgvector` extension on the same Postgres.
- **Audit log** in a separate append-only store. Schema in `docs/audit-schema.md`.

## Data flow for a typical incident

1. **Signal in.** Dynatrace fires a P1 webhook → API ingestor.
2. **Receive.** Orchestrator creates incident record, writes audit entry.
3. **Enrich.** Orchestrator queries observability MCPs (Splunk recent errors, AIOps correlations, SLO state) and the code-context MCP (Phase 2: failing function source, recent diffs, similar past incidents). Assembles the context packet, bounded to ~8K tokens.
4. **Diagnose.** Strategist invoked with the packet. Returns a `Runbook` with ranked hypotheses and steps.
5. **Stage.** Orchestrator decides per-step: in `auto` mode with confidence above threshold → execute immediately; otherwise → present in UI for human approval.
6. **Execute.** Approved/auto steps dispatched to the appropriate Sub-Agent. Sub-Agent calls Remediation MCP (or Jira/Confluence). Idempotency key carried through.
7. **Verify.** Verifier sub-agent invoked after a wait period. Re-queries observability. Reports recovery or persistence.
8. **Close.** If recovered, orchestrator captures resolution into incident history (vector-indexed for future similarity match). If not, returns to step 4 with the new context.
9. **Audit.** Every step above writes to the audit log.

## What's true today

- Orchestrator, Strategist, three Sub-Agents implemented at MVP quality.
- Splunk, Dynatrace, AIOps, SLO, Remediation, Confluence, Jira MCPs wired (some are mocks pending vendor MCP delivery).
- React console functional for Agent Builder, Ops Console, Run History.
- SQLite persistence (Phase 1 migrates to Postgres).
- SSE streaming for the Ops Console.
- Three fix modes implemented and enforced at the executor.

## What's coming (per ROADMAP.md)

- Phase 1: identity, RBAC, secrets, audit log to its own store, HA, OTel, prompt-injection defence, eval harness v1.
- Phase 2: code-context MCP, repo onboarding, indexing, retrieval, incident-to-code resolution, code-aware Strategist.
- Phase 3: self-serve onboarding, trust ladder, per-app evals.
- Phase 4: scale, governance, cross-app intelligence, operating model.
