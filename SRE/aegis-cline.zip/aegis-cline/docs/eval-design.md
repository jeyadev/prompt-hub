# AEGIS — Eval Design

How we measure agent quality. This document is the methodology; the implementation is in `evals/`.

## Why evals at all

A change to an agent's prompt, model, or context strategy that "feels better" is not evidence. We make changes based on numbers against a reproducible set, not based on intuition. Without this, prompt engineering drifts and quality regresses silently.

## What we measure

For the Strategist (the first agent under formal eval):

- **Schema validity.** Does the output parse as a `Runbook`? Are required fields present? Are confidence scores in [0, 1]?
- **Hypothesis quality.** Are the hypotheses well-formed? Are they ranked in a sensible order? Does the top hypothesis at least *type-match* the labeled correct cause class (deploy-induced, dependency, capacity, configuration, infra)?
- **Cause precision.** Does the top hypothesis match the actual cause in the labeled case? This is the headline metric for code-aware runbooks (Phase 2).
- **Runbook plausibility.** Would a senior SRE accept this runbook? Judged by an LLM judge with the senior-SRE persona.
- **Confidence calibration.** When the Strategist says 0.85, is the cause right ~85% of the time? Tracked across runs.
- **Cost per case.** Tokens and dollars. Spikes are investigated.

## Scoring layers

### Layer 1 — Deterministic

Pure code. Fast. Cheap. Catches structural regressions.

- Schema validation
- Confidence bounds
- Banned content (no PII in output, no "I think" prose where structured fields are required)
- Token-cost bounds (no run that costs > 2× the median)

### Layer 2 — Judge LLM

A separate Sonnet-class agent with a senior-SRE persona scores qualitative properties: hypothesis plausibility, runbook step quality, "would I act on this."

The judge returns a structured `JudgeVerdict`:

```python
class JudgeVerdict(BaseModel):
    case_id: str
    overall_score: float  # 0–10
    hypothesis_plausibility: float  # 0–10
    runbook_actionability: float  # 0–10
    cause_match: bool
    rationale: str  # for human review
    flags: list[str]  # e.g. "vague", "missing-rollback", "wrong-paging"
```

### Layer 3 — Human spot check

Every release picks 5 random cases from the latest run and a human reviews the judge's verdict. We are calibrating the judge as much as the agent. If judge-vs-human agreement drops below 80%, we revisit the judge prompt.

## The golden set

### Composition

- 30 cases minimum to start (Phase 1 task 004).
- Distributed across cause classes: deploy-induced ~30%, dependency degradation ~25%, capacity ~15%, configuration ~15%, infra ~15%.
- Severity-weighted: at least 5 P1-like cases, the rest split across P2/P3.
- Real provenance: ≥80% derived from real (anonymised) JPMC incidents. ≤20% hand-crafted to cover edge cases the real set doesn't hit.

### Curation

The set is curated, not collected. Adding a case requires:

- The original incident ID (or "synthetic" with rationale).
- The labeled inputs (alert, observability summary, code context if Phase 2).
- The labeled expected output (cause class at minimum; full expected runbook for high-value cases).
- A short note on what this case tests that others don't.

Retiring a case: when the system under test has changed enough that the case is no longer representative, mark it `retired: true` with a date and reason. It stays in the repo for replay but doesn't count toward the score.

### Refresh cadence

- New cases added weekly from real resolved incidents.
- Set audited quarterly for class balance.
- Set never grows for the sake of growing — we cap at ~150 cases for v1; beyond that we sample.

## When the eval runs

- **PR-time:** on changes to `agents/`, `evals/`, or any prompt file. Subset of ~10 cases for fast feedback (under 5 min). Full set runs nightly on the PR branch if it's still open.
- **Nightly on `main`:** full set, results stored in Postgres.
- **Pre-release:** full set with stricter regression threshold.
- **On-demand:** any developer can trigger a run against any branch.

## Regression detection

Default threshold: 2% drop in the aggregate score blocks the PR. Tunable per-agent (Strategist is stricter than Communicator).

Regression is computed against the most recent `main` run, not against a fixed baseline. This lets quality improve over time without blocking on stale thresholds.

## The judge is versioned

Every judge invocation records the hash of the judge prompt and the model. When we change the judge prompt, the new baseline is set against itself, and we re-score recent runs to maintain comparability.

## What evals do not catch

- Real-world novelty. The set is a sample; production isn't. We complement evals with online metrics (suggestion-accept rate, time-to-resolution).
- Adversarial input that wasn't in the set. The injection-detection eval is a separate suite for this category.
- Slow-burn quality drift between formal runs. Hence the nightly cadence.

Evals are necessary but not sufficient. They are the floor.
