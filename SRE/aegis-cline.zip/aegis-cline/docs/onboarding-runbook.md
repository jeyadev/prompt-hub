# AEGIS — Application Onboarding Runbook

The flow an app team follows to onboard their service to AEGIS. The Phase 3 wizard will automate most of this; this document is the underlying contract.

## Before you begin

You need:

- Owner authority on the service you're onboarding (or sign-off from the owner).
- Repo write access (to add `aegis.yaml`).
- Splunk index name for the service.
- Dynatrace entity ID for the service.
- The service's on-call rotation, mapped to PagerDuty or equivalent.
- One past incident with full timeline (we use it to baseline AEGIS's suggestions during Shadow).

## Step 1 — Add `aegis.yaml`

In your repo root:

```yaml
# aegis.yaml
schema_version: 1

service:
  id: cds-gateway
  name: CDS API Gateway
  tier: 1
  owners:
    primary: cds-platform-team@example.com
    escalation: cds-leadership@example.com

repo:
  host: github-enterprise
  owner: ai-platform
  name: cds-gateway
  default_branch: main

runtime:
  platform: kubernetes
  namespace: cds-prod
  deployment: cds-gateway

observability:
  splunk:
    index: cds_app
  dynatrace:
    entity_id: HOST-ABC123
  slo_tracker:
    service_id: cds-gateway

on_call:
  provider: pagerduty
  schedule_id: P12345

mode:
  initial: shadow  # always shadow on first onboarding
```

Commit this in a PR. CI validates the schema.

## Step 2 — Trigger onboarding

`POST /api/onboard` with `{service_id, repo_binding}`. The endpoint:

- Reads `aegis.yaml` from your repo's `main`.
- Validates that the Splunk index and Dynatrace entity are reachable from AEGIS's identity.
- Clones and indexes the repo (Phase 2 onward).
- Generates a first-pass runbook library from your Confluence pages (Phase 3).
- Sets the service mode to `shadow`.

Status is polled at `GET /api/services/<id>/onboarding`.

## Step 3 — Shadow for two weeks

For two weeks:

- AEGIS observes every incident on your service.
- AEGIS generates a runbook for each but executes nothing.
- Your responders work the incident normally.
- AEGIS compares its generated runbook to the human resolution.
- The scorecard for your service updates daily.

You can review the scorecard at `/services/<id>/scorecard`.

## Step 4 — Graduate to Suggest-only

When your scorecard shows ≥85% suggestion-accept rate over the shadow window:

- Request promotion through the Ops Console.
- A platform-SRE reviews the scorecard and approves.
- AEGIS moves to `suggest_only`: generated runbooks appear in the incident bridge as suggestions for the on-call.

Spend at least two more weeks here. Demote yourself with one click if AEGIS suggests something wrong.

## Step 5 — Graduate to Approval-required

When suggestion-accept stays high and your team is comfortable:

- Request promotion.
- AEGIS now stages actions; humans approve; AEGIS executes.

This is the typical steady state. Many services live here forever.

## Step 6 — Auto (optional, scoped)

For Tier-3 services only, after at least 60 days in Approval-required with high accuracy and zero false-positive destructive proposals, you can request specific action types to graduate to `auto`. Destructive actions never become `auto`.

## Self-service controls

You can, at any time and with one click:

- Demote AEGIS's mode for your service.
- Pause AEGIS entirely for your service.
- View every action AEGIS has staged or executed on your service in the last 90 days.
- Comment on a generated runbook to give the platform team feedback.

## When AEGIS gets it wrong

It will, sometimes. The expectation is **trust through evidence**, not trust through promises. The mode ladder exists because evidence is collected at each step.

If AEGIS suggests something dangerous in Shadow or Suggest-only mode, the cost is one suggestion you ignore. The scorecard captures it. The eval set learns from it. The platform team is notified automatically when a service's suggestion-accept rate drops.

If AEGIS executes something wrong in Approval-required mode, it's because a human approved it. The action gate enforces this. The post-incident review names this honestly.

If AEGIS executes something wrong in Auto mode, that is a serious event. The action gate has explicit guardrails — no destructive actions, confidence floors, scoped action types. A failure here triggers an immediate demotion and a review.

## Quarterly review

Every onboarded service gets a quarterly review with the platform team:

- What worked.
- What didn't.
- What new action types should AEGIS support for this service.
- What runbook templates should be retired.
- Whether the service is ready to graduate further.

The review is a conversation, not a form. It is the heart of the FDE operating model.
