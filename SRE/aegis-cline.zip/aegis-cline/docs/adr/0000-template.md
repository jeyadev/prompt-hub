# ADR NNNN — [Title]

**Status:** proposed | accepted | superseded by ADR NNNN | deprecated
**Date:** YYYY-MM-DD
**Deciders:** Jey Ganesh (+ others if relevant)
**Related:** ROADMAP phase N, task NNN, rule N

## Context

The situation that requires a decision. Two or three paragraphs maximum. Include:

- What problem are we solving?
- What constraints apply (invariants, phase, security posture)?
- What's the current state, if any?
- Why is this decision needed *now* rather than later?

## Decision drivers

The forces that shape the decision. Bullet list of the considerations that matter — performance, cost, operability, audit, vendor risk, time-to-market, reversibility. Each one rated on a rough scale (must-have, important, nice-to-have).

## Considered options

### Option A — [Name]

One-paragraph description. Then:

- Pros: what this option gives us.
- Cons: what it costs us.
- Risk: how it can fail and what catches it.

### Option B — [Name]

Same shape.

### Option C — [Name]

Same shape.

(Two options is the minimum. If you only have one option, the decision is already made — you don't need an ADR for it.)

## Decision

**We choose Option [X].**

The rationale in 2–3 sentences. The rationale references the decision drivers — "Option B because operability and reversibility outweighed the perf gains of Option A."

## Consequences

What follows from this decision. Both positive and negative:

- **Good:** capability X becomes possible.
- **Good:** simplification of subsystem Y.
- **Bad:** we now owe Z (a migration, a deprecation, a new dependency).
- **Bad:** we lose flexibility on W.

## Failure modes introduced

What new failure modes does this decision introduce? Each one gets an entry in `docs/failure-modes.md` referencing this ADR. (Or a reason this decision doesn't add any.)

## Out of scope

What this ADR explicitly does not decide. Decisions that are adjacent and should be made in their own ADR.

## References

- Related ADRs: NNNN, NNNN
- Related rules: 0N, 0N
- Related tasks: NNN, NNN
- External: vendor docs, prior art, RFCs
