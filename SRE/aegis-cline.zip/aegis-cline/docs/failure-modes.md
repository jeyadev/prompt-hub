# AEGIS — Failure Modes

This is a living catalogue of the ways AEGIS can fail, the blast radius of each, what catches the failure, and the residual risk we accept. Every PR that changes agent behavior or adds reach must update this document.

## Format

```
## FM-NNN — Short title
**Component:** which part of AEGIS
**Severity:** S1 (catastrophic) | S2 (significant) | S3 (contained) | S4 (cosmetic)
**Likelihood:** high | medium | low
**Blast radius:** what's affected if it happens
**Detection:** what catches it
**Mitigation:** what we do about it
**Residual risk:** what's left after the mitigation
**Added:** YYYY-MM-DD by whom, referencing task NNN if applicable
```

## Seed entries

## FM-001 — Strategist hallucinates a confident wrong cause
**Component:** agents/strategist
**Severity:** S2
**Likelihood:** medium
**Blast radius:** wrong remediation gets staged. In approval mode, humans catch it but trust erodes. In auto mode, wrong action executes.
**Detection:** eval harness golden set explicitly includes "confident wrong cause" test cases; on-call feedback through the runbook scoring API.
**Mitigation:** confidence thresholds gate auto-execution; per-action confidence floors; auto mode only for low-blast-radius actions; weekly eval regression catches drift.
**Residual risk:** novel incident class not represented in the golden set could slip through. Mitigated by graduation criteria — services only reach auto mode after demonstrated accuracy.
**Added:** 2026-05-13 by setup

## FM-002 — Indirect prompt injection through log content
**Component:** orchestrator/context
**Severity:** S1
**Likelihood:** low (today), medium (as adversaries learn)
**Blast radius:** Strategist's behavior could be manipulated by an attacker who can write to a log we ingest. Worst case: triggering a destructive action.
**Detection:** injection-detection eval suite; structured-output enforcement catches most attempts.
**Mitigation:** input partitioning with explicit delimiters; tool-use forces structured output; destructive actions never available in auto mode; eval suite expands as we encounter novel injections.
**Residual risk:** sufficiently sophisticated injection that bypasses partitioning is theoretically possible. Action governance (no destructive auto-mode actions) is the backstop.
**Added:** 2026-05-13 by setup

## FM-003 — MCP server returns malformed response
**Component:** mcp/<any>
**Severity:** S3
**Likelihood:** medium
**Blast radius:** an agent gets garbage context, produces a degraded runbook.
**Detection:** Pydantic validation on all MCP responses; circuit breaker on repeated malformed responses; per-call schema verification.
**Mitigation:** orchestrator catches `MCPProtocolError`, degrades to symptom-only mode, alerts platform team.
**Residual risk:** silent partial corruption (valid schema, wrong values) — eval harness with synthetic-corruption test cases catches this category.
**Added:** 2026-05-13 by setup

## FM-004 — Audit write fails; action proceeds anyway
**Component:** orchestrator + app/audit
**Severity:** S1 (compliance)
**Likelihood:** low
**Blast radius:** an action without a corresponding audit record — invariant 3 violated. Regulatory exposure.
**Detection:** audit-chain verification script; weekly reconciliation of action-table rows against audit rows.
**Mitigation:** rule 05 hard requirement — if audit write fails, the calling operation must also fail. Enforced in the action gate. Verified by integration test.
**Residual risk:** a bug in the action gate could re-introduce this. CI test specifically guards against it.
**Added:** 2026-05-13 by setup

## FM-005 — Token budget exhaustion mid-incident
**Component:** orchestrator + agents
**Severity:** S3
**Likelihood:** medium
**Blast radius:** Strategist produces no output for that incident; falls through to human-only mode.
**Detection:** the agent raises explicitly; logged with the budget overshoot amount.
**Mitigation:** per-agent budgets are conservative; orchestrator catches the exception and degrades cleanly; alerts platform team when budget exhaustion is happening more than 1% of incidents.
**Residual risk:** during a major outage with many incidents, cost could spike. Daily cost cap halts AEGIS gracefully rather than running unbounded.
**Added:** 2026-05-13 by setup

## FM-006 — Code resolver returns wrong function for a stack frame
**Component:** code_context/resolver
**Severity:** S2
**Likelihood:** medium (Phase 2 onward)
**Blast radius:** Strategist gets misleading context; suggests reverting the wrong PR.
**Detection:** retrieval eval set with labeled (incident, correct code location) pairs; weekly regression.
**Mitigation:** confidence on the packet itself; Strategist degrades to symptom-only when confidence is low; human approval mode required for code-suggested rollbacks until the cause-precision metric is established.
**Residual risk:** stack-frame parsers have language-specific edge cases. Each one we miss is a new failure-mode entry.
**Added:** 2026-05-13 by setup (anticipated; activates when Phase 2 ships)

---

(Add entries above this line. Number sequentially. Reference task IDs.)
