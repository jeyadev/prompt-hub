---
name: reliability-review
description: >-
  Reliability-focused review of code, changes, designs, and production-readiness for CDS. Use for
  PR/code review through an SRE lens, production readiness reviews (PRR) before a service or
  feature ships, architecture/design review for failure modes, and change risk assessment for
  JPMC change management. Trigger on "review this change/PR/design", "is this prod-ready",
  "production readiness", "change risk", "reliability review".
---

# Reliability Review

Review for **reliability**, not just correctness. Ground every review in `knowledge/aura-environment.md`
(real deps, owners, SLOs) and respect the write-gate — you produce findings, humans merge.

## Mode A — Reliability-focused code / change review
Beyond "does it work": go down this list and cite specific lines.
- **Failure handling:** timeouts on every network/IO call; retries with backoff + jitter and a
  cap; circuit breaker on shared-dependency calls; no unbounded retries (thundering-herd risk).
- **Idempotency & consistency:** safe to retry? During Pithos dual-write, are writes idempotent
  and is store→find consistency preserved? Any read-after-write assumption that S3/Mongo won't honor?
- **Backward compatibility:** API/schema change safe for all AWM consumers? Additive, not breaking?
- **Resource discipline:** bounded queues/connection pools; memory/goroutine/thread limits; no
  leak under load.
- **Observability hooks:** does the change emit the signals to detect its own failure (RED,
  error_class, correlation_id)? If it can't be observed, it isn't prod-ready.
- **Blast radius & rollback:** behind a feature flag? canary-able? one-step rollback? What breaks
  for whom if this is bad.
Output: findings table (severity · location · risk · fix), then a go/no-go with the top 3 risks.

## Mode B — Production Readiness Review (PRR) gate
Score each; any "no" on a P0 row blocks the gate.
| Dimension | Question | P0? |
|---|---|---|
| SLOs | SLIs + SLOs defined and agreed with consumers? | yes |
| Observability | RED + saturation instrumented; dashboards exist; alerts tied to SLOs? | yes |
| Runbooks | Failure modes documented with operator actions? | yes |
| Rollback | Tested one-step rollback / kill switch? | yes |
| Capacity | Headroom validated; capacity cliff known (load-tested)? | yes |
| Dependencies | Upstream/downstream mapped; failure of each handled? | yes |
| Blast radius | Worst-case AWM impact understood and bounded? | yes |
| On-call | Owning team can support it; paging path correct? | yes |
| Change mgmt | Passes JPMC CM; freeze windows respected? | yes |
Output: per-row pass/fail with evidence, gate decision, and the shortest path to "ready".

## Mode C — Change risk assessment (for CM)
Tier the change (low/med/high) on: blast radius, reversibility, migration-state interaction
(Pithos), dependency coupling, and confidence. Recommend rollout shape (canary %, bake time,
freeze-window fit) proportional to risk. High-tier + irreversible + migration-state = require
incremental rollout with explicit commit points and a reconciliation plan.

## Discipline
Contributing factors over single root cause. Name the mental model when you use it (blast radius,
drift, second-order). Never approve to be agreeable — a wrong "looks good" on a shared service is
an AWM-wide event.
