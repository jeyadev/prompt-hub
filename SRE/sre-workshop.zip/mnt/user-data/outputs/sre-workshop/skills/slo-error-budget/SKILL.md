---
name: slo-error-budget
description: >-
  Define SLIs, SLOs, and error-budget policies for CDS, and reason about error-budget burn. Use to
  pick good SLIs, set SLO targets, design error-budget policy, or translate reliability vs velocity
  decisions into budget terms. Trigger on "SLO", "SLI", "error budget", "burn rate", "reliability
  target", "what should our SLO be".
---

# SLO / Error Budget

The error budget is a **communication tool** between reliability and velocity, not a number to
hit. Budget remaining = room to take risk; budget exhausted = reliability outranks features.
Ground definitions in `knowledge/aura-environment.md` and where SLOs already live as-code.

## Defining an SLI
- Pick SLIs that reflect **consumer experience**, not internal vanity: availability (good/valid
  requests), latency (a threshold or percentile target), and for CDS specifically **correctness**
  (store-to-find consistency — a stored doc must be findable).
- **Define good vs valid explicitly.** `availability = good/valid`; ambiguous denominators
  produce SLOs that lie. Missing telemetry counts as **blind**, not good.
- Latency SLIs use a percentile and a threshold (e.g. 95% of finds < X ms), never an average.

## Setting the SLO
- Start from what consumers actually need and what the system has historically delivered — not a
  round number. 100% is the wrong target (no room to ship, no room to fail).
- Agree it with the AWM consumers who depend on CDS; an SLO nobody accepts isn't a contract.

## Error-budget policy (write it before you need it)
- Budget healthy → ship; take risk; do migrations.
- Budget at risk (e.g. >X% consumed) → slow risky changes, prioritize reliability work.
- Budget exhausted → change freeze on the affected service until recovered; reliability work jumps
  the queue. The policy makes this automatic instead of an opinion battle.

## Burn-rate alerting
Use **multi-window multi-burn-rate** (fast + slow windows must both fire) so blips don't page but
sustained burn does. Page on fast burn (~2% of budget in 1h), ticket on slow burn (~5% in 6h). The
concrete SPL/PromQL lives in the o11y kits — route implementation there:
- Prometheus/Grafana → `grafana-sre-kit` (recording rule + multiwindow alert).
- Splunk → `splunk-sre-kit` (burn-rate search).

## Output
SLI definitions (good/valid stated) · proposed SLO with rationale and consumer sign-off note ·
error-budget policy thresholds · burn-alert spec handed to the right o11y kit · 2-sentence version
for Kunal.
