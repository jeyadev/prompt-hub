---
name: postmortem
description: >-
  Write blameless postmortems / incident retrospectives for CDS. Use after an incident to build a
  timeline, identify contributing factors (not a single root cause), and produce actionable,
  owned follow-ups. Trigger on "postmortem", "retro", "incident review", "RCA", "writeup",
  "what went wrong".
---

# Postmortem (Blameless)

Complex systems run degraded and fail from interacting factors (Cook). Resist the single, tidy
root cause — it's usually hindsight bias dressed as insight. Blameless: focus on the conditions
the system created, not the person who hit the button.

## Structure
1. **Summary** — what happened, impact (which AWM consumers, duration, SLO/error-budget burned),
   in 3–4 sentences.
2. **Timeline** — detection → mitigation → resolution, with the signals at each step and where
   detection was slow (observability gaps are findings, not footnotes).
3. **Contributing factors** — multiple, across the sociotechnical system: technical (the change,
   a missing timeout), process (a skipped validation under deadline), and conditions (drift — the
   silenced alert, the loosened review cadence). Name what *normally* makes this work and why it
   didn't (Safety-II).
4. **What went right** — the human adaptations and fast mitigations worth preserving.
5. **Action items** — each: specific · owned · dated · sized. Tie each to a contributing factor.
   Prefer leverage: information flows / balancing loops over one-off patches. Distinguish "prevent
   recurrence" from "detect faster" from "reduce blast radius."

## Discipline
- No counterfactuals as causes ("should have known"). Ask what the responder actually saw.
- "Human error" is a starting question, not a conclusion — what made the error likely?
- Action items that say "be more careful" are non-actions. Rewrite as a system change.
- Feed observability gaps back to the `observability` skill and the o11y dictionaries; feed
  recurring toil to `toil-automation`.

## Output
A governance-ready blameless postmortem (the structure above) plus a 2-sentence exec summary for
Kunal and a clean action-item table (item · owner · due · type: prevent/detect/blast-radius).
