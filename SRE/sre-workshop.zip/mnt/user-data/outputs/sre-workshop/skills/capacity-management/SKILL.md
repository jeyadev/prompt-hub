---
name: capacity-management
description: >-
  Capacity planning and management for CDS on JPMC Private Cloud. Use for demand forecasting,
  headroom and saturation analysis, capacity-cliff / load-test reasoning, provisioning and
  scaling decisions, cost-aware capacity, and capacity impact of the Pithos migration. Trigger on
  "capacity", "headroom", "forecast demand", "do we have enough", "scaling plan", "saturation",
  "load test".
---

# Capacity Management

Private-cloud reality first: **Gaia/CPSR is not elastic.** Capacity is a forecasting +
procurement + lead-time problem, not an autoscale slider. Plan ahead or absorb risk. Ground in
`knowledge/aura-environment.md` (real services, deps, consumers) and the Grafana metrics for
saturation signals.

## Principles
- **Capacity = f(demand, efficiency, headroom).** Move any of the three; know which you're moving.
- **Demand has two engines:** organic growth (trend) and inorganic (launches, onboarding a new
  AWM consumer, migration cutover). Forecast both; inorganic is where surprises live.
- **Saturation is a golden signal.** Track utilization toward limits (CPU, memory, connection
  pools, queue depth, IOPS), not just averages.
- **Queueing-theory knee:** latency stays flat then explodes as utilization passes ~70–80%. Target
  steady-state utilization **below the knee**, sized so failover/burst still fits under it. Little's
  Law (L = λW) connects throughput, concurrency, and latency — use it to reason about pool sizes.
- **Headroom is deliberate:** size for peak + N+1 redundancy + failover absorption + lead-time
  buffer, not for average. On a shared service, headroom must cover the *sum* of AWM consumers'
  peaks, which may not coincide — but plan as if they can.
- **Find the cliff before prod does.** Load-test to the non-linear degradation point so the
  capacity cliff is a known number, not a 2am discovery.
- **Cost-aware:** headroom isn't free. Right-size; over-provisioning is its own debt on a governed
  private cloud.

## Workflow
1. **Baseline.** Pull current demand + saturation per service from Grafana/Cortex (USE method:
   Utilization, Saturation, Errors for each resource). State the window and the peak, not the mean.
2. **Forecast.** Project organic trend + name inorganic events (next AWM consumer, Pithos ramp
   phases). Give a range, not a point.
3. **Headroom check.** Compare forecast peak + redundancy + failover against capacity limits.
   Identify the binding constraint (the bottleneck resource — improving anything else is waste).
4. **Lead-time gate.** If new capacity is needed, when must the procurement/provisioning request
   land given Gaia/CPSR lead time? This date is the real deadline.
5. **Recommend.** Scale / optimize-efficiency / shed-load / accept-risk — proportional to the gap,
   with the cliff number and the lead-time date stated.

## Pithos migration note
The cutover changes the capacity profile: IBM CM → S3 + MongoDB shifts where load and limits live
(object throughput, Mongo connection/working-set limits, S3 request rates). The first 72 hours
have **no historical baseline** — size from the ramp plan and watch saturation, not historical norms.

## Output
A capacity assessment: per-service headroom vs forecast, the binding constraint, the cliff number,
the lead-time deadline, and a recommendation with its risk if deferred. 2-sentence version for Kunal.
