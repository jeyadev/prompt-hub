---
name: observability
description: >-
  Observability for CDS across logs (Splunk) and metrics (Grafana/Prometheus). Use to generate
  SPL or PromQL, design Splunk or Grafana dashboards, build SRE notebooks, or decide which signal
  belongs in logs vs metrics. Trigger on "Splunk", "SPL", "Grafana", "PromQL", "dashboard",
  "metric", "log query", "golden signals", "observability".
---

# Observability (router)

Two engines do the heavy lifting; this skill routes to them and enforces the division between them.

## The division (decide before querying)
- **Metrics (Grafana/Prometheus, Cortex):** low-cardinality aggregates — RED, saturation, SLO
  burn, capacity. Cheap, real-time, alertable. Never put unbounded identifiers (doc_id, account)
  in labels.
- **Logs (Splunk):** high-cardinality correlation — per-`doc_id` store-to-find consistency,
  error-class breakdowns, investigation. The orphaned-S3-GET-404 correctness signal lives **here**,
  not in metrics, because it needs per-id correlation.
If a request needs per-identifier correlation → Splunk. If it needs a low-cardinality
trend/alert → Grafana/Prometheus.

## Routing
- SPL generation, Splunk dashboards (Dashboard Studio JSON) → **`splunk-sre-kit`**
  (`/generate-spl`, `/build-dashboard`). Reads `cds-splunk-data-dictionary.md`.
- PromQL, Grafana 10 dashboards, recording/alerting rules, SRE notebooks →
  **`grafana-sre-kit`** (`/generate-promql`, `/build-dashboard`, `/build-notebook`). Reads
  `cds-metrics-dictionary.md`.
- Real-time / circuit-breaker signal → Dynatrace (via AURA), correlate with the above.

## Shared discipline (both kits enforce)
Scope + time-bound everything · percentiles not averages for latency · base+chain (Splunk) /
recording rules + `$__rate_interval` (Grafana) to protect shared infra · thresholds tied to SLOs ·
dashboards/alerts via dashboard-as-code, never agent-published · missing telemetry = blind.

## Grounding
The dictionaries are the lever — their quality caps output. Keep them fresh via the AURA
Orchestrator (`/aura-discovery`), which reconciles assumed index/metric/field names against reality.
