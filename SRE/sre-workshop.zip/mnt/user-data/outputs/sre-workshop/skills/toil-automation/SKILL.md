---
name: toil-automation
description: >-
  Identify operational toil and design automation for CDS — including L1/L2 support automation and
  queue hygiene. Use to spot toil, decide what to automate, and design automation that keeps a
  human in the loop. Trigger on "toil", "automate this", "manual work", "L1/L2", "queue hygiene",
  "reduce on-call burden", "runbook automation".
---

# Toil & Automation

Toil = manual, repetitive, automatable, tactical, no-enduring-value work that scales with service
size. It's a reinforcing loop: toil crowds out the engineering that would reduce toil. Break the
loop — but carefully.

## Identify
Score candidate work on: frequency × time-per-occurrence × number-of-people × predictability.
High-frequency + predictable + low-judgment = automate first. Pull recurring patterns from the
PBA/IPB queues and from postmortem action items.

## Safety-II check before automating (do not skip)
Ask what's currently working *because* a human is compensating. L1/L2 staff hold institutional
knowledge about how CDS actually behaves vs how it's documented. Automating the visible steps can
remove the invisible adaptation and make L2 escalations *worse* (second-order effect: engineers
lose pattern recognition). Automate the toil; **preserve the judgment**. Treat support staff as
knowledge holders, not just ticket processors — capture what they know before you replace what
they do.

## Design pattern: draft-action, human approves
Default to the **draft-action** pattern, not autonomous action. The automation does the toil —
gathers context, drafts the triage/response/runbook step, proposes the fix — and a human
one-click approves. This collapses toil while preserving the write-gate: nothing mutates prod
autonomously. Deterministic first — fingerprint/rule-match known cases and short-circuit before
any LLM call; the knowledge base sets the ceiling.

## Evaluate honestly
- What's the measured toil baseline (hours/week), and what does the automation actually remove?
- Vendor noise-reduction claims (90–99%) diverge from measured reality (~50–60%) — use your own
  baseline, not the brochure.
- Does the automation create new operational debt (a thing to maintain, a new failure mode)?
- Does it still work when the team is stretched or during on-call crunch?

## Output
Toil inventory ranked by leverage · the Safety-II risk for each candidate · a draft-action design
for the top candidate · measured-baseline success metric · 2-sentence version for Kunal.
