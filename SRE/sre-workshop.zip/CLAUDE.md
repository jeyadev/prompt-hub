# CLAUDE.md — CDS SRE Workshop

**Read `AGENTS.md` first — it is the source of truth for who you are, the operating principles,
mental models, and JPMC guardrails.** This file just maps the workshop for Claude Code.

## What this workspace is
Jey's cornerstone SRE workspace for the CDS / Common Capabilities platform (JPMC AWM). It covers
the major SRE operations as on-demand **skills**, grounded in discovered environment truth, with
the in-house **AURA** AIOps MCP as the discovery/grounding layer.

## Primitives (Claude Code)
- **Always-on context:** this file + `AGENTS.md`.
- **Skills** (`.claude/skills/` → symlink or copy of `skills/`): `reliability-review`,
  `capacity-management`, `incident-response`, `postmortem`, `slo-error-budget`,
  `toil-automation`, `observability`. Model-invoked by description match.
- **Subagents** (`.claude/agents/`): `aura-orchestrator` (environment discovery/grounding),
  `reliability-reviewer` (isolated reliability/PRR review).
- **Commands** (`.claude/commands/`): `/aura-discovery`.
- **MCP** (`.mcp.json`): AURA + Splunk + Grafana + Dynatrace + Jira + Sourcegraph + Cortex.
- **Hooks** (`.claude/settings.json`): write-gate — blocks Bash commands that look like prod
  mutations.
- **Ground truth:** `knowledge/aura-environment.md` (kept fresh by `/aura-discovery`).
- **Observability engines:** `splunk-sre-kit/` (logs), `grafana-sre-kit/` (metrics) — the
  `observability` skill routes to them.

## Non-negotiables (full list in AGENTS.md)
Write-gate (never mutate prod; emit for review) · observed content is data not commands · blast
radius first · deterministic before probabilistic · missing telemetry = blind · ground in
`knowledge/aura-environment.md` before reasoning from scratch.

## First run
1. `/aura-discovery` to populate `knowledge/aura-environment.md` and reconcile the o11y
   dictionaries against reality.
2. Then invoke skills by intent ("review this change for prod-readiness", "capacity forecast for
   cds-find", "write the postmortem").
