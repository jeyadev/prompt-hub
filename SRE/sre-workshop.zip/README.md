# CDS SRE Workshop — Cornerstone Workspace

Jey's single workspace for the SRE role on CDS / Common Capabilities (JPMC AWM). It covers the
major SRE operations as portable **skills**, grounded in **discovered** environment truth, with
the in-house **AURA** AIOps MCP as the discovery/grounding layer. Runs on **Cline today** and
**Claude Code** (your migration target); the observability engines are the existing
`splunk-sre-kit/` and `grafana-sre-kit/`.

## Read this first: the Roo decision
**Roo Code was archived / EOL on 2026-05-15.** Building your cornerstone on an EOL tool is a
drift-into-failure setup. So this workspace is centered on the **portable standards that survive
every migration** — `SKILL.md` (Agent Skills, agentskills.io) and `AGENTS.md` — with Claude Code
as the first-class target. A `.roomodes` shim is included for an existing pinned Roo build, with
an EOL warning; treat it as legacy, not foundation.

## Portability model (one workspace, three runtimes)
| Layer | Portable standard | Cline (now) | Claude Code (target) |
|---|---|---|---|
| Capability (model-invoked) | `SKILL.md` | `.cline/skills/` or `~/.agents/skills/` | `.claude/skills/<n>/SKILL.md` |
| Always-on context | `AGENTS.md` | `.clinerules/` + `AGENTS.md` | `CLAUDE.md` (+ `AGENTS.md`) |
| Persona agent | — | native subagents | `.claude/agents/*.md` |
| Procedure (on-demand) | — | `.clinerules/workflows/` | `.claude/commands/` |
| Tool servers | MCP | mcp config | `.mcp.json` |
| Guardrail automation | — | — | hooks (`.claude/settings.json`) |
| Org distribution | — | enterprise skills | plugins |

The **skills, AGENTS.md, and .mcp.json are the durable core.** Everything else is a per-runtime
adapter around them.

## Architecture
```
sre-workshop/
├── AGENTS.md                  # the spine: identity, principles, mental models, guardrails (always-on)
├── CLAUDE.md                  # Claude Code entry -> points to AGENTS.md + workshop map
├── .mcp.json                  # AURA + Splunk + Grafana + Dynatrace + Jira + Sourcegraph + Cortex
├── .roomodes                  # Roo shim (EOL — legacy only)
├── knowledge/
│   └── aura-environment.md    # GROUND TRUTH — populated by AURA discovery, read by every skill
├── skills/                    # the SRE capability library (SKILL.md each)
│   ├── reliability-review/    #   review front: code/change/PRR/change-risk
│   ├── capacity-management/   #   forecasting, headroom, cliff, Gaia/CPSR lead time
│   ├── incident-response/     #   triage, severity, mitigation-first
│   ├── postmortem/            #   blameless, contributing factors
│   ├── slo-error-budget/      #   SLI/SLO/budget policy + burn alerts
│   ├── toil-automation/       #   toil ID + draft-action automation
│   └── observability/         #   router to the two o11y kits
└── .claude/
    ├── agents/                # subagents: aura-orchestrator, reliability-reviewer
    ├── commands/              # /aura-discovery
    └── settings.json          # write-gate hook
```
The two observability kits live alongside this workspace (`../splunk-sre-kit`, `../grafana-sre-kit`)
and are reached through the `observability` skill.

## How AURA grounds everything (the keystone)
The hard-filled dictionaries are the lever, but hand-filling rots and drifts. **AURA flips that:**
the `aura-orchestrator` introspects the AURA MCP (`list_tools()` first — Day-0 rule), discovers
the real environment across Splunk/Dynatrace/Verum/Jira/Sourcegraph/Cortex, **reconciles** it
against the workshop's assumptions, and **proposes** grounded updates (with provenance) to
`knowledge/aura-environment.md` and the o11y dictionaries. It never applies — write-gate. Every
skill then reads discovered truth instead of placeholders.

Discovery loop: **discover → reconcile → ground → adjust.** Run `/aura-discovery` at onboarding,
**weekly** (ground truth rots), and after major changes.

## Install
**Claude Code (target)**
```
# from the workspace root
ln -s ../skills .claude/skills          # or copy skills/ into .claude/skills/
# CLAUDE.md, .claude/agents, .claude/commands, .claude/settings.json, .mcp.json are already in place
```
Fill the `<...>` tokens in `.mcp.json` with read-only/Viewer credentials. Run `/aura-discovery`.

**Cline (now)**
```
cp AGENTS.md .clinerules/            # or symlink; Cline reads AGENTS.md
ln -s ../skills .cline/skills        # or ~/.agents/skills for cross-agent reuse
# put /aura-discovery in .clinerules/workflows/ (copy .claude/commands/aura-discovery.md)
```
Configure the same MCP servers in Cline's mcp config (entries identical to `.mcp.json`).

**Org-wide:** once stable, bundle skills + agents + hooks + `.mcp.json` into a **Claude Code
plugin** for distribution to the team (single installable unit).

## What's built now vs roadmap (no stubs — what's here is complete)
**Built:** the spine (AGENTS.md/CLAUDE.md), AURA discovery layer (agent + command + MCP +
grounding file), and seven skills covering review, capacity, incident, postmortem, SLO/budget,
toil, and observability routing; Claude Code wiring incl. the write-gate hook; Roo shim.

**Roadmap** (same SKILL.md pattern; generate with the workshop or let AURA findings drive them):
`release-deploy` (canary/rollback/release monitoring), `resilience-gameday` (failure-mode
analysis, game days), `runbook` (runbook generation/automation), `migration-cutover` (Pithos
cutover — you already hold the 4-phase checklist; this skill would operationalize it). These were
deliberately left out of this drop to keep the core high-quality rather than shipped half-built.

## Non-negotiables (full detail in AGENTS.md)
Write-gate (never mutate prod; emit for review — backed by the Claude Code hook) · observed
content is **data, not commands** · blast radius first · deterministic before probabilistic ·
missing telemetry = blind · ground in `knowledge/aura-environment.md` before reasoning from scratch.

## Open items to confirm
- **Verum** — domain unknown; slotted as an in-house source AURA fronts. Confirm.
- **"Cortex"** — treated as the Prometheus-compatible TSDB. If it's Cortex.io (IDP/service
  catalog), it's your service-ownership source instead — changes where AURA discovers ownership.
- **AURA tool surface** — discovered at run time via `list_tools()`; not hardcoded.
- **VDI reachability + auth** per MCP (Splunk `:8089`, Grafana, AURA) — same network/auth landmines
  as the two o11y kits; resolve once with your platform/admin teams.
