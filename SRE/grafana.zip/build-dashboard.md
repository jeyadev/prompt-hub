---
description: Design and generate a CDS SRE Grafana 10 dashboard (Classic JSON)
---

# /build-dashboard

Design and generate a Grafana 10 dashboard for the requirement I give you. If I haven't given
specifics, run the intake first.

## Requirements intake (ask only what I haven't answered)
1. **Tier** — Tier 1 (health glance), Tier 2 (per-service RED trends), or Tier 3 (drill/debug +
   log links)? One dashboard = one job; if I ask for all three, propose three dashboards.
2. **Scope** — which CDS services/namespaces? Whole platform or a subset (Pithos cutover =
   cds-find + cds-store)?
3. **Signals** — rate, errors, p50/p95/p99, saturation (USE), error-budget burn, deploy/annotation
   overlay, telemetry-gap?
4. **Time default & refresh** — default window and refresh cadence (warn on aggressive refresh of
   expensive panels).

## Build procedure
1. **Resolve names** from `cds-metrics-dictionary.md`; mark unknowns `<PLACEHOLDER>`.
2. **Inverted-pyramid layout:** `stat` RAG singles on top, `timeseries` trends in the middle,
   `table` / log-link panels at the bottom.
3. **Variables, not duplication:** a `ds` datasource variable + a `service` query variable
   (`label_values(...)`); use panel `repeat` over copy-pasted panels.
4. **Datasource by UID/variable** (`{"type":"prometheus","uid":"$ds"}`), never by name.
5. **`$__rate_interval`** in every rate/increase; histograms aggregated by `le`.
6. **Thresholds = SLOs** from the dictionary in `fieldConfig.defaults.thresholds`. Never invent.
7. **Back heavy panels with recording rules**; keep refresh sane.
8. **Emit Classic JSON** (`schemaVersion: 39`, `timeseries`/`stat` — not `graph`) as a file with a
   stable `uid`. State validation status; note unverified panel options honestly.
9. **Never publish to prod.** Output JSON for review and dashboard-as-code provisioning (file
   provider / GKP ConfigMap → git → CI). Any MCP write is dev/sandbox only.

Full methodology + a canonical Grafana 10 JSON example: Grafana SRE Context rule §3–§5.
