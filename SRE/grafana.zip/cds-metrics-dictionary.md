# CDS Metrics Dictionary (Grafana / Prometheus)

> **The lever.** The mode's output quality is capped by how completely and accurately this is
> filled in. Anything left `<PLACEHOLDER>` surfaces as `<PLACEHOLDER>` in generated PromQL — by
> design, so a guessed metric name never ships to a refreshing prod dashboard. Re-sync into
> `.roo/rules-grafana-sre/` and `.clinerules/` after edits.

---

## 1. Datasources (reference by UID, not name)
| Variable | Datasource UID | Type | Scope |
|---|---|---|---|
| `$ds` | `<fill>` | prometheus | CDS application + infra metrics |
| `<CDS_LOKI_UID>` | `<fill>` | loki | CDS logs (for drill links) |

## 2. Metrics (confirm real names — these are ASSUMED until verified)
| Assumed metric | Real metric name | Type | Key labels | Notes |
|---|---|---|---|---|
| `http_requests_total` | `<fill>` | counter | `service`, `status_code`, `endpoint` | request volume |
| `http_request_duration_seconds_bucket` | `<fill>` | histogram | `service`, `le`, `endpoint` | latency histogram |
| `cds_requests_total` | `<fill>` | counter | `service`, `backend` | backend = mongo/pithos/s3 |
| `cds_errors_total` | `<fill>` | counter | `service`, `error_class` | categorised errors |
| `cds_orphaned_get_total` | `<fill or N/A>` | counter | `service` | store-to-find consistency (if instrumented) |
| `container_cpu_usage_seconds_total` | std | counter | `namespace`, `pod` | GKP |
| `container_memory_working_set_bytes` | std | gauge | `namespace`, `pod` | GKP |
| `up` | std | gauge | `job`, `instance` | scrape health |

## 3. Labels (confirm real names + sensitivity)
| Assumed label | Real label | Cardinality | Sensitive? |
|---|---|---|---|
| `service` | `<fill>` | low (12) | no |
| `status_code` | `<fill>` | low | no |
| `endpoint` | `<fill>` | medium | maybe |
| `backend` | `<fill>` | low | no |
| `error_class` | `<fill>` | low/med | no |
| `<NEVER>` doc_id / correlation_id / account id | — | **unbounded** | **yes — must NOT be a label** |

## 4. Services (12 critical — fill the rest)
| Service | Role | Pithos-migrating? | Tier-1? |
|---|---|---|---|
| cds-find | Document retrieval | yes | yes |
| cds-store | Document write/store | yes | yes |
| `<fill>` | `<fill>` | `<fill>` | `<fill>` |

## 5. SLOs / thresholds (drive ALL dashboard RAG + burn alerts)
| Token | Service | Objective | Window | good = |
|---|---|---|---|---|
| `<SLO>` | cds-find | `<fill, e.g. 0.999>` availability | 30d | status_code !~ "5.." |
| `<LATENCY_OBJECTIVE_S>` | cds-find | p95 < `<fill>` s | 30d | — |
| `<PITHOS_RAMP_TARGET>` | cds-store/find | planned ops/s at current ramp phase | per phase | — |
| `<CDS_NS>` | — | GKP namespace for CDS pods | — | — |
| `<CDS_JOB>` | — | Prometheus `job` label for CDS scrape targets | — | — |

## 6. Recording rules to define (deterministic substrate)
| Recorded series (`level:metric:operation`) | Backs |
|---|---|
| `service:cds_requests:rate5m` | RED rate, burn denominator |
| `service:cds_requests:error_rate5m` | error numerator |
| `service:cds_slo:error_ratio5m` | SLI ratio, burn alerts, dashboards |
| `<add p95 recorded series if histogram is heavy>` | latency panels |

## 7. Environment facts the mode must know
| Question | Answer |
|---|---|
| Grafana version | `<fill — kit targets 10 / Classic schemaVersion 39>` |
| Prometheus scrape interval | `<fill — drives min rate window>` |
| Backend: Prometheus or Mimir/Thanos? | `<fill>` |
| Grafana MCP reachable from VDI? (`:3000` / proxy) | `<UNCONFIRMED — see README landmine 1>` |
| Service-account token provisioned (Viewer)? | `<fill>` |
| Dashboard provisioning: file provider or ConfigMap (GKP)? | `<fill>` |
| Notebook path to Prometheus: Grafana proxy or direct? | `<fill — default proxy>` |
| Sandbox/dev Grafana for validation? | `<fill>` |
