"""
cds_prom.py — shared Prometheus client for CDS SRE notebooks.

Queries Prometheus THROUGH the Grafana datasource proxy using the same read-only Viewer
service-account token as the Grafana MCP, so there is one auth model and Grafana RBAC is
enforced. Falls back to a direct Prometheus base URL only if explicitly configured.

Guardrails (mirrors the Grafana SRE Context):
  - read-only; never writes to Grafana/Prometheus
  - range queries require explicit start/end (no all-time)
  - returns tidy pandas DataFrames; does NOT print raw label values for you — that's the
    notebook author's responsibility (never export identifier-bearing labels)

Env:
  GRAFANA_URL                 e.g. https://grafana.internal.example
  GRAFANA_SA_TOKEN            Viewer service-account token (glsa_...)
  CDS_PROM_DS_UID             Prometheus datasource UID (from cds-metrics-dictionary.md)
  CDS_PROM_DIRECT_URL         (optional) direct Prometheus base URL to bypass the proxy
"""

from __future__ import annotations

import os
import time
from datetime import datetime, timezone

import requests
import pandas as pd


class CDSProm:
    def __init__(self, grafana_url=None, token=None, ds_uid=None, direct_url=None, verify_tls=True, timeout=30):
        self.grafana_url = (grafana_url or os.environ.get("GRAFANA_URL", "")).rstrip("/")
        self.token = token or os.environ.get("GRAFANA_SA_TOKEN", "")
        self.ds_uid = ds_uid or os.environ.get("CDS_PROM_DS_UID", "")
        self.direct_url = (direct_url or os.environ.get("CDS_PROM_DIRECT_URL", "")).rstrip("/")
        self.verify_tls = verify_tls
        self.timeout = timeout
        if not self.direct_url:
            if not (self.grafana_url and self.token and self.ds_uid):
                raise ValueError(
                    "Set GRAFANA_URL, GRAFANA_SA_TOKEN, CDS_PROM_DS_UID (or CDS_PROM_DIRECT_URL)."
                )

    # ---- internal ----
    def _base(self) -> str:
        if self.direct_url:
            return f"{self.direct_url}/api/v1"
        return f"{self.grafana_url}/api/datasources/proxy/uid/{self.ds_uid}/api/v1"

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self.token}"} if self.token and not self.direct_url else {}

    def _get(self, path: str, params: dict) -> dict:
        r = requests.get(self._base() + path, params=params, headers=self._headers(),
                         verify=self.verify_tls, timeout=self.timeout)
        r.raise_for_status()
        payload = r.json()
        if payload.get("status") != "success":
            raise RuntimeError(f"PromQL error: {payload.get('error', payload)}")
        return payload["data"]

    @staticmethod
    def _ts(t) -> float:
        if isinstance(t, (int, float)):
            return float(t)
        if isinstance(t, datetime):
            return t.replace(tzinfo=t.tzinfo or timezone.utc).timestamp()
        raise TypeError("time must be epoch seconds or datetime")

    # ---- public ----
    def query(self, expr: str, at=None) -> pd.DataFrame:
        """Instant query -> DataFrame[labels..., value, timestamp]."""
        params = {"query": expr}
        if at is not None:
            params["time"] = self._ts(at)
        data = self._get("/query", params)
        rows = []
        for s in data.get("result", []):
            ts, val = s["value"]
            rows.append({**s["metric"], "timestamp": pd.to_datetime(float(ts), unit="s", utc=True),
                         "value": float(val)})
        return pd.DataFrame(rows)

    def query_range(self, expr: str, start, end, step="1m") -> pd.DataFrame:
        """Range query -> tidy DataFrame[timestamp, value, labels...]. start/end REQUIRED."""
        if start is None or end is None:
            raise ValueError("query_range requires explicit start and end (no all-time queries).")
        params = {"query": expr, "start": self._ts(start), "end": self._ts(end), "step": step}
        data = self._get("/query_range", params)
        frames = []
        for s in data.get("result", []):
            df = pd.DataFrame(s["values"], columns=["timestamp", "value"])
            df["timestamp"] = pd.to_datetime(df["timestamp"].astype(float), unit="s", utc=True)
            df["value"] = df["value"].astype(float)
            for k, v in s["metric"].items():
                df[k] = v
            frames.append(df)
        return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=["timestamp", "value"])


def client_from_env() -> CDSProm:
    return CDSProm()
