---
description: Build a parameterised SRE Jupyter notebook (Prometheus via Grafana proxy)
---

# /build-notebook

Build a Jupyter SRE analysis notebook for the analysis I name. Notebooks are the offline/periodic
layer for what dashboards do badly. Pick from (or extend) these types:

- **SLO / error-budget report** (monthly) — budget consumed, burn-down, per-service table, governance
  summary export. (Worked example: `notebooks/slo-error-budget-report.ipynb`.)
- **Capacity forecast** — trend + simple forecast of request rate / saturation toward limits.
- **Alert-noise / incident retrospective** — alert firing frequency, top noisy alerts, MTTA/MTTR,
  precision (actionable vs noise) to feed alert tuning.
- **Cutover post-analysis** — Pithos ramp volume, new error classes, consistency over the window.

## Build procedure
1. **Parameterise at the top:** service(s), SLO, window, datasource UID — read from
   `cds-metrics-dictionary.md`. Mark unknowns `<PLACEHOLDER>`.
2. **Use the shared helper** `cds_prom.py` (range/instant query → DataFrame). Do not hand-roll
   HTTP. It queries Prometheus **through the Grafana datasource proxy** with the Viewer
   service-account token (one auth model, RBAC enforced); direct Prometheus only as fallback.
3. **Read recording rules**, not raw expensive expressions, for SLI/burn series.
4. **Read-only.** The notebook queries prod read-only and never writes back to Grafana/Prometheus.
5. **No raw sensitive label values** in cells, outputs, or exports — aggregate or hash.
6. **Emit** a committed `.ipynb` plus, where useful, an HTML/markdown export for governance forums.
7. State validation status; if the proxy/MCP is unreachable, the notebook still generates but is
   labelled `generate-only, NOT run`.

Full methodology: Grafana SRE Context rule §7.
