# Grafana + Prometheus SRE Kit — Roo Code + Cline (CDS / AWM)

The **metrics sibling** of the Splunk SRE kit. Turns Roo Code **or** Cline into a principal-SRE
Grafana/Prometheus engineer for CDS: cost-aware PromQL, recording/alerting rules, **Grafana 10**
dashboards (Classic JSON, `schemaVersion 39`), and Jupyter SRE notebooks — all behind the same
guardrails so an autonomous agent can't OOM shared Prometheus with a cardinality bomb or publish a
dashboard straight to prod.

Three layers: **metrics** (instrumentation + recording/alerting rules) → **dashboards**
(real-time) → **notebooks** (offline/periodic analysis dashboards can't do).

## What's in here
| File | Purpose | Used by |
|---|---|---|
| `grafana-sre-context.md` | **The brain.** PromQL methodology, metric pattern library, recording/alerting rules, Grafana 10 dashboard JSON, notebook methodology, guardrails. | both |
| `cds-metrics-dictionary.md` | **The lever.** Real datasource UIDs, metric/label names, services, SLOs, recording rules. You fill this in. | both |
| `.roomodes` | Roo Code mode shell (`📊 Grafana SRE (CDS)`). | Roo |
| `workflows/generate-promql.md` | `/generate-promql`. | Cline |
| `workflows/build-dashboard.md` | `/build-dashboard` (with intake). | Cline |
| `workflows/build-notebook.md` | `/build-notebook`. | Cline |
| `notebooks/cds_prom.py` | Shared read-only Prometheus client (via Grafana proxy). | notebooks |
| `notebooks/slo-error-budget-report.ipynb` | Worked SLO/error-budget report notebook. | notebooks |

## One brain, two tools — install
Knowledge lives once (`grafana-sre-context.md` + `cds-metrics-dictionary.md`). Place copies where
each tool reads them:

**Roo Code**
```
<repo>/.roomodes
<repo>/.roo/rules-grafana-sre/01-grafana-sre-context.md     # copy of grafana-sre-context.md
<repo>/.roo/rules-grafana-sre/02-cds-metrics-dictionary.md  # copy of cds-metrics-dictionary.md
```
Pick the **📊 Grafana SRE (CDS)** mode in the Roo selector.

**Cline**
```
<repo>/.clinerules/grafana-sre-context.md                   # copy of grafana-sre-context.md
<repo>/.clinerules/cds-metrics-dictionary.md                # copy of cds-metrics-dictionary.md
<repo>/.clinerules/workflows/generate-promql.md
<repo>/.clinerules/workflows/build-dashboard.md
<repo>/.clinerules/workflows/build-notebook.md
```
Run with `/generate-promql`, `/build-dashboard`, `/build-notebook`.

> Keep ONE canonical copy and sync the other (script or pre-commit hook). Two hand-edited copies =
> methodology drift. Or put the brain in `AGENTS.md` at repo root (both tools read it) and keep
> `.roomodes` / workflows as thin shells. **Same pattern as the Splunk kit — both can coexist in
> one repo; the modes/workflows are namespaced (`splunk-*` vs `grafana-*`).**

## Optional: wire the Grafana MCP (generate-only → validated)
Official `mcp-grafana` (Grafana Labs, Grafana 9.0+; RBAC-aware; tools for dashboards, Prometheus,
Loki, alerting, incidents, OnCall, Sift, annotations).
```json
{
  "mcpServers": {
    "grafana": {
      "command": "uvx",
      "args": ["mcp-grafana"],
      "env": {
        "GRAFANA_URL": "https://<GRAFANA_HOST>",
        "GRAFANA_SERVICE_ACCOUNT_TOKEN": "glsa_<VIEWER_TOKEN>"
      }
    }
  }
}
```
Use a **Viewer** service account (read-only). With this wired, the mode validates PromQL/dashboards
against **dev/sandbox** Grafana first. The notebooks reuse the **same token** via the datasource
proxy — one auth model, RBAC enforced.

## Two operating tiers
- **Generate-only** (no MCP/proxy): produces PromQL, rule YAML, dashboard JSON, notebooks; never
  claims it ran. Safe default; works even if Grafana is unreachable from your VDI.
- **Validated** (MCP/proxy reachable, Viewer token): same output + dry-run validation against
  sandbox before prod.

## JPMC landmines — confirm before relying on the validated tier
1. **MCP/proxy reachability from VDI.** The MCP and the notebook proxy talk to Grafana (`:3000` /
   the datasource-proxy route). Whether your Gaia/VDI network permits the agent/notebook host to
   reach it is **unconfirmed** and may be blocked. If blocked → stay generate-only. (Dictionary §7.)
2. **Service-account tokens.** The MCP and notebooks need a **Viewer** SA token. Provisioning that
   under JPMC identity/governance is a Grafana-admin conversation — not assumed solved here.
3. **Dashboards & rules are change-managed.** They reach prod via dashboard-as-code (file provider
   / GKP ConfigMap → git → CI), never via the agent. The kit enforces this; MCP writes are
   dev/sandbox only.
4. **Cardinality = blast radius.** Guardrails (label-scoping, no unbounded-id labels, recording
   rules for heavy/refreshing queries, `$__rate_interval`) exist because a cardinality bomb on
   shared Prometheus/Mimir is an AWM-wide reliability event.
5. **Notebooks read prod.** They query read-only and never write back; still, treat any
   identifier-bearing label as sensitive and never export raw values.

## On "notebooks"
Grafana has no native notebook feature — this kit reads "notebooks" as **Jupyter SRE analysis
notebooks** (SLO reports, capacity forecasting, alert-noise retros, cutover post-analysis) querying
Prometheus through the Grafana proxy. If you meant Grafana Incident timelines or a different
in-product artifact, say so and the `build-notebook` workflow can be repointed.

## Do this first
1. Fill `cds-metrics-dictionary.md` — datasource UID, **real metric/label names**, the 12 services,
   SLO thresholds, recording-rule inventory. Output quality tracks this directly.
2. Decide generate-only vs validated; if validated, resolve landmines 1–2 with your Grafana admin
   and provision a Viewer service account.
3. Drop files into Roo and/or Cline per the install section.
4. Try it: `/generate-promql` → "error-budget burn alert for cds-find", `/build-dashboard` →
   "Tier-1 health overview for the Pithos cutover", then run
   `notebooks/slo-error-budget-report.ipynb` after setting `GRAFANA_URL`, `GRAFANA_SA_TOKEN`,
   `CDS_PROM_DS_UID`.

### Notebook env
```
pip install requests pandas matplotlib
export GRAFANA_URL=https://<GRAFANA_HOST>
export GRAFANA_SA_TOKEN=glsa_<VIEWER_TOKEN>
export CDS_PROM_DS_UID=<prometheus datasource uid>
```
