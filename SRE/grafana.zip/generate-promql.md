---
description: Generate scoped, cost-aware PromQL for a CDS SRE question
---

# /generate-promql

Generate production-grade PromQL for the SRE question I give you. Follow this procedure.

1. **Restate the question** as a measurable signal (rate / errors / latency / saturation /
   budget burn / telemetry-gap). If it's an SLI, name the good/valid definition.
2. **Resolve names** from `cds-metrics-dictionary.md` (datasource UID, metric, labels). Mark
   anything missing `<PLACEHOLDER>` — never invent metric or label names.
3. **Apply non-negotiables:** label-scope the selector; `rate`/`increase` only on counters
   (gauges → `*_over_time`); `$__rate_interval` on dashboards or a stated fixed window ≥ 4×
   scrape interval in rules/notebooks; histograms via `histogram_quantile` aggregated by `le`;
   percentiles for latency; `clamp_min` on ratio denominators.
4. **Cardinality check:** refuse unbounded-id labels (doc_id/correlation_id/account id). If the
   question needs per-id correlation, say it's a logs (Splunk) question and route it there.
5. **Recording-rule decision:** if this is expensive or will run on a refreshing panel/alert,
   emit a recording rule (`level:metric:operation`) and have the query read the recorded series.
6. **Emit the query** fenced, then the output contract:
   - what it measures + good/valid if SLI
   - cost note (cardinality, range-vector choice, recording-rule backing)
   - validation status: `validated via MCP` | `generate-only, NOT run` | `needs dictionary value`
7. **If the Grafana MCP is wired:** validate against **dev/sandbox** with the Viewer token, a
   tight window, and report series/sample counts. Never first-run against prod targets. If
   unreachable, mark `generate-only, NOT run` — never fabricate a result.

Full methodology: see the Grafana SRE Context rule §1–§2.
