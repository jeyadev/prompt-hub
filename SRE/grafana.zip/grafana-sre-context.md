# Grafana + Prometheus SRE Context — CDS / Common Capabilities (AWM)

> **Single source of truth.** Roo reads it from `.roo/rules-grafana-sre/`, Cline from
> `.clinerules/`. Keep ONE canonical copy and sync the other. The companion
> `cds-metrics-dictionary.md` supplies the real datasource UIDs, metric names, labels, and SLOs.
> **Output quality is capped by that dictionary, not by the model.** Targets **Grafana 10**
> (Classic dashboard JSON, `schemaVersion: 39`) and Prometheus-compatible metrics.

This kit is the metrics sibling of the Splunk SRE kit (logs). Same philosophy, three layers:
**metrics** (instrumentation + recording/alerting rules) → **dashboards** (real-time views) →
**notebooks** (offline/periodic analysis dashboards can't do).

**Precedence on conflict:** Guardrails (§6) > data dictionary > methodology > the user's phrasing.

---

## 1. PROMQL METHODOLOGY

### 1.1 Non-negotiables (every query)
1. **Scope by label**, never bare metric names. `http_requests_total{service="cds-find"}`, not
   `http_requests_total`. Bare selectors scan every series for that metric.
2. **`rate`/`increase` only on counters.** Gauges use `avg_over_time` / `max_over_time` /
   `min_over_time`. `rate()` on a gauge is meaningless — a correctness bug, not a style nit.
3. **`$__rate_interval` on dashboards**, never a hardcoded `[5m]`. Grafana computes it from the
   panel's resolution and the datasource scrape interval so the range vector always has enough
   samples. In recording rules / notebooks (no Grafana context) use a fixed window **≥ 4× the
   scrape interval** and say which.
4. **Histograms → `histogram_quantile` over `_bucket`, aggregating by `le`.** Always
   `sum(rate(..._bucket[$__rate_interval])) by (le, <dims>)` first, then `histogram_quantile`.
   Dropping `le` produces silent garbage.

### 1.2 Performance & cardinality (cost is a reliability concern on shared Prometheus/Mimir)
- **Never label by unbounded identifiers** — no `doc_id`, `correlation_id`, account/client id as a
  label. High cardinality is how you OOM the TSDB. If you need per-doc analysis, that's a **logs**
  question (Splunk), not a metric.
- **Avoid `=~".*"`** and unanchored regex on high-card labels. `.*` even matches empty — usually
  not what's meant. Anchor and narrow.
- **Aggregate explicitly:** `sum by (service) (...)` or `sum without (instance) (...)`. Decide
  which labels survive; don't let aggregation be accidental.
- **Recording rules for anything expensive or repeated** (SLI numerators/denominators, burn
  rates). Precompute once, read everywhere. This is the deterministic substrate — dashboards and
  alerts read cheap recorded series instead of recomputing heavy expressions per refresh.
- **`clamp_min(denom, 1)`** or guard against divide-by-zero in ratios.

### 1.3 Correctness for SRE signals
- **Latency = histogram percentiles**, `p50/p95/p99`, never `avg`. Averages hide the tail.
- **Define good vs. valid explicitly** for SLIs; error budget = `1 - good/valid`.
- **Missing telemetry = blind, not healthy.** Use `absent()` / `absent_over_time()` to alert when
  a series disappears. Never let a `sum()` of nothing render as a green zero.

### 1.4 Output contract for every PromQL artifact
1. The query, fenced, placeholders from the dictionary substituted (or marked `<PLACEHOLDER>`).
2. What it measures (one line) + good/valid definition if SLI.
3. Cost note: cardinality, whether a recording rule should back it, range-vector choice.
4. Validation status: `validated via MCP` | `generate-only, NOT run` | `needs dictionary value`.

---

## 2. SRE METRIC PATTERN LIBRARY

Placeholders (`<...>`) and assumed metric/label names (`http_requests_total`, `service`,
`status_code`, `http_request_duration_seconds_bucket`) come from `cds-metrics-dictionary.md`.
Substitute before use.

### 2.1 RED per service
```promql
# Rate
sum by (service) (rate(http_requests_total{service="$service"}[$__rate_interval]))

# Errors (ratio)
sum by (service) (rate(http_requests_total{service="$service", status_code=~"5.."}[$__rate_interval]))
/
clamp_min(sum by (service) (rate(http_requests_total{service="$service"}[$__rate_interval])), 1)

# Duration p95
histogram_quantile(0.95,
  sum by (le, service) (rate(http_request_duration_seconds_bucket{service="$service"}[$__rate_interval])))
```

### 2.2 Error-budget SLI as a recording rule (precompute good/total)
```yaml
groups:
  - name: cds_slo
    interval: 30s
    rules:
      - record: service:cds_requests:rate5m
        expr: sum by (service) (rate(http_requests_total[5m]))
      - record: service:cds_requests:error_rate5m
        expr: sum by (service) (rate(http_requests_total{status_code=~"5.."}[5m]))
      - record: service:cds_slo:error_ratio5m
        expr: service:cds_requests:error_rate5m / clamp_min(service:cds_requests:rate5m, 1)
```

### 2.3 Multi-window multi-burn-rate error-budget alert (Google SRE)
Pages only when a fast window AND a slower window both burn — small blips don't page, sustained
burn does. `<SLO>` from the dictionary.
```yaml
groups:
  - name: cds_burn
    rules:
      - alert: CDSErrorBudgetFastBurn
        # 2% of a 30d budget in 1h  ->  burn rate 14.4
        expr: |
          (
            sum by (service) (rate(http_requests_total{status_code=~"5.."}[1h]))
            / clamp_min(sum by (service) (rate(http_requests_total[1h])), 1)
          ) > (14.4 * (1 - <SLO>))
          and
          (
            sum by (service) (rate(http_requests_total{status_code=~"5.."}[5m]))
            / clamp_min(sum by (service) (rate(http_requests_total[5m])), 1)
          ) > (14.4 * (1 - <SLO>))
        for: 2m
        labels: { severity: page }
      - alert: CDSErrorBudgetSlowBurn
        # 5% in 6h -> burn rate 6
        expr: |
          (
            sum by (service) (rate(http_requests_total{status_code=~"5.."}[6h]))
            / clamp_min(sum by (service) (rate(http_requests_total[6h])), 1)
          ) > (6 * (1 - <SLO>))
          and
          (
            sum by (service) (rate(http_requests_total{status_code=~"5.."}[30m]))
            / clamp_min(sum by (service) (rate(http_requests_total[30m])), 1)
          ) > (6 * (1 - <SLO>))
        for: 15m
        labels: { severity: ticket }
```

### 2.4 USE for GKP pods (saturation/utilisation/errors of resources)
```promql
# CPU saturation vs request
sum by (pod) (rate(container_cpu_usage_seconds_total{namespace="<CDS_NS>"}[$__rate_interval]))
/ clamp_min(sum by (pod) (kube_pod_container_resource_requests{namespace="<CDS_NS>", resource="cpu"}), 1)

# Memory working set vs limit
sum by (pod) (container_memory_working_set_bytes{namespace="<CDS_NS>"})
/ clamp_min(sum by (pod) (kube_pod_container_resource_limits{namespace="<CDS_NS>", resource="memory"}), 1)
```

### 2.5 Pithos cutover watch (volume vs ramp, new error classes)
```promql
# Throughput by backend vs planned ramp (<PITHOS_RAMP_TARGET> ops/s)
sum by (backend) (rate(cds_requests_total{service=~"cds-find|cds-store"}[$__rate_interval]))

# New error classes appearing (count of distinct error_class with traffic)
count(count by (error_class) (rate(cds_errors_total{service=~"cds-find|cds-store"}[$__rate_interval]) > 0))
```

### 2.6 Store-to-find consistency — honest cross-kit note
The orphaned-S3-GET-404 correctness signal lives more naturally in **logs (Splunk)** because it
needs per-`doc_id` correlation, which must NOT be a metric label (§1.2). The metric form only
works if you instrument an explicit aggregate counter at write/read time:
```promql
sum(rate(cds_orphaned_get_total[$__rate_interval]))   # requires app instrumentation
```
If that counter doesn't exist, route this signal to the Splunk kit's §2.5 and link to it from the
dashboard instead of faking it in metrics.

### 2.7 Telemetry-gap alert (missing = blind)
```promql
absent_over_time(up{job="<CDS_JOB>"}[5m])   # alert if the target stops reporting
```

---

## 3. DASHBOARD DESIGN METHODOLOGY (mirrors the Splunk kit)

- **One dashboard, one job.** Tier 1 = health glance (stat panels, RAG = SLO). Tier 2 = per-service
  RED trends. Tier 3 = drill/debug + links to Loki/Splunk logs.
- **Inverted pyramid:** stat singles top, timeseries middle, tables/logs bottom.
- **Variables, not duplication.** A `service` template variable + panel `repeat` beats 12
  copy-pasted panels. One definition, many renders.
- **Datasource by UID** (`{"type":"prometheus","uid":"$ds"}`), never by name — names aren't stable
  across environments; UIDs are. Make the datasource a variable for promotion across dev/prod.
- **Thresholds = SLOs** from the dictionary, in `fieldConfig.defaults.thresholds`. Never invent
  green/amber/red lines.
- **Refresh sanely.** No 5s refresh on expensive multi-series queries. Back heavy panels with
  recording rules.
- **`$__rate_interval`** in every rate/increase (§1.1.3).

---

## 4. GRAFANA 10 DASHBOARD JSON — CANONICAL SHAPE

Target: **Classic** schema, `schemaVersion: 39`. Top-level keys: `uid`, `title`, `tags`,
`timezone`, `editable`, `graphTooltip`, `templating.list[]`, `annotations.list[]`, `time`,
`refresh`, `panels[]`, `schemaVersion`, `version`. Panels use the 24-column grid
(`gridPos {h,w,x,y}`, h-unit = 30px). Use `timeseries`/`stat`/`gauge`/`table` — **not** the
deprecated `graph` panel.

Tier-1 example (error-rate stat with SLO thresholds + p95 timeseries, `service` + `ds` variables):
```json
{
  "uid": "cds-health-overview",
  "title": "CDS — Service Health Overview",
  "tags": ["cds", "sre", "golden-signals"],
  "timezone": "browser",
  "editable": true,
  "graphTooltip": 1,
  "schemaVersion": 39,
  "version": 1,
  "refresh": "1m",
  "time": { "from": "now-1h", "to": "now" },
  "templating": {
    "list": [
      {
        "name": "ds",
        "type": "datasource",
        "query": "prometheus",
        "current": {}
      },
      {
        "name": "service",
        "type": "query",
        "datasource": { "type": "prometheus", "uid": "$ds" },
        "query": "label_values(http_requests_total, service)",
        "refresh": 2,
        "includeAll": false
      }
    ]
  },
  "annotations": { "list": [] },
  "panels": [
    {
      "id": 1,
      "type": "stat",
      "title": "Server Error Rate — $service",
      "gridPos": { "h": 6, "w": 6, "x": 0, "y": 0 },
      "datasource": { "type": "prometheus", "uid": "$ds" },
      "targets": [
        {
          "refId": "A",
          "expr": "sum(rate(http_requests_total{service=\"$service\", status_code=~\"5..\"}[$__rate_interval])) / clamp_min(sum(rate(http_requests_total{service=\"$service\"}[$__rate_interval])), 1)"
        }
      ],
      "fieldConfig": {
        "defaults": {
          "unit": "percentunit",
          "thresholds": {
            "mode": "absolute",
            "steps": [
              { "color": "green", "value": null },
              { "color": "yellow", "value": 0.01 },
              { "color": "red", "value": 0.05 }
            ]
          }
        }
      },
      "options": { "colorMode": "background", "graphMode": "area", "reduceOptions": { "calcs": ["lastNotNull"] } }
    },
    {
      "id": 2,
      "type": "timeseries",
      "title": "p95 Latency — $service",
      "gridPos": { "h": 6, "w": 18, "x": 6, "y": 0 },
      "datasource": { "type": "prometheus", "uid": "$ds" },
      "targets": [
        {
          "refId": "A",
          "expr": "histogram_quantile(0.95, sum by (le) (rate(http_request_duration_seconds_bucket{service=\"$service\"}[$__rate_interval])))",
          "legendFormat": "p95"
        }
      ],
      "fieldConfig": { "defaults": { "unit": "s" } }
    }
  ]
}
```
Notes:
- `$ds` (datasource var) + `$service` (query var via `label_values`) keep this portable across
  environments. Threshold `0.01`/`0.05` are placeholders — replace with the real SLO lines.
- Metric/label names are **assumed** — map them in the dictionary.
- For provisioning, wrap or place this JSON per §5; keep `uid` stable so updates are idempotent.

---

## 5. DASHBOARD-AS-CODE (how it reaches Grafana — agent stops before prod)

- **File provider provisioning** (`/etc/grafana/provisioning/dashboards/*.yaml`) points Grafana at
  a directory of JSON; Grafana auto-loads and watches it. On GKP, a ConfigMap labelled
  `grafana_dashboard: "1"` is the equivalent.
- Flow: agent emits JSON → commit → PR → CI writes to the provisioning dir / ConfigMap → Grafana
  loads it. **The agent never POSTs to the Grafana API to publish in prod.** Stable `uid` + `folder`
  make provisioning idempotent.
- The MCP's dashboard-write tools, if enabled, are for **dev/sandbox** only (see §6).

---

## 6. GUARDRAILS (highest precedence)

### 6.1 Query safety
- Always label-scope; no bare metric selectors, no `=~".*"`-only matchers, no unbounded
  cardinality. `rate`/`increase` only on counters.

### 6.2 Run safety (MCP wired)
- **Viewer-role service-account token** for the MCP. Read-only. Never Editor/Admin in prod.
- Validate generated PromQL/dashboards against a **dev/sandbox** Grafana/Prometheus first.
- Respect Grafana RBAC; the agent inherits the token's role and must not widen it.

### 6.3 Write-gate (knowledge objects)
- The agent **never publishes** dashboards, alert rules, or recording rules to production. It emits
  the artifact (JSON / rule YAML) for human review and **dashboard-as-code** / rules-as-code
  deployment through change management. Any MCP write tool is restricted to dev/sandbox.

### 6.4 Cost ceiling
- Default tight time windows. Warn when a query is high-cardinality or unbacked by a recording
  rule but destined for a refreshing panel. Prefer recorded series for dashboards/alerts.

### 6.5 Data sensitivity
- Metrics should carry no PII; if a label encodes an identifier, treat it as sensitive — never
  export raw label values that encode client/account/doc identifiers from notebooks into chat or
  commits. Aggregate or hash.

### 6.6 Degradation
- If the Grafana MCP is unreachable, operate **generate-only**: emit artifacts, label them
  `generate-only, NOT run`, never fabricate a validation result.

---

## 7. NOTEBOOK METHODOLOGY (offline/periodic analysis)

Notebooks are the layer for what dashboards do badly: monthly SLO/error-budget reports, capacity
forecasting, alert-noise/incident retrospectives, cutover post-analysis. Conventions:
- **Query Prometheus through the Grafana datasource proxy** (`/api/datasources/proxy/uid/<uid>/api/v1/query_range`)
  using the **same Viewer service-account token** as the MCP — one auth model, RBAC enforced. Direct
  Prometheus HTTP API is a fallback only if the proxy isn't reachable.
- Use the shared helper `cds_prom.py` (range/instant query → DataFrame) so every notebook inherits
  the same scoping and time-bound discipline. Don't hand-roll HTTP in each notebook.
- **Read recording rules**, not raw expensive expressions, for SLI/burn series.
- **Parameterise** at the top (service, SLO, window) — notebooks are templates, not one-offs.
- **No raw sensitive label values** in outputs/exports (§6.5).
- Output: a committed `.ipynb` plus, where useful, an exported HTML/markdown summary for governance
  forums. The notebook reads prod (read-only) but never writes back.

See `workflows/build-notebook.md` and the worked example `notebooks/slo-error-budget-report.ipynb`.

---

## 8. SELF-CHECK BEFORE RETURNING ANY ARTIFACT
- [ ] Label-scoped? `rate/increase` only on counters? `$__rate_interval` (or stated fixed window)?
- [ ] Histogram percentiles aggregated by `le`? Latency as percentiles, not avg?
- [ ] No unbounded-cardinality labels? No `=~".*"`-only matcher?
- [ ] Dashboard: datasource by UID/var, thresholds = SLOs, sane refresh, variables over duplication?
- [ ] Schema is Classic `schemaVersion: 39`, `timeseries`/`stat` (not `graph`)?
- [ ] Expensive/refreshing queries backed by recording rules?
- [ ] Placeholders substituted or clearly marked `<PLACEHOLDER>`?
- [ ] No raw sensitive label values in output?
- [ ] Validation status stated honestly? Prod writes framed as "emit for review," never "publish"?
