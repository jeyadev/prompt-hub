# Task NNN — bug: [Short title]

**Type:** bug
**Mode:** the mode whose territory contains the bug (feature-dev for application code, strategist-dev for prompt regressions, etc.)
**Estimated effort:** small (<2h) | medium (2–8h) | large (1–3 days — large bug fixes are usually undiagnosed; consider a spike first)
**Severity:** S1 (production-down) | S2 (significant impact) | S3 (contained) | S4 (cosmetic)
**Claimed by:** [name (YYYY-MM-DD)]
**Reported by:** [name or source — incident ID, user report, eval failure, etc.]
**Depends on:** task NNN if any

---

## The bug

One paragraph. What's wrong. Where it's observed. What the expected behavior is.

Include:
- The shortest reproducer (steps, inputs, environment).
- The actual output / error.
- The expected output / behavior.

## Suspected cause

What you think is wrong, and where. This is a hypothesis; the work confirms or refutes it.

If you don't have a hypothesis yet, **this is a spike, not a task.** Open a spike to diagnose, then a task to fix.

## Acceptance criteria

- [ ] **Regression test exists.** Lives in the relevant `test_*.py`. **Fails on `main`. Passes on the fix branch.** This is non-negotiable per rule 10.
- [ ] The reproducer steps from above no longer reproduce the bug.
- [ ] No new regressions introduced (full local test suite + PR-subset eval if relevant).
- [ ] Root cause documented (not just symptom suppressed).

## Implementation notes

- Resist the temptation to fix more than the bug. A bug fix PR is for the bug. Adjacent improvements go in their own PRs.
- If the bug reveals a broader pattern (this kind of bug could happen elsewhere), open a follow-up task to audit similar code paths. Don't fix all of them in this PR.
- If the fix requires touching an invariant, stop — the bug fix has become an architectural change. Switch to ADR mode.

## Testing requirements

- [ ] **Regression test** — the one that proves the fix works (Layer 1).
- [ ] Other layers as the affected code requires (per rule 10).

## Exit artifacts

- The regression test, in the right `test_*.py`.
- The fix, in the right module.
- (If the bug was a failure mode worth tracking) entry in `docs/failure-modes.md`.
- (If the diagnosis surfaced a non-obvious fact) entry in `.roo/memory.md`.
- PR with the standard sections; describe the root cause clearly in "What changed."

## Post-fix follow-ups

(Optional — adjacent issues spotted during diagnosis that should become their own tasks.)
