# Task NNN — refactor: [Short title]

**Type:** refactor
**Mode:** polish (the polish mode is specifically for behavior-preserving changes)
**Estimated effort:** small (<2h) | medium (2–8h) | large (1–3 days)
**Claimed by:** [name (YYYY-MM-DD)]
**Depends on:** task NNN if any
**Triggered by:** what made this refactor worth doing (a recurring confusion, a hard-to-test seam, a duplication across files)

---

## What changes (and what doesn't)

**What changes:** the structure of the code — names, organization, splits, merges, interfaces.

**What does NOT change:** the behavior. Same inputs produce the same outputs. Same observed performance characteristics. Same external contracts.

Any change in behavior is a feature change, not a refactor, and belongs in a feature task.

## Why now

Refactors are speculative — they pay back over time, not immediately. Justify the spend:

- Recurring confusion: "Every time I touch X, I have to re-derive how it works."
- Hard to test: "The current shape makes Y untestable without mocking five things."
- Duplication: "Z is implemented three times across the codebase; one source of truth would be safer."
- Coming need: "An upcoming feature requires touching this; refactoring first is cheaper."

If you can't name a concrete reason, the refactor isn't worth it yet.

## Scope (in)

- Bullet list of the structural changes.
- Specifically: files moved, modules split, functions renamed, abstractions introduced/removed.

## Scope (out)

- Bullet list of the things that look adjacent but stay untouched.
- New features (any) — refactor PRs don't add features.
- Unrelated cleanup — tempting in a refactor, but stays out of this PR.

## Acceptance criteria

- [ ] **All existing tests pass.** No exceptions. If a test had to change, the change is documented in the PR and justifies why behavior is still preserved (usually because the test was testing internals; the test was wrong, the code was right).
- [ ] **Characterization tests added before the refactor** for any code path that didn't already have tests covering its current behavior. The characterization tests pin down what the code does *today* so the refactor can prove it preserves that.
- [ ] No new functionality. No new public API surface. (Refactors can hide internals; they can't add capabilities.)
- [ ] Performance: no regression worse than 5% on any benchmark we already track. Document the numbers if performance-sensitive.

## Implementation notes

- Work in small, reviewable chunks. A refactor PR with 50 files changed is unreviewable; it ships as a sequence of smaller refactors, each behavior-preserving on its own.
- Lean on the type checker — `mypy --strict` is your friend during refactors.
- Avoid reformatting unrelated files. The diff should show the structural change, not formatting noise.

## Testing requirements

- [ ] **Characterization tests** for any code path the refactor touches that wasn't already tested. Add these *before* the refactor lands.
- [ ] **Full local suite passes** after the refactor.
- [ ] **Integration tests** if the refactor crosses component boundaries.
- [ ] **Eval** if the refactor touches anything in the agent prompt-rendering or context-assembly path. Eval score must be within noise floor (2%) of pre-refactor.

## Exit artifacts

- The refactored code.
- Any new tests (characterization or otherwise).
- (If the refactor changed how an interface works internally) updated docstrings.
- (If the refactor revealed a non-obvious fact about why the old shape existed) entry in `.roo/memory.md`.
- PR description states the behavior-preserving claim and how it was verified.
