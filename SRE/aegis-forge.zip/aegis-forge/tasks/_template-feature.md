# Task NNN — [Short title]

**Type:** feature
**Mode:** feature-dev | strategist-dev | mcp-integrator | code-context (pick the most specific)
**Estimated effort:** small (<2h) | medium (2–8h) | large (1–3 days)
**Claimed by:** [name (YYYY-MM-DD) — added when work starts; see rule 09]
**Depends on:** task NNN, NNN if any
**Blocks:** task NNN, NNN if any
**ADR:** docs/adr/NNNN-*.md if architectural decision is the predecessor

---

## Objective

One paragraph. What is being built and why this exists as a feature now (whose pain, what changes for them when it ships).

## Scope (in)

- Bullet list of what this task does.
- Be concrete — file paths, schema fields, behaviors.
- Include any new dependencies (and the justification — rule 03 requires this).

## Scope (out)

- Bullet list of what this task does NOT do.
- Explicitly call out the adjacent work that might tempt scope creep.
- Reference any follow-up task IDs where the out-of-scope work will happen.

## Acceptance criteria

- [ ] Specific, checkable item.
- [ ] Each one is independently verifiable.
- [ ] Touches all three: behavior, tests, docs.
- [ ] Includes any eval thresholds if agent-behavior-touching.

## Implementation notes

Free-form. Include:
- Architectural pointers — where the code lives, which existing modules it integrates with.
- References to relevant invariants (rule 02). If an invariant could be affected, restate compliance plan.
- Known gotchas, vendor quirks, prior-art references in `.roo/memory.md`.

## Testing requirements

Per rule 10. State which layers apply:

- [ ] **Layer 1 — Unit tests.** What functions, what cases (happy + the two most likely failure modes).
- [ ] **Layer 2 — Integration tests.** What components are crossed; what containerized dependencies.
- [ ] **Layer 3 — Eval tests.** If agent-touching: which agent, what new golden cases (if any), what threshold.
- [ ] **Layer 4 — Manual tests.** If UI or first-time end-to-end: what to verify, in what environment.

Coverage requirement: 80% on touched packages by default; 100% if touching the audit-write path.

## Exit artifacts

- Code in `<package>/`.
- Tests in `<package>/test_*.py`.
- Migration in `<migrations-path>/NNNN_*.py` if schema change.
- Eval cases in `evals/golden/<agent>/*.yaml` if agent-touching.
- New entry in `docs/failure-modes.md` if the feature adds reach.
- New entry in `.roo/memory.md` if a non-obvious fact surfaced.
- Update to `STATE.md` if load-bearing vs scaffolding shifted.
- PR with the standard description sections (per Development Guide stage 6).

## Notes & open questions

(Optional — anything the human wants surfaced for the agent before work starts.)
