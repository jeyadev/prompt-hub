# Tasks

The unit of committed work. Each task is one branch, one PR, one human owner. Each task survives a feature-protocol stress-test before it exists (see `.roo/rules/08-feature-protocol.md`).

## Templates

Four templates live in this directory:

- `_template-feature.md` — copy for new features or capabilities.
- `_template-spike.md` — copy for time-boxed research.
- `_template-bug.md` — copy for bug fixes.
- `_template-refactor.md` — copy for behavior-preserving improvements.

To create a task: copy the right template to `tasks/NNN-<short-title>.md` where NNN is the next available number in the right range. Fill in. Commit. Now the task exists.

## Numbering convention

- `001–099` — major workstreams in the current focus area (whatever you're working on).
- `100–199` — secondary workstreams.
- `200–299` — tertiary.
- `500–599` — cross-cutting / infra.
- `900–999` — spikes and research.

These ranges are loose — the point is to keep related tasks grouped numerically, not to follow a strict taxonomy. If you outgrow the ranges, renumber. The task numbers are not stable identifiers; the file paths are.

## Lifecycle

```
   _template-*.md         ← copy
        ↓
   NNN-title.md (created)
        ↓
   Claimed by: <name>     ← edit when work starts
        ↓
   PR opened, cross-reviewed
        ↓
   Completed by: <name>   ← on merge, claim becomes completion
        ↓
   (file stays in repo as a record)
```

## Claim semantics (rule 09)

Every task has a header field `Claimed by:`. The first human to start the work fills it with their name and the date. **Commit this small change before starting the actual work** — that way other collaborators can see the task is in flight.

When the task ships (PR merged):

- `Claimed by:` becomes `Completed by:` with the merge date.
- The task file stays in the repo as a permanent record. We don't delete completed tasks; they document what shipped and when.

If a task is abandoned (claim was wrong, dependencies shifted, scope changed):

- The claimer adds an `Abandoned by:` line with the date and reason.
- Removes the `Claimed by:` field so the task is open again.

## The task is the contract

The task file is the contract between the human who claimed it and everyone else. It says:

- **What's being built** (objective + scope-in).
- **What's not being built** (scope-out — explicit and important).
- **What "done" looks like** (acceptance criteria).
- **What tests are required** (testing requirements).
- **What changes when it lands** (exit artifacts).

When the agent restates scope before writing code (rule 06), it's restating the contract. When the reviewer reviews the PR (rule 09), they're checking against the contract. When you later wonder what a task was, the file tells you.

## When a task is wrong

Sometimes you start work and realize the task as written is wrong — wrong scope, wrong approach, missing dependencies. **Stop. Don't execute a different task than the one written.**

Two options:

- **Small correction.** Edit the task file with the correction. Note the change in the file. Continue.
- **Big correction.** The task as written is fundamentally wrong. Abandon it, write a new task, claim the new one. The original stays in the repo as a record of what we thought we'd do.

Either way, the file stays truthful about what was done.

## When NOT to create a task

- Typos, dependency bumps, formatting-only changes — just PR them. The "task" overhead exceeds the work.
- Reverts — revert immediately; document the decision in the PR.
- Hot fixes for production incidents — fix first; write up retroactively.

For everything else: task first, code after.

## How to start a task in Cline

1. **Open the task file.** Read every section.
2. **Check `Claimed by:`.** If empty, claim it (commit the small edit).
3. **Set the Roo mode** named in the task header.
4. **Start the session.** Standing prompt:
   > *"Execute task NNN. Read `.roo/rules/`, `STATE.md`, and `.roo/memory.md` first. Confirm scope before writing code — restate what you're going to do, what you're explicitly not doing, and any assumptions."*
5. **Confirm the restatement.** Push back if it's wrong.
6. **Drive the work.** Reject diffs that exceed scope; ask for the smallest version if the agent over-builds.
7. **Verify** acceptance criteria, run the pre-merge ritual (rule 10).
8. **Open the PR.** Cross-review per rule 09.
9. **On merge:** `Claimed by:` → `Completed by:` with the date. `/newtask` before starting the next.

## What "done" looks like

A task is done when:

- Every box in the Acceptance Criteria is checked.
- Tests at the required layers pass.
- Code review (self + cross) is complete.
- Failure-mode and memory updates landed if relevant.
- STATE.md updated if structural.
- The PR description references the task and explains what shipped.
- The merge happened.

If any of these is missing, the task is not done. The agent should not ask the human to merge an incomplete task.
