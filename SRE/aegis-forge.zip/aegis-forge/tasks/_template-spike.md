# Task 9NN — [Short title]

**Type:** spike
**Mode:** architect-aegis (most spikes are research; output is a doc)
**Estimated effort:** small (<4h) | medium (4–8h) | large (1–2 days max)
**Time-box:** [hard deadline — when do we stop and write up?]
**Claimed by:** [name (YYYY-MM-DD)]
**Depends on:** task NNN if any
**Spawned from:** ideas/INBOX.md entry of YYYY-MM-DD (link the trigger)

---

## The question

One sentence. What are we trying to find out? A spike answers a question.

Good question: "Can pgvector's `ivfflat` index handle our retrieval latency requirements at 100k chunks?"
Bad question: "Should we use pgvector?" (too vague — break into specifics)
Bad question: "How does pgvector work?" (this is reading docs, not a spike)

## Why this is a spike, not a task

What's uncertain that makes this not yet a real task. Usually one of:

- Performance characteristics unknown.
- Vendor API behavior unverified.
- Architectural trade-off needs prototyping to inform.
- Library compatibility with the existing stack unclear.

If you can name a concrete acceptance criterion already, this is a task, not a spike.

## Approach

How will we answer the question? Bullet list:

- The smallest representative experiment.
- The data or environment needed.
- The measurements to take.
- The threshold for "answered" vs "more investigation needed."

## Time-box

A spike is bounded. Default 1 day, never more than 3. **When the time-box is hit, the spike ends regardless of completeness.** The write-up captures what was learned and what's still unknown.

## Exit artifacts

- `docs/spikes/9NN-<title>.md` — the write-up. Must include:
  - The question, restated.
  - The approach taken.
  - The findings, with data/numbers/code references.
  - The recommendation: proceed to a real task, abandon, defer, or do another spike.
  - The follow-up task IDs created (if any).
- Any prototype code goes in `scripts/spike-9NN/` or a throwaway branch (NOT in production code paths).
- If the spike spawned new failure modes worth tracking, entries in `docs/failure-modes.md`.

## Notes & open questions

(Optional.)
