# AEGIS — Current State

This document captures where AEGIS is *right now*, as inherited from the MVP demo. The agent reads this to understand the starting point before reading the roadmap (which is the destination).

Update this document at the end of every phase. Each section has a "last updated" date so we know when the snapshot was taken.

---

## At a glance

**Last updated:** YYYY-MM-DD (fill in when seeding from your repo)
**Mode:** feature-by-feature development under `aegis-forge` (no fixed roadmap)
**Status:** demo-complete; production-grade work proceeds opportunistically.

---

## What the demo proved

- The Strategist → Dynamic Runbook → Sub-Agent pattern works for real incidents on a controlled subset of services.
- MCP-based tool integration is viable as the only path to external systems.
- The three fix modes (`suggest_only`, `approval_required`, `auto`) are enforceable at the executor.
- Streaming agent reasoning to a React console produces a usable operator experience.
- Cost per resolved incident is bounded enough to justify Phase 1 investment.

(Add demo-specific outcomes here when seeding — e.g. "demoed against simulated Splunk and Dynatrace; resolved 7 of 10 fixture incidents in approval-mode without operator intervention beyond approval.")

---

## What's load-bearing today

These are the things that *work* and shouldn't be casually refactored without a task and a reason.

- **Strategist prompt structure** in `agents/strategist/prompt.py` — iterated against demo cases. Treat as baseline; eval-harness regressions block changes.
- **Orchestrator state machine** in `orchestrator/lifecycle.py` — implements the receive → enrich → strategise → execute → verify lifecycle.
- **MCP base client** in `mcp/base/client.py` — retry, circuit-breaker, timeout, basic audit hooks. This is the seam every adapter sits on.
- **Three Sub-Agents** in `agents/sub_agents/` — Remediator, Communicator, Verifier. Their contracts with the orchestrator are stable.
- **React console** in the `aegis-console` repo — separate codebase; this workspace does not contain it.

---

## What's scaffolding (built to be replaced)

These exist because the MVP needed them; they're explicitly not production-ready. Each is a candidate for a future feature task — capture in `ideas/INBOX.md` when prioritized, stress-test, claim, ship.

- **SQLite persistence** — will move to Postgres + pgvector when a feature requires it.
- **`.env`-based secrets loading** — replaced by Vault when identity work happens.
- **Audit log in operational DB** — should separate to its own append-only store before production rollout.
- **No formal eval harness** — needed before agent prompt changes can be defended at scale.
- **Manual observability (print/log)** — replaced by OTel when self-observability is needed.
- **Hand-crafted MCP mocks for Splunk/Dynatrace** — replaced by vendor MCP servers or our own production-grade implementations.
- **Single-instance deployment** — move to HA before any service depends on AEGIS for availability.
- **Hard-coded service catalogue** — replaced by `aegis.yaml`-driven onboarding when self-serve becomes a need.

---

## Decisions made (don't relitigate without an ADR)

These are decisions that have been made, considered, and worked. Re-opening one requires an ADR under `docs/adr/`.

- **Python 3.12, FastAPI, async-first.** Considered alternatives: Go (rejected on team skillset), TypeScript (rejected on ecosystem fit for ML/agent work).
- **Postgres + pgvector** as the operational + vector store. Considered: dedicated vector DB (Pinecone, Weaviate) — rejected on operational simplicity. One DB engine is easier to run than two.
- **Anthropic Claude as the model provider.** Considered: multi-vendor (OpenAI, Bedrock). Rejected for MVP — too much complexity for an unclear benefit. Re-evaluate at Phase 4.
- **MCP-only for tool integration.** Considered: direct SDK calls. Rejected — see invariant 1 rationale.
- **Three fix modes, not a continuum.** Considered: confidence-as-mode (smooth gradient). Rejected — discrete modes are auditable and humans can reason about them.
- **React for the console.** Considered: server-rendered (Phoenix, HTMX). Rejected on the streaming UX need.

---

## Known technical debt

Things we know are wrong and need to fix. Each is either a task or a candidate task.

- (Seed from your demo's known issues.)
- Example: "Strategist prompt is currently hard-coded; should be loaded from a versioned prompt store." → potential task.
- Example: "Sub-Agent error handling collapses MCPTransportError and MCPProtocolError into a generic exception; loses retry-vs-fail-fast discrimination." → potential task.

---

## What's out there but not yet integrated

External assets that exist but aren't wired into AEGIS proper yet.

- (Seed from your repo. Examples: a Confluence runbook corpus that hasn't been ingested; a historical incident dataset that hasn't been vectorised; a Jira ticket archive available for fine-tuning context.)

---

## The team

- **Jey Ganesh** — owner, architect, primary developer.
- **Aayushi [last name]** — collaborating developer (onboarding YYYY-MM-DD).
- **(Future)** — additional collaborators as Phase 2 expands.

---

## How to update this file

- At the end of every task in `tasks/`, check whether STATE has changed. If the task replaced scaffolding with production code, move the entry. If the task added a load-bearing component, add it.
- At the end of every phase, do a full rewrite. The state at end-of-Phase-1 looks very different from end-of-Phase-0.
- Don't edit "decisions made" without an ADR. Decisions are facts; you can supersede them, you cannot rewrite history.
