# Bootstrapping from an Existing Codebase

Your AEGIS MVP exists. The workspace exists. This is the playbook for fusing them.

## The mental model

The workspace is **contract + scaffolding**. Your demo code is **the substance**. We are not replacing the demo; we are giving it a contract to develop under.

Three things have to be true at the end of bootstrap:

1. The code lives in the workspace's directory structure.
2. The agent understands what's already true (`STATE.md`) and what should be true (the rules).
3. The gap between (1) and (2) has been catalogued and turned into prioritised tasks.

Bootstrap is a one-time operation. After it, every subsequent task starts from a known baseline.

## The four-step bootstrap

### Step 1 — Overlay

Copy your existing AEGIS repo's contents over the workspace, at the same root.

```bash
# Assuming the workspace zip is unpacked at ./aegis-cline/
# and your existing demo code is at ../aegis-demo/

cd aegis-cline
rsync -av --exclude='.git' ../aegis-demo/ ./

# This places your existing app/, orchestrator/, agents/, mcp/, etc. alongside
# the workspace's .roo/, .roomodes, .clineignore, tasks/, docs/, ideas/.
```

Resolve overlaps manually:

- **`.gitignore`** — merge yours with the workspace's. Your existing patterns + the workspace's secret/cache patterns.
- **`pyproject.toml`** — keep your existing version, but add the dependencies the workspace's `pyproject.toml` lists that you don't have yet.
- **`README.md`** — keep one. Probably the workspace's, since it explains the rule structure.

### Step 2 — Seed `STATE.md`

`STATE.md` is the single most important file for continuity. The agent reads this to understand "where we are." Open it; fill in the placeholders with your real state:

- What the demo proved (specific outcomes, not generalities).
- What's load-bearing (working code you don't want refactored casually).
- What's scaffolding (deliberate shortcuts taken for the demo).
- Decisions you've made and don't want to relitigate.
- Known technical debt.

A useful prompt to draft this:

> *"Read every Python file in this workspace. Produce a draft `STATE.md` filling in the sections under their placeholder headers. Be specific — cite files and functions, not generalities."*

You read the draft, correct it, commit.

### Step 3 — Run Task 000

Switch Roo Code to `architect-aegis` mode. Open `tasks/000-codebase-audit.md`. Prompt:

> *"Execute task 000. Read `.roo/rules/` and `STATE.md` first. Audit the existing code against every rule and every invariant. Produce the gap-analysis document. Confirm the audit scope before starting."*

The agent confirms scope, you approve, the agent works. Output is `docs/audit-2026-NN-NN.md` with:

- Per-rule findings.
- Per-invariant compliance verdict.
- Proposed new tasks for the gaps.

You **read the audit carefully**. The agent will get some things wrong (false positives where the code is fine, false negatives where the code is broken in ways static reading doesn't catch). Mark up corrections directly in the doc.

### Step 4 — Insert the gap-closing tasks

Take the proposed-tasks list from the audit. For each, decide:

- **Already covered** by an existing task (001–013)? Note the linkage in the audit; move on.
- **New task?** Create it under `tasks/`, using the next available number. Use the existing tasks as templates.
- **Spike first?** If the gap is unclear, create a spike task in the 9NN range instead of a full task.

Add the new tasks to `ROADMAP.md` under the right phase.

## After bootstrap

The workspace is now coherent with the codebase. From here, the protocol from `06-task-discipline.md` and `08-feature-protocol.md` take over. Every change goes through the normal flow.

The agent now starts every session with:
1. `.roo/rules/` (auto-loaded).
2. `STATE.md` (recommended preamble — agent reads if relevant).
3. `.roo/memory.md` (tacit knowledge from prior sessions).
4. The specific task file (loaded when you reference it).

That's the continuity. The agent never starts from zero again.

## Refreshing STATE.md

`STATE.md` is not static. Update it:

- **End of each task** — if load-bearing or scaffolding lists changed, update. Most tasks don't change STATE; the structural ones do.
- **End of each phase** — full rewrite. Phase 1 STATE looks very different from Phase 0.
- **When a decision is made** — add to the "decisions made" section, with a pointer to the ADR.

A stale STATE.md is worse than no STATE.md. The agent will believe it. Don't let it lie.

## When the audit finds something scary

Common: invariant 3 (immutable audit log) is *partial* — the demo writes audit entries but to the operational DB, not to a separate store. **Not a panic.** This is exactly what task 003 fixes. The audit confirms task 003 is real and necessary.

Less common: an invariant is *violated* in a load-bearing way. Example: the demo's MCP base client has a bug where idempotency keys aren't propagated through retries. This *would* be a violation of invariant 4 — but the demo depends on the current behaviour for a specific flow.

In this case, the audit flags it as **load-bearing violation**. The fix becomes a higher-priority task (insert before 001 if necessary), and the team accepts the carve-out as documented, time-bounded technical debt — not silent acceptance.

Document load-bearing violations in `docs/failure-modes.md` as well, so they aren't lost.
