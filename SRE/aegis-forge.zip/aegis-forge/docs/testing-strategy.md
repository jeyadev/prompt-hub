# Testing Strategy

The human-facing rationale for how we test. Rule 10 (`.roo/rules/10-testing-discipline.md`) is the operating contract; this is the why.

## The premise

Production agentic systems fail in ways traditional systems don't. A retry-loop bug is the same in any codebase; an agent that confidently produces the wrong runbook is a new category. Testing has to cover both.

The four-layer strategy below handles both. Each layer catches a class of failure that the others don't:

| Layer | Catches | Misses |
|---|---|---|
| Unit | Logic errors, type confusion, schema bugs | Cross-component issues, model drift |
| Integration | Plumbing errors, dependency bugs, ordering issues | Subtle model output regressions |
| Eval | Model output regressions, prompt drift | Implementation bugs the prompt doesn't see |
| Manual | UX failures, real-world surprises, integration gaps | Anything you didn't think to try |

No single layer is sufficient. All four are required.

## Where testing pays the most

Hours invested in testing don't return equally across the codebase. The places where testing pays back fastest:

### Agent boundaries (highest ROI)

The contracts between agents are where bugs travel between subsystems. The Strategist → orchestrator handoff, the orchestrator → Sub-Agent dispatch, the MCP base client → adapter boundary. Bugs at these seams are the hardest to debug after the fact because the cause is in one component and the symptom in another.

Test these boundaries with **both** layer 1 (the contract shape) and layer 3 (the contract under realistic prompts).

### MCP adapters

The vendor systems behind MCP servers drift. Quietly. Without warning. The Splunk API your adapter targets today is not exactly the Splunk API of next quarter. The defense is:

- **Recorded fixtures.** Capture real responses once, replay forever.
- **Schema validation in tests.** If Splunk starts returning a new field, the test should fail with a clear message, not silently pass.
- **Periodic integration runs.** Nightly hits against the real vendor (in a test environment) — the only thing that catches drift.

This is high-ROI because adapter bugs hit production agents and degrade their context silently.

### The audit-write path

100% coverage requirement. The audit log is a compliance contract; any code path that writes audit must be tested for: success, idempotency, failure-aborts-the-action, hash-chain-integrity. There's no acceptable test gap here.

### Confidence-gate logic

The code that decides whether an auto-mode action runs is a few dozen lines of branching logic that determines whether AEGIS does anything dangerous. Every branch needs coverage. Every threshold needs a test that fires just-above and just-below.

This is the smallest amount of code with the largest blast radius. Test it like it matters, because it does.

### What pays less

- Trivial CRUD endpoints — test the happy path, move on.
- Pure data classes (Pydantic models without behavior) — schema validation already tests them.
- Glue code that exists to satisfy an interface — usually transitively tested through callers.

## The eval layer in depth

Evals are not optional. They are how we know an agent change is good.

### What evals catch

- A prompt change that improves one case class at the cost of another.
- A model upgrade that changes confidence calibration silently.
- A context-assembly change that drops a critical signal.
- A schema change that the prompt didn't fully adapt to.

### What evals do not catch

- Real-world novelty — the set is a sample.
- Implementation bugs that don't affect the agent's output shape.
- Adversarial inputs not represented in the set (handled by a separate injection-detection suite).

### The golden set discipline

The set is **curated, not collected**. Specifically:

- ≥30 cases minimum for a new agent under eval; cap at ~150 for v1.
- Real provenance for ≥80% of cases (anonymized real incidents).
- Class-balanced across cause types.
- Reviewed quarterly for staleness; retired cases marked, not deleted.
- New cases added weekly from real resolved incidents.

A bloated golden set with low-signal cases is worse than a tight one with high-signal cases. The judge LLM noise floor is around 5%; a set of low-signal cases gets dominated by noise.

### The judge LLM

A separate Sonnet-class agent with a senior-SRE persona scores qualitative properties: hypothesis plausibility, runbook actionability, "would I act on this." The judge is **versioned** — every invocation records the judge prompt hash. When the judge prompt changes, the new baseline is set against itself, and recent runs are re-scored for comparability.

The judge is calibrated, not trusted. A 5% random sample of judge verdicts is reviewed by a human each release. If judge-vs-human agreement drops below 80%, the judge prompt is revisited.

See `docs/eval-design.md` for the full methodology.

## Testing the testing

The most insidious failure is when tests pass but the system is broken. Defenses:

### Mutation testing (aspirational)

Run mutation testing periodically (not in CI; on demand). If `mutmut` can mutate a line and no test fails, that line is undertested. Use the report to identify weak coverage areas; don't chase 100% mutation score.

### Fixture quality reviews

Once per quarter, review the test fixtures for realism. Fake data that's too clean misses real-world bugs (e.g., timestamps that always parse cleanly when production has timezone drift).

### Production sampling

A periodic comparison: take a sample of production incidents from the past week. Run them through the current agent on a staging environment. Compare to what actually happened. Differences are either: a bug in the test set (we missed a case class), a bug in the agent (drift), or a real change in the world (the production environment changed). All three are diagnostic.

## The pre-merge ritual

Before pushing:

```bash
# Quick local checks (< 30 seconds)
ruff check .
black --check .

# Type check (< 30 seconds on touched packages)
mypy --strict app orchestrator agents mcp

# Unit tests (< 2 minutes)
pytest -m "not integration"

# Eval subset (if agent-touching, < 5 minutes)
python -m evals.runner --agent strategist --set golden-pr-subset
```

Push only when all are green. CI runs the same plus integration tests and full eval; failures there are mostly environment issues, not code issues, if local was green.

## When testing surfaces a deeper problem

Testing pain is diagnostic, not punitive. Common patterns:

- **Test requires mocking five things** → the function does too much; split it.
- **Test asserts a string match against generated text** → the prompt should return structured data, not free text.
- **Test is non-deterministic** → either set seeds explicitly, or the test is asking the wrong question.
- **Test passes locally, fails in CI** → fixture timing, locale, or filesystem assumptions. Fix the test; don't disable it.
- **Test is slow (>1s)** → mark `@pytest.mark.slow` and move to nightly, or refactor the code under test.

Listen to your tests. They tell you what's wrong before users do.

## Cultural notes

- **Tests are a deliverable, not a tax.** A PR without tests is incomplete, not "tests pending."
- **Untested code is technical debt.** It's debt that compounds.
- **Test names are documentation.** `test_strategist_returns_low_confidence_when_context_missing` beats `test_case_5`.
- **Failing tests are not noise.** If you're tempted to mark `@pytest.mark.skip`, the test is telling you something. Listen.
- **A test that's hard to write means code that's hard to use.** Refactor first; the test gets easier.
