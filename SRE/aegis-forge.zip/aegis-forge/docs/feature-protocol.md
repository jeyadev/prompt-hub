# Feature & Idea Protocol — Human Guide

This is the human-facing version of the feature protocol. The agent-facing version (which the agent enforces automatically) lives in `.roo/rules/08-feature-protocol.md`. Read both.

## Why this exists

AEGIS is a long-running project that will be modified by an agent at high velocity. Without a protocol, two things go wrong:

1. **Idea sprawl.** Every conversation generates ideas. Most are forgotten. The good ones are forgotten with the bad. Eventually you remember none of them.
2. **Feature creep.** The agent is enthusiastic and willing. If you don't gate ideas before they become tasks, you end up with a codebase that solves problems you don't have.

The protocol exists to make ideas *visible* and to make commitment *deliberate*.

## The bird's-eye view

```
            ┌──────────────┐
            │  Random      │
            │  thought     │
            └──────┬───────┘
                   │
                   ▼
            ┌──────────────┐
            │ INBOX.md     │  ← Stage 1: capture, no quality bar
            └──────┬───────┘
                   │
                   ▼
            ┌──────────────┐
            │ Stress-test  │  ← Stage 2: architect mode, 6 questions
            └──────┬───────┘
                   │
        ┌──────────┼──────────┬─────────┬──────────┐
        ▼          ▼          ▼         ▼          ▼
    ┌────────┐ ┌────────┐ ┌─────┐ ┌──────┐  ┌─────────┐
    │ reject │ │ defer  │ │spike│ │ ADR  │  │ task    │
    └────────┘ └────────┘ └─────┘ └──────┘  └─────────┘
       │          │          │        │           │
       ▼          ▼          ▼        ▼           ▼
    rejected   deferred   tasks/9  docs/adr   tasks/NNN
      .md        .md       NN.md    NNNN.md     .md
```

## Stage-by-stage

### Stage 1 — Capture (5 min)

Whenever, wherever. `ideas/INBOX.md`. Append a dated entry, one paragraph, name the trigger. No design work, no scoping. The point is not losing the thought.

If you're in a Cline session and an idea surfaces that's adjacent to the current task — *don't follow it*. Append to INBOX, return to the current task. Tangents are how scope creep happens.

### Stage 2 — Stress-test (15–30 min)

Open a fresh Cline session in `architect-aegis` mode. Paste the idea from INBOX. Use the standing prompt:

> *"Stress-test this idea against AEGIS rules and roadmap. Run all six questions from rule 08. Be ruthless. Tell me whether it dies, gets sharper, or gets committed — and to what artifact."*

The architect mode can only write `.md`/`.txt` — so there's no risk of an enthusiastic scaffolding spree. Output is a structured assessment.

You read the assessment critically. The agent has no skin in the game; you do. If the agent waved away a real concern, push back. If the agent killed something you still believe in, ask for the specific question that failed and whether it can be answered differently.

### Stage 3 — Classify

Six possible outcomes:

| Outcome | Goes to | Use when |
|---|---|---|
| Reject | `ideas/rejected.md` | Violates an invariant with no fix; solves a non-problem; permanently better done outside AEGIS. |
| Defer | `ideas/deferred.md` | Belongs to a later phase; or depends on a decision/event that hasn't happened. Include the activation condition. |
| Spike | `tasks/9NN-spike-*.md` | Too uncertain to scope. Time-boxed research (default 1 day). Output is a doc, not code. |
| ADR | `docs/adr/NNNN-*.md` | Architectural decision required before tasks make sense. The decision is the artifact. Tasks follow. |
| Task | `tasks/NNN-*.md` | Scoped, dependencies clear, fits the roadmap. Ready to execute. |
| Rule change | Update `.roo/rules/` | Affects the operating contract. Rare. PR-announced. |

A useful test: an ADR answers "*which* should we do?", a spike answers "*could* we do this?", a task answers "*how* do we ship this?" If you're conflating two of those, you have two artifacts.

### Stage 4 — Commit

Have the agent generate the artifact. Drop a one-liner back in `ideas/INBOX.md` pointing to it ("→ task 014" or "→ ADR 0003"). If the new artifact adds a workstream that's not already in `ROADMAP.md`, update the roadmap in the same change.

### Stage 5 — Cadence (30 min weekly)

Without this, the system rots. Three sweeps:

- **INBOX older than 7 days** — anything not yet stress-tested either gets stress-tested or rejected. No idea camps unexamined.
- **Deferred older than 90 days** — revive (move to active) or kill (move to rejected with rationale). The world has moved.
- **Tasks blocked > 2 weeks** — unblock, kill, or rescope. Open-but-not-moving is the worst state.

A natural time: Sunday evening, 30 minutes. Make it a recurring calendar event. The agent can prep the review by listing every entry across the three files.

## The six stress-test questions, in full

These are the heart of the protocol. They are written to be *answerable*, not to be inspirational.

### 1. Invariant check

Does this idea require violating one of the 10 invariants in rule 02?

If yes: kill the idea, or amend the invariant in writing first (via ADR). Both cannot happen in the same change. Most ideas that look like they want to bend an invariant are wrong; sometimes the invariant is wrong. Decide explicitly.

### 2. Problem check

Whose specific pain does this solve? Name the user.

If the answer is hypothetical ("we might want…", "users could…"), reject or defer. AEGIS only adds reach when a real user has a real problem. Hypothetical problems waste time on features no one asked for.

### 3. Dependency check

Does this depend on infrastructure that's not yet built?

If yes, defer with an **activation condition** — the specific state that would unblock it. Don't try to build the dependent feature before the foundation. The condition is a state ("when the eval harness exists," "when Postgres replaces SQLite"), not a date.

### 4. Smallest version

What's the cheapest version that would prove the idea is real?

If you can't name a < 1-week version, the idea isn't ready. The full version of an idea is almost never the right thing to build first. Find the version that's cheap to throw away.

### 5. Failure mode

What's the worst thing this does when it's broken?

If existing gates contain the failure: good, proceed. If not: what new gate must ship in the same change? An idea without a failure-mode story doesn't merge.

### 6. Carrying cost

What does it cost to *maintain*, not build?

Every feature is a tax forever. Some features are cheap to carry; some are quietly expensive. Be honest. If the carrying cost outweighs the benefit, defer or reject.

## When to break the protocol

The protocol serves the work, not the other way around. Skip it when:

- The change is mechanical (typo, dependency bump, formatting).
- The "idea" is just clarifying a task already in flight.
- A production incident demands an immediate fix — fix first, then ADR the decision retroactively.

When you skip, do it deliberately. "I'm skipping the protocol because X" is a perfectly acceptable thing to write in a PR description; "I forgot the protocol existed" is not.

## When the protocol is wrong

Revisit it. Rule 08 is versioned. The protocol that worked at five tasks may not work at fifty. The questions that mattered in Phase 1 may not matter in Phase 4. Re-tune deliberately, not by attrition.
