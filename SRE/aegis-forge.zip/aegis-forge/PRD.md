# AEGIS — Product Requirements

## Problem

In a Tier-1 bank, the cost of an SRE incident is not the engineering time — it is the customer impact, the regulatory exposure, and the toll on the on-call rotation. The average production incident today takes too long to diagnose because the responder is doing five things in parallel: reading logs, querying metrics, finding the right runbook, paging the right owner, and deciding what to do. Most of that is pattern matching against information that already exists in our observability stack. We can compress that pattern-matching loop.

## The product

AEGIS is an agentic platform that:

1. **Diagnoses** a production incident by synthesising observability signals (Splunk logs, Dynatrace metrics, AIOps correlations, SLO state) and, from Phase 2 onward, the source code of the affected service.
2. **Generates a dynamic runbook** — a structured plan with ranked hypotheses, confidence scores, and pre-staged actions.
3. **Executes remediation** through MCP-based tool integrations, under a mode-driven approval gate calibrated to risk.
4. **Verifies recovery** by re-querying observability and either declaring resolution, escalating, or returning to diagnosis.
5. **Learns** by capturing the resolution into an incident memory that informs future runbooks for similar fingerprints.

## Who it serves

- **App-team SREs and developers** — the on-call rotation for an onboarded service. AEGIS is their force multiplier.
- **Platform SRE team** — operates AEGIS itself, onboards new services, runs the eval harness.
- **SRE leadership** — sees the ROI dashboard, signs off on mode promotions.
- **Risk, audit, and CISO functions** — consume AEGIS's audit log, model cards, eval results.

## Success metrics

- 40% reduction in MTTR on onboarded Tier-1 services.
- ≥85% suggestion-accept rate for onboarded services before any are promoted past `approval_required`.
- <5% cause-attribution hallucination rate, judged by app owners on a rolling sample.
- 25+ apps onboarded across three lines of business by month 12.
- Token cost per resolved incident tracked and bounded.

## What AEGIS does not do

- It does not replace human responders. It is gated to never take destructive action without an approved policy.
- It does not silently degrade. When code context is unavailable, runbooks are tagged `code_context: unavailable` and downstream gates adjust.
- It is not a generic chatbot. There is no free-form Q&A surface.
- It is not a replacement for the SRE platform team — the team operates AEGIS, and is itself instrumented by it.

## Constraints

- All external systems through MCP. No vendor SDK calls in agent code.
- All data through the redaction layer before reaching a model.
- All decisions written to an immutable, 7-year-retained audit log.
- All actions idempotent.
- All destructive actions require human approval; no exceptions.

## Non-goals (deliberately out of scope)

- We are not building an observability platform. AEGIS reads from existing ones.
- We are not building a ticketing system. AEGIS writes into the existing one.
- We are not building a runbook editor. Runbooks are generated, not authored by humans (though humans can annotate).
- We are not building a model. AEGIS uses Anthropic Claude models through the API.

## Phasing (see ROADMAP.md for detail)

Not in this workspace. `aegis-forge` is for feature-by-feature production development — the order of features is opportunistic, driven by what we're learning and what unblocks the most. If a multi-phase roadmap emerges, it lives in `aegis-cline`, not here.

Active and planned features are tracked through the task pipeline:
- `ideas/INBOX.md` — captured ideas, pre-stress-test.
- `ideas/deferred.md` — survived stress-test, awaiting activation condition.
- `tasks/NNN-*.md` — claimed and in-flight or shipped.
- `docs/adr/NNNN-*.md` — architectural decisions made along the way.

The state of what's shipped lives in `STATE.md`. The state of what's coming lives in the task and idea files. There is no plan that says "do these features in this order"; there is a discipline that says "every feature stands on its own merits."
