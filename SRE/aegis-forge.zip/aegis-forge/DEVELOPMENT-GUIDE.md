# Development Guide

The operating manual for `aegis-forge`. This document describes the **full ideate → develop → test → ship cycle** for one feature. The agent enforces most of it for you; this guide explains the why so you can drive deliberately.

Read it once end-to-end. Refer back to specific stages as you work.

---

## The mental model

In this workspace, **the unit of work is one feature, not one phase**. There is no master plan that says "do X then Y then Z." Each feature stands on its own merits, survives its own stress-test, ships under its own task file, and gets reviewed on its own evidence.

This is the right shape when:
- The architecture is settled enough that features are additive, not exploratory.
- The order of features is opportunistic — driven by what you're learning, what users are asking for, what unblocks the most.
- You still want production discipline: no surprises, no silent regressions, no untraceable decisions.

The cycle is seven stages. Most features go through all seven. Some skip stages legitimately (a tiny bug fix may not need an ADR; a refactor doesn't change behavior so eval isn't relevant). The agent will tell you which stages apply.

```
  Ideate  →  Define  →  Develop  →  Test  →  Review  →  Ship  →  Document
    ↑                                                                   |
    └───────────── feeds back into the next cycle ──────────────────────┘
```

---

## Stage 1 — Ideate

**Goal:** capture the idea so it isn't lost, and stress-test it so weak ideas die early.

### Capture

When an idea hits, append to `ideas/INBOX.md`. Format: date, source, one paragraph. No design, no scope, no quality bar. This takes 60 seconds. Examples of legitimate triggers:

- A real incident in production that AEGIS should have caught.
- A conversation with an app team about what they wish AEGIS did.
- A pattern you noticed across multiple eval failures.
- A vendor-API capability you didn't know existed.
- An architectural intuition that wants to be tested.

If you're mid-task and an idea surfaces, **don't follow it**. Append to INBOX, return to the current task. This is the single most important discipline in vibe-adjacent development.

### Stress-test

When you're ready to evaluate an idea (within a few days; weekly review at the latest), switch Roo Code to `architect-aegis` mode. Standing prompt:

> *"Stress-test this idea against the rules and the architecture. Run all six questions from rule 08. Be ruthless. Tell me whether it dies, gets sharper, or gets committed — and to what artifact."*

The six questions (full text in `.roo/rules/08-feature-protocol.md`):

1. **Invariant check.** Does this require violating any of the 10 invariants in rule 02? If yes — kill the idea or amend the invariant in writing first. Never both at once.
2. **Problem check.** Whose specific pain does this solve? If hypothetical, reject or defer.
3. **Phase check.** Does this depend on infrastructure not yet built? If yes, defer with an activation condition.
4. **Smallest version.** What's the cheapest version that proves the idea? If no < 1-week version can be named, the idea isn't ready.
5. **Failure mode.** What's the worst thing this does when broken? Can existing gates contain it? If not, what new gate ships with it?
6. **Carrying cost.** What does it cost to maintain, not build? Be honest.

The agent produces a structured assessment. **You** read it critically — the agent has no skin in the game.

### Classify

The output of stress-testing routes the idea to one of six destinations:

| Outcome | Goes to | Use when |
|---|---|---|
| **Reject** | `ideas/rejected.md` | Question 1, 2, or 3 fails with no fix. |
| **Defer** | `ideas/deferred.md` | Belongs later; include the activation condition (a state, not a date). |
| **Spike** | `tasks/9NN-spike-*.md` | Too uncertain to scope; needs research first. |
| **ADR** | `docs/adr/NNNN-*.md` | Architectural decision required before tasks make sense. |
| **Task** | `tasks/NNN-*.md` | Scoped, dependencies clear, ready to execute. |
| **Rule change** | Updates `.roo/rules/` | Affects the contract. Rare. PR-announced. |

A useful diagnostic: an ADR answers "*which* should we do?", a spike answers "*could* we do this?", a task answers "*how* do we ship this?" If you're conflating two of those, you have two artifacts.

Drop a one-liner back in `ideas/INBOX.md` pointing to the artifact. ("→ task 042" or "→ ADR 0007".) The idea now lives in one place with a clear status.

---

## Stage 2 — Define

**Goal:** produce the artifact that will guide the work.

### If the outcome is a task

Pick the right template from `tasks/`:
- `_template-feature.md` — new behavior, new capability.
- `_template-spike.md` — time-boxed research.
- `_template-bug.md` — fixing existing broken behavior.
- `_template-refactor.md` — improving internals without changing behavior.

Copy to `tasks/NNN-<short-title>.md` using the next available number. Fill in:
- Objective (1 paragraph).
- Scope in (explicit list of what this task does).
- Scope out (explicit list of what's tempting but belongs elsewhere — this is what stops scope creep).
- Acceptance criteria (checkable, not aspirational).
- Implementation notes (architectural pointers, gotchas, references to invariants).
- Testing requirements (which tests, what depth — see Stage 4).
- Exit artifacts (code path, docs, eval cases, failure-mode entries).

The agent helps you fill these in. **You** confirm them. The task file is the contract between this feature and the rest of the system.

### If the outcome is an ADR

Copy `docs/adr/0000-template.md` to `docs/adr/NNNN-<short-title>.md`. The ADR has these required sections:

- **Context** — what problem requires a decision, what constraints apply.
- **Decision drivers** — the forces that matter (performance, cost, operability, audit, reversibility).
- **Considered options** — minimum of two. If there's only one option, the decision is already made; you don't need an ADR.
- **Decision** — which option and why, referencing the drivers.
- **Consequences** — both good and bad.
- **Failure modes introduced** — entries that will land in `docs/failure-modes.md`.

Once the ADR is accepted (status: `accepted`), the implementation tasks follow. An ADR without tasks behind it is a thinking exercise; an ADR with tasks is a decision.

### If the outcome is a spike

Spikes are time-boxed (default 1 day, never more than 3). The exit artifact is a doc, not code. The doc answers a specific question well enough to commit to a real task afterwards. Use `_template-spike.md`.

---

## Stage 3 — Develop

**Goal:** ship the code with discipline.

### Pre-flight

Before opening Cline:
1. **Read the task file.** All of it. The scope, the acceptance criteria, the testing requirements.
2. **Check the claim.** If `Claimed by:` is empty, claim it: edit the field with your name and today's date. Commit this small change first. If it's already claimed, pick a different task.
3. **Pick the mode** named in the task header. See `.roomodes` — `feature-dev`, `mcp-integrator`, `test-author`, etc.

### Start the session

Standing prompt:

> *"Execute task NNN. Read `.roo/rules/`, `STATE.md`, and `.roo/memory.md` first. Confirm scope before writing any code — restate what you're going to do, what you're explicitly not doing, and any assumptions."*

The agent restates. You confirm or correct. Don't let it start coding until the restatement is right. This is where 80% of wrong-direction work gets prevented.

### Coding discipline (rule 03)

The agent enforces these; this is what to expect:

- Python 3.12, async-first, type hints required.
- `ruff` + `black` formatting; `mypy --strict` on the core packages.
- One concern per commit. Conventional commit messages.
- Pydantic v2 for anything crossing a boundary.
- No new dependencies without discussion.
- No speculative abstractions — add when the second concrete need appears, not the first.

### Agent design discipline (rule 04)

For tasks that touch an agent (Strategist, Sub-Agents, classifier):

- Smallest useful agent — can the orchestrator handle this deterministically?
- Tool-use over freeform output for structured data.
- Explicit confidence in the schema, not implied in prose.
- Token budgets are caps, not targets.
- Failure modes documented before merge.

### What to do when the agent goes sideways

- **Restating wrong.** "That's not the scope. Re-read the task file. The scope-out section explicitly excludes X."
- **Inventing abstractions.** "Stop. You're introducing three new classes for a 30-line feature. Show me the simplest version — under 50 lines — and we'll grow from there."
- **Drifting off-task.** "Show me a summary of every file you've changed in this session. Are any of them not in scope?"
- **Generating code you don't understand.** "Walk me through what you just wrote, line by line, like I haven't read it. Then tell me which two lines are most likely to break."

---

## Stage 4 — Test

**Goal:** the feature works under the conditions that will matter in production.

Testing is not a separate task. It lands in the same PR as the code. Rule 10 (testing discipline) describes the contract; `docs/testing-strategy.md` describes the rationale. The short version:

### The four test layers

1. **Unit tests** — fast, local, hit the happy path and the two most likely failure modes per public function.
2. **Integration tests** — `@pytest.mark.integration`. Hit real (containerized) dependencies — Postgres, Redis, mock MCP servers. Run in CI nightly, not on every PR.
3. **Eval tests** — for any change that touches agent behavior, the eval harness runs against the golden set. PR-time eval is a subset (10 cases, <5 min); nightly eval is the full set. PR fails if the golden score regresses by more than 2%.
4. **Manual tests** — for UI changes and for first-time end-to-end flows. Checklisted in the PR description, not skipped.

### Which layers a given task requires

The task template's "Testing requirements" section names them. As a default:

- **Feature task** — unit + integration + (eval if agent-touching) + manual if UI.
- **Bug task** — a regression test that fails before the fix and passes after; then the same layers as the affected feature.
- **Refactor task** — characterization tests that lock in current behavior before the change; full test suite after.
- **Spike task** — no tests required (the output is a doc).

### Coverage gates

- 80% line coverage on `agents/` and `orchestrator/` (enforced in CI).
- 100% coverage on the audit-write path (it's a compliance contract; no exceptions).
- For new code: at least one test per new public function. Internal helpers can be tested transitively.

### Pre-merge

Run locally before pushing:

```bash
ruff check .
black --check .
mypy --strict app orchestrator agents mcp
pytest -m "not integration"
# If the change touches agent behavior:
python -m evals.runner --agent strategist --set golden-pr-subset
```

CI runs all of these plus integration tests on the PR. CI is the gatekeeper, not a hint.

---

## Stage 5 — Review

**Goal:** catch what you couldn't see while building.

### Self-review

Before opening the PR, the agent and you do a self-review. Standing prompt:

> *"Self-review pass. List every file changed. For each, describe what changed and why. Flag anything you're uncertain about, anything that violates an invariant, anything that adds reach without an updated failure-mode entry, and anything I should look at carefully."*

The agent produces the review; you read it. Address the flags before opening the PR. This catches an embarrassing percentage of issues without anyone else having to look.

### Cross-review (rule 09)

**Code written by Cline driven by Jey is reviewed by Aayushi. Code written by Cline driven by Aayushi is reviewed by Jey.** This is the non-negotiable.

The reviewer's mandate is to be adversarial. Specifically check:

- **Scope.** Does the PR do what the task said and nothing else?
- **Invariants.** Does any change touch the 10 invariants? If so, is the touching deliberate and documented?
- **Tests.** Are the testing requirements from the task file actually met? Are the tests meaningful, or do they assert "the function returns true"?
- **Failure modes.** If the change adds reach, is `docs/failure-modes.md` updated?
- **Memory.** If the work surfaced a non-obvious fact, is `.roo/memory.md` updated?
- **Diff readability.** Can you read every line and explain it? If no, ask.

For PRs that touch the **contract surfaces** — anything in `.roo/rules/`, any ADR, `ROADMAP`/`STATE`, any invariant-touching code — **both humans review**. These are contract changes; consensus matters.

---

## Stage 6 — Ship

**Goal:** merge cleanly and make the change durable.

### PR description (required sections)

- **Task / ADR reference.** "Closes task 042."
- **What changed.** Two or three sentences. Plain language.
- **Why it changed.** What problem this solves.
- **How it was tested.** Layers and notable cases.
- **Invariant compliance.** If the PR touches one, restate compliance: "Invariant 4 (idempotency): the new action carries an idempotency key constructed from (incident_id, step_id, action_type). Test in `agents/test_remediator.py::test_idempotency_key_present`."
- **Failure modes added.** Reference any new entries in `docs/failure-modes.md`.

The agent drafts this; you sharpen it.

### Merge gates

The PR cannot merge unless:
- All CI checks pass (lint, type, unit, integration, eval if relevant).
- Cross-review approval is recorded.
- For contract-surface changes: second human review recorded.
- For agent-behavior changes: eval golden-set score reported and within 2% of baseline.

### Post-merge

On merge:
- `Claimed by:` becomes `Completed by:` in the task file, with the merge date. The task file stays in the repo as a record.
- The relevant entry in `ideas/INBOX.md` is updated with the merged status.

---

## Stage 7 — Document

**Goal:** make the change discoverable by your future self and your collaborators.

After every meaningful merge — not after every typo fix:

### Update STATE.md

If the change shifted what's load-bearing or what's scaffolding, update the relevant sections. Most tasks don't change STATE; the structural ones do. A stale STATE is worse than no STATE; the agent will believe it.

### Update memory.md

If the work surfaced a non-obvious fact — a vendor API quirk, a performance characteristic, a subtle interaction between components — append to `.roo/memory.md`. Date and author tag the entry. This is how the team accumulates tacit knowledge that doesn't fit in code or rules.

### Update failure-modes.md

If the change introduced a new failure mode (i.e., a new way the system could be wrong in production), add the entry per the template at the top of `docs/failure-modes.md`. Don't wait for the failure to happen.

### When the change deserves more

For large features, draft a short retrospective note in `notes/` (or wherever you keep informal docs): what worked, what was surprising, what you'd do differently. These compound over time into real engineering wisdom.

---

## The artifacts you'll produce

A complete feature, end to end, leaves behind:

1. An entry in `ideas/INBOX.md` with the original idea and the disposition link.
2. (Optionally) An ADR in `docs/adr/` if architectural.
3. A task file in `tasks/NNN-*.md`, marked completed.
4. Code in the relevant packages.
5. Tests in the matching test files.
6. (If agent-touching) Eval cases in `evals/golden/<agent>/`.
7. (If new failure modes) Entries in `docs/failure-modes.md`.
8. (If learned something tacit) An entry in `.roo/memory.md`.
9. (If state changed) Updated `STATE.md`.
10. A PR with a complete description, merged with cross-review.

If any of those is missing for a feature that should have it, the feature isn't really done.

---

## Common failure modes (and how to catch them early)

### "The agent did most of this and I don't understand half of it"

You stopped reading diffs. The cure is to ask the agent to walk you through the changes line-by-line before merging. If you can't explain the code, you can't review the code, and you shouldn't ship the code.

### "Three half-built features, none merged, demo subtly broken"

You kept saying yes to new ideas without closing loops. The cure is hard: stop. Pick one in-progress task. Ship it or park it. Then start the next. Concurrent feature count is mostly self-imposed.

### "I wrote a task that took a week instead of the estimated day"

You missed a dependency or under-scoped. Document it in the task's completion notes, learn the pattern, and split the next task more aggressively.

### "An invariant got violated and review didn't catch it"

The reviewer didn't run the invariant checklist explicitly. Add an explicit invariant-check section to your PR template if this happens twice.

### "We rebuilt something we'd already considered and rejected"

You didn't check `ideas/rejected.md` before stress-testing the new idea. The rejected file is a search-first resource, not just a record.

### "The eval regressed but we merged anyway"

Discipline failure. The 2% threshold isn't advisory. If you genuinely have a reason to override it, the override is documented in the PR description and reviewed by the other human.

---

## When to break the protocol

The protocol serves the work, not the other way around. Skip stages when:

- **Trivial fixes** — typo, dependency bump, formatting. Skip ideation; skip ADR; skip eval. Still test, still review.
- **Production incident** — fix first, ADR the decision retroactively. Don't run six stress-test questions while customers are impacted.
- **Reverting a bad merge** — revert immediately; ADR the rollback decision separately.

When you skip, do it deliberately. "I'm skipping stages 1–2 because this is a typo fix" is fine to write in the PR description. "I forgot the protocol existed" is not.

---

## Bootstrapping from an existing codebase

If you're applying this workspace to an existing AEGIS demo (or any existing codebase), see `docs/bootstrap-from-existing-codebase.md` for the four-step overlay process. The short version: copy your code in, seed `STATE.md`, run a codebase-audit task in architect mode, generate gap-closing tasks. You're not starting over — you're inheriting.

---

## The agent enforces this for you

When you start a session and say "let's add feature X," the agent will:

1. Check whether the idea is captured in INBOX. Capture it if not.
2. Run the six stress-test questions.
3. Propose a classification.
4. Wait for your confirmation.
5. Generate the artifact (task, ADR, etc.).

This is the protocol from rule 08. The agent will not enthusiastically scaffold a feature when the right move is to ADR the architectural choice first. That discipline is the whole point of the workspace.

The agent also enforces task discipline (rule 06), testing requirements (rule 10), collaboration conventions (rule 09), and the architectural invariants (rule 02). What you provide is direction, judgment, and the willingness to push back when the agent's confident answer is wrong.

That last part is the most important. The agent is a force multiplier on your engineering. It is not a substitute for it.
