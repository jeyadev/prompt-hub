# 10 — Testing Discipline

Tests are not a separate task. They land in the same PR as the code they test. The CI gate requires it. This rule describes what the agent enforces and what humans verify.

## The four test layers

Every change selects from these layers based on what it touches.

### Layer 1 — Unit tests

Fast, deterministic, no external dependencies. Test the public contract of one module at a time. Default test framework: `pytest` with `pytest-asyncio`.

Required for:
- Every new public function in `agents/`, `orchestrator/`, `mcp/`.
- Every change to an existing public function (a test that would have caught the bug, or an extension to existing tests).
- Pydantic schema changes (validation behavior is part of the contract).

Naming: tests co-located with source. `foo.py` → `test_foo.py` in the same directory.

### Layer 2 — Integration tests

Hit real, containerized dependencies — Postgres, Redis, mock MCP servers, the actual eval judge. Marked `@pytest.mark.integration`. Run in CI nightly and on demand; not on every PR (too slow).

Required for:
- New MCP adapters (one happy-path recorded test + one failure-mode test).
- Database schema changes (round-trip the new shape end-to-end).
- Any orchestration logic that crosses three or more components.

Use `testcontainers-python` for ephemeral Postgres / Redis. Reuse the container across the test session — startup cost is non-trivial.

### Layer 3 — Eval tests

For any change that touches agent behavior — prompt, model, context strategy, schema. The eval harness runs against the golden set.

Required for:
- Strategist prompt or schema changes.
- Sub-Agent prompt or schema changes.
- Changes to the context-assembly logic that feeds an agent.
- New agent types.

PR-time eval is a subset (10 cases, < 5 min). Nightly eval is the full set. The PR fails if the golden score regresses by more than 2% against the most recent `main`.

The eval is **not advisory**. Overriding the regression threshold requires:
1. Explicit acknowledgement in the PR description ("Accepting 4% regression on case class X because Y").
2. Second human approval.
3. An entry in `ideas/INBOX.md` to revisit the regression within two weeks.

### Layer 4 — Manual tests

Checklisted, not skipped. Required for:
- UI changes (the React console).
- First-time end-to-end flows (a new incident path, a new MCP integration in production).
- Failure-mode rehearsals (simulate the failure mode, verify the gate catches it).

The PR description names the manual tests run, with a brief result for each.

## Which layers a given task requires

The task template's "Testing requirements" section names them. Defaults:

- **Feature** — Layer 1 + Layer 2 + (Layer 3 if agent-touching) + (Layer 4 if UI).
- **Bug** — A regression test that fails before the fix and passes after (Layer 1, usually). Then the layers the affected feature originally needed.
- **Refactor** — Characterization tests that lock in current behavior **before** the change. Full suite after.
- **Spike** — No tests required; the output is a doc.

If the task is unclear about layers, ask. Don't infer "no tests needed" from silence.

## Test quality, not test quantity

A high coverage number with shallow tests is worse than a lower coverage number with sharp tests. The agent should not pad coverage by asserting `assert function_returns_something`. Each test should:

- Assert one thing per test where possible.
- Use realistic inputs, not just empty objects.
- Cover the happy path AND at least the two most likely failure modes.
- Use fixtures for shared setup; avoid stateful test interdependency.

For prompt-driven agents, the agent's output is structured; the test asserts schema validity AND content properties (e.g., "the top hypothesis is in the deploy-induced class"). Free-text snapshot tests are brittle and not preferred.

## Coverage gates

- **80% line coverage** on `agents/`, `orchestrator/`, and `mcp/`. CI fails below this.
- **100% coverage** on the audit-write path. The audit log is a compliance contract; no test gaps.
- **New code in the PR** — every new public function has at least one test. Internal helpers can be tested transitively through their callers.

Mutation testing is not currently enforced. If we find ourselves doubting test quality, we'll add it.

## TDD vs test-along

This codebase doesn't mandate strict TDD. The convention is **test-along**: write the test for a behavior either just before or just after the implementation, in the same session, in the same commit. Tests written days later are second-class evidence.

The exception: bug fixes are **strictly test-first**. The regression test exists before the fix lands. The test fails on `main`, passes on the fix branch. This is non-negotiable.

## Prompt snapshot tests

For agents whose prompts are stable contracts:

- The prompt is rendered against a fixture input and snapshot-tested.
- A change to the prompt requires acknowledging the snapshot diff in the PR.
- Acknowledgement is not a rubber stamp — the reviewer reads the diff and confirms the prompt change is deliberate.

This catches accidental prompt changes (a stray edit, a refactor that altered the rendered output). It does not replace eval; it complements it.

## What the agent must do

When implementing a task:

1. Read the task's "Testing requirements" section before writing code.
2. Write tests in the same session as the code they test (test-along default; test-first for bug fixes).
3. Run the local test suite before declaring done — at minimum: ruff, black, mypy, pytest (non-integration).
4. If the change touches agent behavior, run the PR-subset eval and report the result in the PR description.
5. If a test is hard to write because the code is structured awkwardly, fix the code, not the test.

## What the agent must not do

- Skip tests because "it's a small change." Small changes break production all the time.
- Write tests that pass by tautology (`assert result is not None`).
- Mock so aggressively that the test asserts the mock works, not that the code works.
- Use `@pytest.mark.skip` to bypass a failing test without an issue number and a deadline.
- Add tests after the PR is opened in response to review comments. Tests are part of the PR; if they're missing, the PR isn't ready.

## When testing exposes a deeper problem

Sometimes writing a test reveals that the code is structured wrong — the test is too hard to write, the dependencies are too tangled, the function does too much. When this happens:

- **Stop.** Don't write a tortured test.
- **Flag it** in the PR description: "Testing this required mocking X, Y, and Z. The structure suggests a refactor."
- **Decide.** Either ship the test as-is and open a refactor task, or refactor in this PR (only if the refactor is small).

Painful tests are diagnostic. Listen to them.
