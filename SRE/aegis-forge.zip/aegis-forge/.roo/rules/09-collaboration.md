# 09 — Multi-Developer Collaboration

This codebase has more than one human contributor. The agent supports collaboration by enforcing the conventions below. Solo-developer assumptions in earlier rules are superseded here when relevant.

## The team

Contributors are listed in `CONTRIBUTORS.md` at the workspace root, with role and timezone. The agent reads this when context-setting.

## Append-only memory and idea files

The agent and humans both write to `.roo/memory.md`, `ideas/INBOX.md`, `ideas/deferred.md`, and `ideas/rejected.md`. These are **append-only by convention**:

- Never edit a prior entry. If a prior entry is wrong, append a new entry that corrects it and references the original.
- Every entry carries author and date: `## YYYY-MM-DD — Jey — short title` or `## YYYY-MM-DD — Aayushi — short title`. The agent writes its own author as the human who initiated the session, *not* as "agent" — the human is accountable.
- Conflicts are impossible by design. Merge is trivial.

## Task claim semantics

Tasks under `tasks/` have an optional `Claimed by:` field in their header. The first human to start a task adds their name and date. Others see the task is in progress and don't pick it up.

```markdown
# Task NNN — Title

**Phase:** ...
**Mode:** ...
**Estimated effort:** ...
**Claimed by:** Jey (2026-05-13)   ← added on start
**Depends on:** ...
```

When the task ships (PR merged), the claim becomes `Completed by:` with the merge date. The task file stays in the repo as a record.

If a task is abandoned (claim was wrong, scope changed, dependencies shifted), the claimer adds an `Abandoned by:` line with the date and reason and removes the `Claimed by:`. Another contributor can then pick it up.

## Cross-review is mandatory

**Code written by Cline driven by Jey is reviewed by Aayushi.**
**Code written by Cline driven by Aayushi is reviewed by Jey.**

The driver is too invested to see what the agent missed. The reviewer is fresh and adversarial.

For PRs that touch:
- Anything in `.roo/rules/`
- Anything in `docs/adr/`
- `ROADMAP.md` or `STATE.md`
- Any invariant-touching code (rule 02)

…review is by *both* humans, not just one. These are contract changes; consensus matters.

## Daily sync — the standup prompt

Once per day, one contributor runs a short Cline session in `architect-aegis` mode with the standing prompt:

> *"Daily standup. List: (1) tasks that moved to Completed in the last 24h, (2) tasks currently claimed and by whom, (3) any new INBOX entries, (4) any open ADRs awaiting decision. Keep it under 200 words."*

The output goes in a shared channel (Slack, whatever the team uses). This keeps both humans aware of the codebase's state without a meeting.

## Weekly sync — the protocol review

Once per week, the team runs the protocol review from rule 08, cadence section. This is a 30-minute call. Both humans on the call. The agent supports by surfacing the worklist; the humans make the calls.

## Pair-driving a task

Sometimes two humans want to drive Cline together — typically for architectural tasks or particularly tricky bugs. The convention:

- One human drives the Cline session (sends prompts, accepts/rejects diffs).
- The other observes in a screen share, comments verbally, takes notes in INBOX.
- The driver alternates between sessions, not within a session. Don't hand off the keyboard mid-conversation; clear and restart with the other human driving.

This is for high-value moments. Most tasks are solo-driven; pair-driving is a special-occasion tool.

## What the agent enforces

When a human starts a Cline session:

1. **Read `CONTRIBUTORS.md`** to know who's involved.
2. **Check task claim status** before suggesting a task to work on. The agent does not propose work that's already claimed by someone else.
3. **Stamp author and date** on every memory and idea entry, using the human who initiated the session.
4. **Refuse to single-review PRs** that touch the contract surfaces listed above. The agent reminds the driver that cross-review is required.

## Onboarding a new collaborator

When a new human joins:

1. Add them to `CONTRIBUTORS.md` with role and timezone.
2. They read, in order: `README.md`, `STATE.md`, every file in `.roo/rules/`, `docs/feature-protocol.md`, `docs/bootstrap-from-existing-codebase.md`, `docs/onboarding-runbook.md`. This is ~90 minutes of reading.
3. Their first task is a small one — fix a bug, add a small feature, or improve documentation. Owner-claim, drive Cline, get cross-reviewed by an existing collaborator. The first PR teaches the protocol better than any doc.
4. Add an INBOX entry: "Onboarded [name] on YYYY-MM-DD."

## When this rule conflicts with another

Solo-developer language elsewhere in the rules should be read with this rule's overrides applied. Specifically: anywhere a rule says "you" referring to a single developer, in a multi-dev context it means "the team," and decisions require the conventions above.
