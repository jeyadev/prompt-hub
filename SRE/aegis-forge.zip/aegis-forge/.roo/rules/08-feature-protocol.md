# 08 — Feature & Idea Protocol

How ideas become work in this codebase. The agent enforces this protocol whenever the human raises a new feature, change, or capability. The agent does **not** dive into implementation when an idea is raised — it runs the protocol first.

## The five stages

### 1. Capture

Raw ideas land in `ideas/INBOX.md`. Format: date, one paragraph, trigger/source. No design, no scope, no quality bar. The goal is to not lose the thought.

If the user raises an idea in conversation that hasn't been captured, the agent's first action is to append it to INBOX with the user's framing intact, then proceed to stage 2.

### 2. Stress-test

When asked to evaluate an idea, the agent enters stress-test mode and runs the six questions below. The output is a structured assessment, **not** an implementation plan. The agent should currently be in `architect-aegis` mode for this stage; if not, suggest switching.

The six questions:

1. **Invariant check.** Does this require violating any of the 10 invariants in rule 02? If yes — the idea dies, or the invariant changes in writing first. Both cannot happen in the same change.
2. **Problem check.** Whose specific pain does this solve? Name the user. If the answer is hypothetical ("we might want…"), reject or defer.
3. **Dependency check.** Does this depend on infrastructure that isn't yet built? If yes, defer with the specific activation condition (a state, not a date) that would unblock it. Don't try to build the dependent before the foundation.
4. **Smallest version.** What's the cheapest version that would prove the idea? If no < 1-week version can be named, the idea isn't ready — return to brainstorming.
5. **Failure mode.** What's the worst thing this does broken? Can existing gates contain that? If not, what new gate must ship with it?
6. **Carrying cost.** What does it cost to maintain, not build? Be honest.

A single "no" on questions 1, 2, or 3 should kill or defer. Questions 4–6 sharpen.

### 3. Classify

Each stress-tested idea routes to exactly one outcome:

| Outcome | Where it lands | When |
|---|---|---|
| **Reject** | `ideas/rejected.md` | Question 1, 2, or 3 fails with no fix. |
| **Defer** | `ideas/deferred.md` | Belongs to a later phase, or pending another decision. Include the activation condition. |
| **Spike** | `tasks/9NN-spike-<topic>.md` | Too uncertain to commit. Time-boxed research, output is a doc. |
| **ADR** | `docs/adr/NNNN-<title>.md` | Architectural decision required before implementation. |
| **Task** | `tasks/NNN-<title>.md` | Ready to commit. Maps to a roadmap workstream. |
| **Rule change** | Updates `.roo/rules/` | Affects the contract. Rare. PR-announced. |

### 4. Commit

The agent generates the chosen artifact in the right place. The INBOX entry gets a back-link to the artifact in one line ("→ task 014" or "→ ADR 0003"). If the task adds a workstream not in `ROADMAP.md`, the agent proposes a roadmap update in the same PR.

### 5. Cadence

The user runs a weekly review. The agent supports it on request:

- INBOX older than 7 days: stress-test or reject.
- Deferred older than 90 days: revive or kill.
- Tasks blocked > 2 weeks: surface and propose an action.

## When the user says "let's add X"

The agent does not start implementing. It runs the protocol:

1. Confirm the idea is captured in INBOX (capture it if not).
2. Run the six stress-test questions, narrating the answer to each.
3. Propose a classification.
4. Wait for the user's confirmation on the classification.
5. Generate the artifact.

This protects against two failure modes: the agent enthusiastically scaffolding the wrong thing, and the user ratifying a bad idea because the implementation looks impressive.

## Naming conventions

- INBOX entries: `## YYYY-MM-DD — short title`
- Rejected: same shape; include the rationale below.
- Deferred: same shape; include the activation condition below.
- Spike tasks: `tasks/9NN-spike-<topic>.md` (numbering: 900–999 reserved for spikes).
- ADRs: `docs/adr/NNNN-<title>.md`, four-digit zero-padded, never reused.
- Tasks: existing convention in `tasks/README.md`.

## What this protocol is not

- Not a way to slow things down. The full protocol on a simple idea is 10 minutes.
- Not a way to gatekeep on someone else's judgment. The user is always the decision-maker; the agent provides structure.
- Not a substitute for thinking. It's a scaffold for thinking.

When the protocol becomes friction rather than support, revisit it. Rules are versioned for a reason.
