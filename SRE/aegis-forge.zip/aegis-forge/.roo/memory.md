# AEGIS — Living Memory

The agent (and humans) append durable tacit knowledge here. Things that don't belong in code, don't belong in docs, but would save a future session from re-learning.

## Format

```
## [YYYY-MM-DD] — [Author name] — Short title
Source: who/what discovered this (incident, audit, vendor doc, debugging session)
Context: when does this matter?
Lesson: what to do or avoid.
```

The author is the human who initiated the session in which the agent learned the lesson — not "agent" or "Cline." Humans are accountable for the memory's content.

## Seed entries

## [2026-05-13] — Setup — This memory file is for tacit knowledge
Source: setup
Context: every Roo session
Lesson: This file is not for project requirements (those go in PRD.md), architecture (ARCHITECTURE.md), or roadmap (ROADMAP.md). It is for things like "the Splunk MCP returns timestamps in microseconds, not milliseconds" — non-obvious facts that surface during work and would be expensive to re-discover.

## [2026-05-13] — Setup — Read the rules before starting
Source: rule 06
Context: every new task
Lesson: A 60-second scan of `.roo/rules/` saves a 60-minute wrong-direction unwind. The rules are short on purpose; read them. Confirm scope before writing code on non-trivial tasks.

---

(Future entries are added below as the codebase teaches us.)
