# aegis-forge

A production-grade Cline workspace for **feature-by-feature development**. Full engineering discipline — invariants, ADRs, evals, audit, cross-review — applied to one feature at a time, not to a fixed roadmap.

This is for the project after the demo proves the architecture, but before the roadmap solidifies. You know what kind of system you're building. You don't yet know the exact order in which features will land. This workspace lets you ideate, develop, test, and ship features under production discipline without committing to a phase plan.

## The three workspace shapes

If you're choosing between workspaces for AEGIS:

| | aegis-cline | **aegis-forge** | aegis-lab |
|---|---|---|---|
| **For** | Phase-bound production work | Feature-by-feature production work | Exploration and prototyping |
| **Spine** | Four-phase roadmap | Ideate → develop → test → ship cycle | Whatever you're vibing on |
| **Tasks** | 13 pre-decomposed tasks | Templates; you create as needed | Optional |
| **Discipline** | Heavy | Heavy | Light |
| **Use when** | CISO is watching, phases are decided | CISO is watching, scope is feature-flow | Stakes are low, learning matters |

## Quick start

```bash
unzip aegis-forge.zip
cd aegis-forge

# Overlay your demo code at the same root
rsync -av --exclude='.git' ../your-aegis-demo/ ./

# Initialize the repo
git init && git add . && git commit -m "chore: bootstrap aegis-forge workspace"

# Open in VS Code with Roo Code installed
code .
```

Then **read `DEVELOPMENT-GUIDE.md`** — it's the operating manual. After that, skim the rules in `.roo/rules/` so you know what the agent is enforcing on your behalf.

## What's in here

```
aegis-forge/
├── README.md                   # this file
├── DEVELOPMENT-GUIDE.md        # the operating manual — read first
├── PRD.md                      # what the product is (no phasing)
├── ARCHITECTURE.md             # system architecture
├── STATE.md                    # current state — load-bearing vs scaffolding
├── CONTRIBUTORS.md             # who's on the team
├── pyproject.toml              # Python tooling: ruff, black, mypy, pytest
├── .roo/
│   ├── rules/                  # 10 numbered files — the operating contract
│   │   ├── 01-project.md
│   │   ├── 02-architecture-invariants.md
│   │   ├── 03-coding-standards.md
│   │   ├── 04-agent-design.md
│   │   ├── 05-security.md
│   │   ├── 06-task-discipline.md
│   │   ├── 07-mcp-patterns.md
│   │   ├── 08-feature-protocol.md
│   │   ├── 09-collaboration.md
│   │   └── 10-testing-discipline.md
│   ├── mcp.json.example
│   └── memory.md
├── .roomodes                   # modes: architect, feature-dev, eval-engineer, test-author, mcp-integrator, polish
├── .clinerules
├── .clineignore
├── .gitignore
├── ideas/
│   ├── INBOX.md                # raw capture
│   ├── deferred.md             # survived stress-test, not yet
│   └── rejected.md             # didn't survive, kept for the record
├── tasks/
│   ├── README.md               # the task system: numbering, claim semantics, templates
│   ├── _template-feature.md    # copy this for a new feature
│   ├── _template-spike.md      # copy this for time-boxed research
│   ├── _template-bug.md        # copy this for a bug fix
│   └── _template-refactor.md   # copy this for a polish/refactor task
├── docs/
│   ├── feature-protocol.md     # the ideation protocol (human guide)
│   ├── bootstrap-from-existing-codebase.md
│   ├── failure-modes.md        # living catalogue
│   ├── eval-design.md          # eval methodology
│   ├── testing-strategy.md     # testing approach across layers
│   └── adr/
│       └── 0000-template.md    # ADR template — copy as 0001, 0002, ...
├── app/                        # FastAPI service
├── orchestrator/               # Agent orchestration core
├── agents/                     # Individual agent implementations
├── mcp/                        # MCP clients & adapters
├── evals/                      # Eval harness
├── tests/                      # Tests
└── scripts/                    # Ops scripts
```

## The cycle, in one line

**Capture** in INBOX → **stress-test** in architect mode → **classify** (task, ADR, spike, defer, reject) → **claim and develop** under rules → **test** to discipline → **cross-review** → **ship** → **update STATE, memory, failure-modes**.

The full version is in `DEVELOPMENT-GUIDE.md`. The agent enforces most of it for you; humans drive the decisions.

## When to graduate (or downgrade)

- **Graduate to aegis-cline** when your features have congealed into a multi-phase roadmap big enough to warrant pre-decomposition. The roadmap becomes the spine; this workspace's templates become the per-phase task files.
- **Downgrade to aegis-lab** when you have a specific exploration that doesn't justify the overhead — a hackday, a side prototype, a "let me just try this" moment. Use lab for that prototype; if it earns its way back into production, bring the proven parts here.
