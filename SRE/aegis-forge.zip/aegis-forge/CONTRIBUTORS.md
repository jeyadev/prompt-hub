# Contributors

| Name | Role | Timezone | Started | Notes |
|---|---|---|---|---|
| Jey Ganesh | Owner, architect, primary dev | IST (Bangalore) | (project inception) | forever_an_arjuna |
| Aayushi [last name] | Collaborating developer | (fill in) | YYYY-MM-DD | (fill in) |

## Roles in this codebase

- **Owner** — accountable for direction, roadmap, and final-call decisions. Currently Jey.
- **Architect** — makes ADRs, reviews invariant-touching changes, owns the rules. Currently Jey (with input from collaborators).
- **Developer** — drives Cline sessions, ships PRs, reviews others' PRs.
- **Reviewer** — does cross-review under rule 09. All developers are also reviewers.

## How to join

A new contributor:

1. Is added to this file by an existing owner.
2. Onboards via the flow in `.roo/rules/09-collaboration.md` ("Onboarding a new collaborator").
3. Picks a small first task, drives it through to merge, gets cross-reviewed.

## How to leave

A contributor leaving:

1. Releases all `Claimed by:` tasks (either complete, hand off, or mark abandoned).
2. Updates `STATE.md` with anything load-bearing that only they knew.
3. Stays listed in this file with an "until YYYY-MM-DD" note. We keep the history.
