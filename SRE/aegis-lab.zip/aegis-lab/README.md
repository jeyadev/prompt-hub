# aegis-lab

A lightweight Cline workspace for **vibe coding** on AEGIS. Drop your existing demo code in, open it in VS Code, start adding features. Minimum ceremony, fast iteration.

This is not the production-grade workspace. That one is for when the CISO is watching. This one is for when you're following an idea and you want the agent to keep up.

## Quick start

```bash
# 1. Unzip alongside or over your existing AEGIS demo code
unzip aegis-lab.zip
cd aegis-lab

# 2. Overlay your demo code at the same root
rsync -av --exclude='.git' ../your-aegis-demo/ ./

# 3. Open in VS Code with Roo Code (or Cline)
code .

# 4. Read VIBE-GUIDE.md once. Skim the two rules files. Start.
```

## What's here

```
aegis-lab/
├── README.md                  # this file
├── VIBE-GUIDE.md              # how to work in this workspace — read this
├── .roo/
│   ├── rules/
│   │   ├── 01-project.md      # what AEGIS is, very brief
│   │   └── 02-vibe-rules.md   # five rules, not fifty
│   └── memory.md              # what you've learned, append as you go
├── .roomodes                  # three modes: explore, build, polish
├── .clineignore               # secrets only
├── .gitignore
├── features/
│   ├── INBOX.md               # capture, no ceremony
│   ├── in-progress.md         # what you're building right now
│   ├── shipped.md             # what's done — a running journal
│   └── parked.md              # tried, paused, or decided not to
├── scratch/                   # the sandbox — try things here first
│   └── README.md
└── notes/
    └── README.md              # anything you want to keep, freely
```

Your existing code overlays into `app/`, `orchestrator/`, `agents/`, `mcp/` (or whatever shape your demo uses). The workspace files sit alongside.

## The whole philosophy in two lines

1. **Capture everything; commit deliberately.** Ideas go in `features/INBOX.md` without filtering. Code commits to the real codebase only after they survive a small experiment.
2. **The agent is fast; you are slow.** Use that asymmetry. Let the agent prototype five versions; you pick the one that feels right.

## When to graduate to the enterprise workspace

When the answer to "could this hurt customers?" stops being "no." When you need an audit log to defend yourself. When you have more than one contributor. When the CISO knows your project's name.

Until then, vibe.
