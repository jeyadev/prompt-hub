# The Vibe Coding Guide

How to work in this workspace. Read once. Re-read when you notice you're not having fun.

---

## What vibe coding is, and isn't

**Is:** following an idea with the agent at your speed. Accepting diffs when the direction feels right. Throwing things away cheaply. Building working prototypes in an afternoon. Letting the agent do the parts that bore you so you can do the parts that don't.

**Isn't:** accepting every diff blindly. Skipping `git commit` for days. Pushing untested code to a service your customers depend on. Letting the agent invent the architecture without you noticing.

Vibe coding is **trust with a leash**. The leash is short for things you don't understand and long for things you do.

---

## The three modes

This workspace defines three Roo Code modes. Pick the one that matches your intent.

### `explore` — when you don't know what you want yet

The agent can write anywhere in `scratch/` and `notes/`. Cannot touch real code paths. Use this when:
- You have a vague idea and want to see what it could look like.
- You want the agent to generate three versions of something so you can pick.
- You're learning how some library or pattern works.

Typical prompt: *"Here's a half-baked idea. Build me a working prototype in `scratch/` — pick reasonable defaults, don't ask too many questions, I'll iterate."*

### `build` — when you know what you want

The agent can write to the real code paths (`app/`, `orchestrator/`, `agents/`, `mcp/`, etc.). Use this when:
- The idea has graduated from scratch and you want it in the codebase.
- You're adding a specific feature to working code.
- You're fixing a bug.

Typical prompt: *"Add feature X to the codebase. Here's where it should live. Here's the rough shape. Read the existing code first; match its style."*

### `polish` — when you want to clean up

The agent can refactor, rename, restructure, add tests, improve types. **Cannot add new features.** Use this when:
- A vibe session left the code messy and you want to tidy.
- You want to add tests to something that's been working without them.
- You want to consolidate three near-duplicate functions into one.

Typical prompt: *"Polish pass on `agents/strategist.py`. Don't add features. Tighten the types, extract obvious helpers, add docstrings where they're missing."*

---

## The five rules (and why each exists)

These live in `.roo/rules/02-vibe-rules.md`. Read them. They're the leash.

1. **Don't commit secrets.** Pretty much the only hard rule. Use `.env` (gitignored).
2. **If you break the demo, fix the demo before adding more.** Working code is worth more than enthusiasm. Get back to green before the next vibe.
3. **Prototype in `scratch/` first if you're not sure.** Real code is sticky. Scratch code is free.
4. **Append to memory when you learn something.** `.roo/memory.md`. Future-you will not remember why you did the weird thing.
5. **One feature at a time in `features/in-progress.md`.** Max three. Beyond that you're not building, you're juggling.

---

## The feature flow

No stress-tests, no six questions. Just three files.

### Step 1 — Capture

Idea hits, open `features/INBOX.md`, append:

```markdown
## 2026-05-13 — Real-time runbook scoring widget
The console should show a confidence number on each runbook hypothesis,
updating as the Strategist streams. Probably 30 lines of React.
```

That's it. Don't elaborate. Don't scope. Capture and move on.

### Step 2 — Pick

When you're ready to build something, pick from INBOX. Move the entry to `features/in-progress.md`. You can have up to three in flight.

If the idea has grown teeth since you captured it, scope it now — what's the smallest version? What does "done" look like? Two or three bullets, no template, no ceremony.

### Step 3 — Vibe

Open Cline in `build` mode (or `explore` if you still don't know what you want). Reference the feature. Prompt:

> *"I'm working on the feature in `features/in-progress.md` titled X. Build the smallest version. Here's the shape I'm thinking. Read the relevant existing code first; match its style."*

Accept diffs, reject diffs, iterate. When it works, commit. When it stops being fun, stop.

### Step 4 — Ship or park

**Ship:** the feature works, you committed it, the demo still runs. Move the entry from `in-progress.md` to `shipped.md` with one line of what landed. Done.

**Park:** you stopped before it shipped. Maybe the idea was wrong, maybe it needs more thinking, maybe you got bored. Move to `parked.md` with one line of why. No shame; parked features come back stronger.

---

## Prompts that work

Steal these. Adapt them. The prompt is half the leverage.

### Starting a vibe session

> *"Read `.roo/rules/`, `.roo/memory.md`, and `features/in-progress.md`. Then ask me one question to start: which feature should we work on?"*

### Building a prototype in scratch

> *"In `scratch/<topic>/`, build me a working prototype of X. Use any libraries you like. Don't worry about tests yet. Pick reasonable defaults; I'll review and iterate."*

### Bringing a prototype into the real codebase

> *"The prototype in `scratch/<topic>/` works the way I want. Migrate the relevant parts into the real codebase. Match the existing code's style. Add tests for the happy path."*

### When the agent generates too much

> *"Stop. That's too much. Show me the smallest possible version — under 50 lines if you can. We'll grow from there."*

### When the agent generates code you don't understand

> *"Walk me through what you just wrote, line by line, like I haven't read it. Then tell me which two lines are the most likely to break."*

### When you've been vibing for hours and feel lost

> *"Summary check: what have we done in this session? What's committed? What's uncommitted? What's still open? Should we stop and ship what we have, or keep going?"*

### When the demo breaks

> *"The demo just broke. Find what changed in the last commit, what likely caused the break, and the smallest possible fix. Do not add any new features in this session."*

---

## The anti-patterns

These are how vibe coding goes wrong. Watch for them.

### Vibe debt

Symptom: three half-built features, none of them shipped, the demo is now broken in subtle ways.

Cause: you kept saying "yes, also do this" without ever closing a loop.

Fix: stop adding. Pick one in-progress item. Ship it or park it. Then green-light the next.

### Agent architect

Symptom: the agent has introduced three new directories, two abstractions, and a config system, and you're not sure how they relate.

Cause: you let the agent design while you were focused on the feature.

Fix: in `polish` mode, *"Inventory every new file and abstraction introduced in the last 5 commits. Tell me which ones I'm using, which ones I'm not, and which ones I could delete without breaking anything."* Delete liberally.

### Black-box feature

Symptom: a feature works but you can't explain how. If it broke, you'd have to ask the agent what it even does.

Cause: you stopped reading diffs at some point.

Fix: ask the agent to walk through the feature, then write 3 sentences in `notes/` explaining it in your own words. If you can't write the 3 sentences, the feature isn't really yours.

### Spec drift

Symptom: the feature you're building is no longer the feature you started building. It's grown three legs.

Cause: each diff was a small extension; over 20 diffs, you ended up somewhere different.

Fix: stop. Look at `features/in-progress.md`. Is what you're building still the thing you wrote down? If no, either update the entry to match what it became, or revert to the last commit that matched the original.

### Eternal scratch

Symptom: `scratch/` has 14 prototypes; none has graduated to the real codebase; you keep starting new ones.

Cause: the friction to graduate is higher than the friction to start a new prototype.

Fix: declare a moratorium on new scratch work for one week. Pick the two most promising prototypes; graduate one, delete the other. Repeat.

---

## When to take the leash short

These are the moments where you stop vibing and read every line:

- Anything touching authentication or authorization.
- Anything touching the production data store.
- Anything that calls an external API with a credit card or customer impact.
- Anything that runs in a loop without a clear stopping condition.
- Anything the agent says "this is the elegant way" about.

For these, switch mental modes. Read the diff. Reject anything you don't understand. Ask the agent to walk through it. Take your time.

---

## When to take the leash long

These are the moments where vibing is genuinely the right move:

- UI tweaks, copy changes, visual polish.
- Adding logging, telemetry, or instrumentation.
- Writing scripts for one-time data migrations or analyses.
- Building prototypes in `scratch/`.
- Anything where the cost of being wrong is "I'll just try again."

For these, accept diffs freely. The agent is faster than you. Use the asymmetry.

---

## The weekly recalibration (10 minutes, optional)

Once a week, before you forget what you've done:

1. Read through `features/shipped.md` for the last 7 days.
2. Read through `features/parked.md` for the last 7 days.
3. Append to `notes/lessons.md` (or wherever): **one thing that worked, one thing that didn't, one thing to try next week.**

That's the entire ceremony. Less than a meeting, more than nothing.

---

## When this workspace stops being enough

Sign you should graduate to the enterprise workspace:

- The "could this hurt customers?" answer is no longer "no."
- A second person wants to work on the same code at the same time.
- Someone asks for an audit trail of decisions.
- The "shipped" list is getting long enough that you can't remember what's in production.
- You catch yourself wishing you had real evals.

When that day comes: open the enterprise workspace, copy over the parts of `notes/` and `memory.md` that are still relevant, and proceed under heavier rules. The vibe workspace will have served its purpose: it got you to the point where heavier rules are worth the cost.

Until that day: enjoy the speed.
