# Memory — Tacit Knowledge

Things you learned that don't belong anywhere else. The Splunk quirk. The reason you picked X over Y. The non-obvious behavior of some library. Append; never edit prior entries.

## Format

```
## YYYY-MM-DD — short title
What you learned. Why it matters. One paragraph is fine.
```

---

## 2026-05-13 — Workspace bootstrapped
The aegis-lab workspace is for vibe coding — lightweight feature exploration on top of the demo. The enterprise workspace exists separately for production-grade work. When the answer to "could this hurt customers?" stops being "no," graduate to the enterprise workspace.

---

(Append new entries below.)
