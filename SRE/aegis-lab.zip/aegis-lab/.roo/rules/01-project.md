# 01 — Project Context

**AEGIS** is an agentic incident automation platform for SRE. The demo proved the architecture; this workspace is for following ideas to see where they go.

## Shape of the system

A **Strategist** agent (Opus-class) reads an incident signal + observability context, produces a structured **Runbook** with ranked hypotheses and confidence-scored steps. **Sub-Agents** (Sonnet-class) execute steps through **MCP servers** (Splunk, Dynatrace, Jira, Confluence, Remediation, etc.). Three fix modes: `suggest_only`, `approval_required`, `auto`. Audit log on every decision.

## Stack

- Python 3.12, FastAPI, async
- Postgres (or SQLite if the demo still uses it) + pgvector
- Anthropic Claude via the API
- MCP for all external tool integration
- React console (separate repo)

## In this workspace

The demo code lives in the usual directories (`app/`, `orchestrator/`, `agents/`, `mcp/`). This workspace is for **lightweight feature exploration**, not production-grade engineering. There is a separate workspace for that.

Default posture: **the demo works; preserve that**. Don't refactor for elegance; iterate for outcomes.
