# 02 — The Five Vibe Rules

This is the entire leash. Internalize these, and the workspace will get out of the way.

## 1. Don't commit secrets

The only truly hard rule. Anything that looks like a credential — API keys, tokens, passwords, connection strings — lives in `.env` (gitignored) or stays out of the codebase entirely. Reference them as environment variables.

If the agent suggests committing a config file with secrets in it, refuse. If the agent generates code that hardcodes credentials, fix it.

## 2. If you break the demo, fix the demo before adding more

The working demo is the foundation. Adding a feature that breaks the demo and leaving it broken is how vibe coding accumulates technical debt that eventually kills the project.

When you notice the demo isn't running, that becomes the priority. Get back to green, then resume.

## 3. Prototype in `scratch/` first if you're not sure

Real code is sticky. Once it's in `app/` or `agents/`, deleting it feels expensive even when it should be cheap. Scratch code carries no such weight.

When you have an idea but no plan, the move is: `scratch/<topic>/`, prototype, iterate, prove it works, then bring the proven parts into the real codebase.

## 4. Append to memory when you learn something

`.roo/memory.md`. Format:

```
## YYYY-MM-DD — short title
What you learned. Why it matters. One paragraph.
```

Examples of what belongs here:
- "The Strategist's confidence score is calibrated against `temperature=0.3`; raising temperature drops the score's meaningfulness."
- "Splunk MCP's `search_logs` tool times out around 60s; chunk queries above that."
- "React console's SSE stream chokes on `event: tool_use` blocks larger than 4KB. Truncate at the orchestrator."

Future-you will not remember why you did the weird thing. Memory is how vibe coding stays sane across days.

## 5. One feature at a time in `features/in-progress.md`

Max three concurrent features. Beyond that you're not building, you're juggling, and juggling with an agent is how the codebase becomes incoherent.

When you want to start a fourth, ship one or park one first.

---

## What's NOT a rule (deliberately)

The enterprise workspace has rules about coding standards, type hints, mypy --strict, test coverage, code review, ADRs, eval harnesses, prompt-injection defence, audit log discipline. In this workspace, none of those is a rule.

That's not because they don't matter. It's because **rules are a tax**, and in exploration mode the tax outweighs the benefit. If a feature graduates to production, it earns the tax then. While it's a vibe, it's free.

The risk: a vibe-coded feature gets to production without ever paying the tax. The mitigation is the "When to graduate" section in `VIBE-GUIDE.md` — know when you're past the point where vibes are appropriate.
