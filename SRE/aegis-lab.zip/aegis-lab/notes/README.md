# notes/

Freeform space for anything worth keeping that doesn't fit elsewhere.

## Suggested files (none required)

- `notes/lessons.md` — what worked, what didn't, weekly recalibration entries.
- `notes/decisions.md` — informal decisions that aren't big enough for an ADR but you want a record.
- `notes/sketches.md` — architectural doodles, half-thoughts, things to revisit.
- `notes/glossary.md` — domain terms and what they mean in your code.
- `notes/archive/` — graduated prototypes you want to keep for reference.

No structure is enforced. The point is to have somewhere to put a thought without inventing a system for it.

## When notes/ becomes a structured doc

If a file in `notes/` starts being referenced often, becomes long, or grows sections — promote it to `docs/`. That's the signal the thing has earned a place in the codebase's permanent documentation.
