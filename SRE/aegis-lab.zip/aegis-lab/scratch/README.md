# scratch/

The sandbox. Prototype here before bringing anything into the real codebase.

## What goes in here

- Half-formed ideas you want to see running.
- Three versions of the same thing so you can pick one.
- API exploration: "how does this library actually behave?"
- One-off scripts that you'll throw away.
- Anything you'd otherwise hesitate to put in the real codebase.

## What does NOT go in here

- Code your demo depends on. (That goes in the real codebase.)
- Anything customer-facing or production-bound.
- Long-lived experiments. If a prototype is still here after two weeks, either graduate it or delete it.

## Conventions

- One directory per experiment: `scratch/<topic>/`.
- A one-line README at the top of each experiment saying what it's exploring.
- Use any libraries you like; don't worry about adding them to `pyproject.toml` until the prototype graduates.
- Use any code style you like; the polish pass happens during graduation, not in scratch.

## Graduating a prototype

When a `scratch/<topic>/` proves out:

1. Switch Cline to `build` mode.
2. Prompt: *"The prototype in `scratch/<topic>/` works the way I want. Migrate the relevant parts into the real codebase. Match the existing code's style. Add tests for the happy path."*
3. Once the real code is working, delete the scratch directory (or move to `notes/archive/` if you want to keep it for reference).

## Cleaning up

Every couple of weeks, look through `scratch/`. Anything that hasn't moved in 14 days: graduate, delete, or move to `notes/archive/`. Eternal scratch is the workspace's most reliable failure mode.
