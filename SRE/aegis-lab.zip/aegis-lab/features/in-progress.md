# Features — In Progress

What you're actively building. **Maximum three at a time.** Beyond that, ship one or park one before adding more.

Each entry has the minimum scope to keep the agent on-task: what it does, what "done" looks like, any constraints. No template; whatever fits the feature.

---

## (Example — delete or replace)

### Real-time runbook scoring widget

**What:** show confidence number on each runbook hypothesis in the console, updating as the Strategist streams.

**Done when:**
- Each hypothesis card shows a confidence number.
- The number updates live during streaming.
- No noticeable performance impact on the existing console.

**Constraints:** React component only — no orchestrator changes needed.

**Started:** YYYY-MM-DD

---

(Add real entries below. Delete the example.)
