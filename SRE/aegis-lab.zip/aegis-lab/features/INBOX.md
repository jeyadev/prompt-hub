# Features — INBOX

Raw capture. No format requirements beyond a date and a one-paragraph description. Append to the bottom.

When you're ready to build something from this list, move the entry to `in-progress.md` (and add scope/done-criteria if it earned them).

---

## 2026-05-13 — Workspace bootstrapped
This file is here. Capture features as they occur to you. Don't filter.

---

(Append new entries below.)
