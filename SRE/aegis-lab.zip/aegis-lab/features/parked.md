# Features — Parked

Features you started or considered, then stopped. The point is to remember why — so you don't restart the same dead-end three months later, and so you know what to revisit when conditions change.

No shame in parking. Half of vibe coding is learning what's not worth building.

## Format

```
## YYYY-MM-DD — feature name
Why parked: one paragraph. Was the idea wrong? Too expensive? Blocked on something else? Did you get bored?
Would revisit if: the specific condition that would make this worth picking up again. Or "never" if you're sure.
```

---

(Append parked entries below.)
