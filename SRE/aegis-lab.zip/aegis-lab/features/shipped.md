# Features — Shipped

A running journal of what's landed. One line per feature. Most recent at the bottom.

The point is **memory** — when someone (or future-you) asks "what does this codebase do that it didn't last month?", this file answers.

## Format

```
- YYYY-MM-DD — short feature name — one-sentence description of what shipped
```

---

(Append shipped features below.)
